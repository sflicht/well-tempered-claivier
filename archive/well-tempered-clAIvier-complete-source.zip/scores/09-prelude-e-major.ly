\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "IX. Prelude in E major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key e \major \time 3/4
      \tempo "Allegretto, leggiero" 4 = 92
      \mark \markup \box \small "Opening cell" e'16\p gis'16 a'16 b'16 gis''16 e''16 b'16 gis'16 e'16 b'16 gis'16 b'16 |
      gis'16 b'16 gis''16 dis''16 b''16 gis''16 dis''16 b'16 gis'16 dis''16 b'16 dis''16 |
      cis''16 e''16 cis'''16 dis'''16 e'''16 cis'''16 gis''16 e''16 cis''16 gis''16 e''16 gis''16 |
      cis''16 e''16 a'16 cis''16 a''16 e''16 cis'''16 a''16 e''16 cis''16 a'16 e''16 |
      fis'16 a'16 b'16 cis''16 a''16 fis''16 cis''16 a'16 fis'16 cis''16 a'16 cis''16 |
      b'16 dis''16 b''16 fis''16 dis'''16 b''16 fis''16 dis''16 b'16 fis''16 dis''16 fis''16 |
      e''16 gis''16 e'''16 fis'''16 gis'''16 e'''16 b''16 gis''16 e''16 b''16 gis''16 b''16 |
      dis''16 fis''16 b'16 dis''16 b''16 fis''16 dis'''16 b''16 fis''16 dis''16 b'16 fis''16 |
      \mark \markup \box \small "Contrasting span" cis'''16\mp dis'''16 e'''16 cis'''16 gis''16 e''16 cis''16 gis''16 e''16 gis''16 cis''16 e''16 |
      fis''16 cis''16 a''16 fis''16 cis''16 a'16 fis'16 cis''16 a'16 cis''16 fis'16 a'16 |
      fis''16 gis''16 ais''16 fis''16 cis''16 ais'16 fis'16 cis''16 ais'16 cis''16 fis'16 ais'16 |
      b'16 dis''16 b''16 fis''16 dis'''16 b''16 fis''16 dis''16 b'16 fis''16 dis''16 fis''16 |
      e'''16 b''16 gis'''16 e'''16 b''16 gis''16 a''16 b''16 gis''16 b''16 e''16 gis''16 |
      a''16 e''16 cis'''16 a''16 e''16 cis''16 a'16 e''16 cis''16 e''16 a'16 cis''16 |
      fis''16 gis''16 a''16 fis''16 cis''16 a'16 fis'16 cis''16 a'16 cis''16 fis'16 a'16 |
      b'16 dis''16 b''16 fis''16 dis'''16 b''16 fis''16 dis''16 b'16 fis''16 dis''16 fis''16 |
      \mark \markup \box \small "Development" dis'''16\mf b''16 dis'''16 cis'''16 b''16 dis'''16 gis'''16 b'''16 dis'''16 gis'''16 b''16 gis''16 |
      gis''16 e''16 gis''16 cis''16 e''16 gis''16 cis'''16 e'''16 gis''16 cis'''16 e''16 cis''16 |
      e''16 cis''16 e''16 dis''16 cis''16 e''16 a''16 cis'''16 e''16 a''16 cis''16 a'16 |
      a'16 fis'16 cis''16 a'16 cis''16 fis'16 a'16 cis''16 fis''16 a''16 cis''16 fis''16 |
      dis''16 bis'16 dis''16 cis''16 bis'16 dis''16 gis''16 bis''16 dis''16 gis''16 bis'16 gis'16 |
      gis'16 e'16 gis'16 cis'16 e'16 gis'16 cis''16 e''16 gis'16 cis''16 e'16 cis'16 |
      e'16 cis'16 e'16 dis'16 cis'16 e'16 a'16 cis''16 e'16 a'16 cis'16 a16 |
      dis'16 b16 fis'16 dis'16 fis'16 b16 dis'16 fis'16 b'16 dis''16 fis'16 b'16 |
      \mark \markup \box \small "Return" e'16\mp gis'16 a'16 b'16 gis''16 e''16 b'16 gis'16 e'16 b'16 gis'16 b'16 |
      e'16 gis'16 e''16 b'16 gis''16 e''16 b'16 gis'16 e'16 b'16 gis'16 b'16 |
      a'16 c''16 a''16 b''16 c'''16 a''16 e''16 c''16 a'16 e''16 c''16 e''16 |
      gis'16 b'16 e'16 gis'16 e''16 b'16 gis''16 e''16 b'16 gis'16 e'16 b'16 |
      \mark \markup \box \small "Cadence" fis'16\p a'16 b'16 cis''16 a''16 fis''16 cis''16 a'16 fis'16 cis''16 a'16 cis''16 |
      e'16 gis'16 e''16 b'16 gis''16 e''16 b'16 gis'16 e'16 b'16 gis'16 b'16 |
      b'16 dis''16 b''16 fis''16 dis'''16 b''16 fis''16 dis''16 b'16 fis''16 dis''16 dis''16 |
      e''2. \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key e \major \time 3/4
      b4\p e'4 b4 |
      b4 dis'4 b4 |
      e'4 e'4 cis'4 |
      e'4 cis'4 a4 |
      a4 cis'4 cis'4 |
      dis'4 fis'4 dis'4 |
      e'4 gis'4 e'4 |
      fis'4 fis'4 dis'4 |
      e'4\mp e'4 cis'4 |
      a4 a4 fis4 |
      ais4 cis'4 ais4 |
      dis'4 fis'4 dis'4 |
      e'4 gis'4 e'4 |
      cis'4 cis'4 a4 |
      a4 cis'4 cis'4 |
      dis'4 fis'4 dis'4 |
      b4\mf dis'4 b4 |
      cis'4 e'4 cis'4 |
      cis'4 e'4 cis'4 |
      a4 cis'4 a4 |
      gis4 bis4 bis4 |
      e'4 cis'4 cis'4 |
      cis'4 a4 a4 |
      b4 dis'4 b4 |
      b4\mp e'4 b4 |
      b4 e'4 b4 |
      e'4 a'4 e'4 |
      e'4 gis'4 e'4 |
      cis'4\p fis'4 cis'4 |
      b4 e'4 b4 |
      dis'4 fis'4 a'4 |
      gis'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key e \major \time 3/4
      e,2.\p |
      gis,2. |
      cis,2~ cis,8 b,,8 |
      a,,2. |
      a,,2. |
      b,,2. |
      e,2. |
      b,,2. |
      cis,2.\mp |
      a,,2~ a,,8 gis,,8 |
      fis,,2. |
      b,,2. |
      gis,,2. |
      a,,2. |
      a,,2. |
      b,,2. |
      gis,,2.\mf |
      cis,2~ cis,8 b,,8 |
      a,,2. |
      a,,2. |
      gis,,2. |
      cis,2~ cis,8 b,,8 |
      a,,2. |
      b,,2. |
      e,2.\mp |
      gis,2. |
      a,2. |
      gis,2. |
      a,2.\p |
      b,2. |
      b,2. |
      e,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
