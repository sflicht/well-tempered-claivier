\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "VIII. Fugue in Eb minor — A narrow stair"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a3")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key ees \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 86
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'''2^\markup { \tiny \italic "Subject" } ges'''4 f'''4 |
      aes'''4 ges'''4 des'''4. ees'''8 |
      f'''2 ees'''2 |
      ges'''4.^\markup { \tiny \italic "Countersubject" } f'''16 ges'''16 f'''4 ees'''8 f'''8 |
      ges'''4 f'''2~ f'''8 ees'''16 f'''16 |
      aes'''2 ges'''2 |
      des'''2 ges'''4 f'''4 |
      ges'''4 ees''''4 bes'''8 ces''''8 des''''4 |
      ees''''2 des''''2~ |
      des''''4 f'''4 ges'''4. f'''8 |
      \mark \markup \box \small "Sequential episode" ees'''1 |
      d'''2 ees'''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'''2 bes''4 ces'''8 des'''8 |
      ees'''4 bes''8 ces'''8 des'''2~ |
      des'''4 bes''4 ges''4. aes''8 |
      bes''8 c'''8 des'''2 ees'''4 |
      bes''8 c'''8 des'''4 f'''2 |
      c'''8 bes''8 aes''4 des'''2 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Development" ces''''4. des''''8 ees''''4 fes''''4 |
      des''''4 ges'''2. |
      des'''4. ees'''8 fes'''2 |
      \mark \markup \box \small "Linking episode" aes'''1 |
      g'''2 aes'''2 |
      \mark \markup \box \small "Development" bes'''2^\markup { \tiny \italic "Related-key subject" } des''''4 c''''4 |
      ees''''4 des''''4 aes'''4. bes'''8 |
      c''''2 bes'''2 |
      \mark \markup \box \small "Stretto" bes'''2 des'''2 |
      ees'''2 bes'''4 f'''4 |
      des'''2 ees'''2^\markup { \tiny \italic "Stretto subject" } |
      ges'''4 f'''4 aes'''4 ges'''4 |
      des'''4. ees'''8 f'''2 |
      ees'''2 ges'''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" bes'''2~ bes'''8 aes'''8 ges'''4 |
      bes'''4. aes'''8 ges'''4 bes'''4 |
      ces''''1~ |
      ces''''1~ |
      ces''''8 des''''8 ees''''4 ces''''2 |
      ees''''4. des''''8 ces''''4 ees''''4 |
      bes'''4. aes'''8 ges'''4 bes'''4~ |
      bes'''2. ges'''4 |
      \mark \markup \box \small "Gathered development" ees'''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      ges'''1 |
      aes'''8 bes'''8 ces''''4 ees''''2 |
      f''''2.~ f''''8 ees''''8 |
      d''''1~ |
      d''''2 bes'''2 |
      d''''4 f'''2 bes'''4~ |
      bes'''4 ges'''2.~ |
      ges'''2~ ges'''8 f'''8 ees'''4 |
      \mark \markup \box \small "Final return" aes'''2 bes'''4 ces''''4 |
      aes'''4 bes'''4 ges'''2 |
      aes'''1 |
      \mark \markup \box \small "Final cadence" aes'''2 bes'''2 |
      ges'''1 |
      ges'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'''2^\markup { \tiny \italic "Subject" } ges'''4 f'''4 |
      aes'''4 ges'''4 des'''4. ees'''8 |
      f'''2 ees'''2 |
      ges'''4.^\markup { \tiny \italic "Countersubject" } f'''16 ges'''16 f'''4 ees'''8 f'''8 |
      ges'''4 f'''2~ f'''8 ees'''16 f'''16 |
      aes'''2 ges'''2 |
      ees'''2 d'''4 ees'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''8 c'''8 des'''4 aes'''4 ees'''4 |
      bes''8 c'''8 des'''4 c'''2~ |
      c'''4 f''4 des'''2 |
      ees'''8 f'''8 ges'''4 des'''2 |
      aes''4 ees'''4 bes''4 f'''4 |
      aes''4 des'''8 ces'''8 bes''2~ |
      bes''4 f'''8 ees'''8 des'''4 bes''4~ |
      bes''4 f''4 bes''4 des'''4 |
      ges''8 f''8 ees''4 bes''2 |
      r1 |
      bes''8 aes''8 ges''4 bes''2~ |
      bes''4 ges''2. |
      ces'''8 des'''8 ees'''4 ces'''2~ |
      ces'''4 ees'''4 ces'''2 |
      aes''8 bes''8 ces'''2. |
      aes''2 ees'''2~ |
      ees'''4 bes''2. |
      ges''8 aes''8 bes''2. |
      ges''8 aes''8 bes''4 ees'''2 |
      ges''4 ces'''2. |
      ees'''2 aes''2~ |
      aes''4 f'''2. |
      aes''2 f'''2~ |
      f'''2 bes''2 |
      f'''4 bes''2.~ |
      bes''4 ges'''4 ees'''2 |
      ges''4 ces'''2. |
      ees'''8 des'''8 ces'''4 ges''4 ces'''4 |
      ees'''4 bes''4 des'''2~ |
      des'''4 aes''4 ees'''2 |
      ees'''4 aes''4 f'''4 bes''4~ |
      bes''2 ees'''2 |
      ges'''2 ees'''2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      bes''2^\markup { \tiny \italic "Real answer" } des'''4 c'''4 |
      ees'''4 des'''4 aes''4. bes''8 |
      c'''2 bes''2 |
      ces'''4.^\markup { \tiny \italic "Countersubject" } bes''16 ces'''16 bes''4 aes''8 bes''8 |
      ces'''4 bes''2~ bes''8 aes''16 bes''16 |
      des'''2 ces'''2 |
      bes''2 aes''2 |
      c'''4 aes''2.~ |
      aes''4 ees''8 f''8 ges''2 |
      f''2 ees''8 des''8 ces''4 |
      ges''4 ges'''4 des'''4 aes''4~ |
      aes''4 bes''2.~ |
      bes''8 aes''4. ces''8 des''8 ees''4 |
      ges''4 ees'''2 ces'''4 |
      bes''2 ees''4 bes'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ces'''8 bes''8 aes''4 bes''4 f''4 |
      ees''8 f''8 ges''4 bes''4 f''4~ |
      f''4 des''4 ees''8 f''8 ges''4 |
      ges''4 des''8 ees''8 f''4 aes''4 |
      ges''8 aes''8 bes''4 c'''4 aes''4~ |
      aes''4 ees''8 f''8 ges''4 bes''4 |
      r1 |
      aes''8 ges''8 fes''4 ges''4 des''4~ |
      des''4 ees''8 fes''8 ges''4 bes''4~ |
      bes''4 ges''4 aes''4 fes''4 |
      fes''2 aes''4 des''4 |
      bes''2 aes''4 ees''4 |
      ges''2 des''4 ees''4~ |
      ees''4 aes''4 f''4 c''4~ |
      c''4 f''4 des''4 ges''4 |
      ges''8 f''8 ees''4 bes''4 aes''4~ |
      aes''4 ees''4 des''4 f''4~ |
      f''4 aes''4 ges''8 f''8 ees''4~ |
      ees''4 f''2 ges''4~ |
      ges''4 f''4. ges''8 aes''4 |
      ees''8 f''8 ges''2 ees''4 |
      r1 |
      ges''4 ees''4 ges''4 ees''4~ |
      ees''4 ges''4 ees''4 ges''4~ |
      ges''4 ees''4 ges''4 ees''4 |
      ges''8 f''8 ees''4 ges''4 ees''4~ |
      ees''4 aes''4 ees''4 aes''4~ |
      aes''4 ees''4 aes''4 ees''4 |
      ges''8 f''8 ees''4 ges''4 ees''4~ |
      ees''4 ges''4 ees''4 ges''4 |
      ges''4. aes''8 bes''4 ges''4 |
      ees''8 f''8 ges''2 ces'''4~ |
      ces'''4 aes''4 ees'''4 ces'''4~ |
      ces'''4 aes''4 f''2~ |
      f''4 aes''2 f'''4~ |
      f'''4 f''2 bes''4~ |
      bes''4 f''4 bes'2~ |
      bes'4 ees''4 bes'4 ees''4~ |
      ees''4 ges''4 ces'''4 ges''4 |
      ces'''8 bes''8 aes''4 ges''4 aes''4 |
      ees''4 ges''4 bes''4 ges''4 |
      f''4 des''4 ees''4 aes''4 |
      aes''4 ees''4 bes''2 |
      ees''4 ges''4 bes''4 ges''4~ |
      ges''4 ees''4 ges''4 ees''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2^\markup { \tiny \italic "Real answer" } des''4 c''4 |
      ees''4 des''4 aes'4. bes'8 |
      c''2 bes'2 |
      ces''4.^\markup { \tiny \italic "Countersubject" } bes'16 ces''16 bes'4 aes'8 bes'8 |
      ces''4 bes'2~ bes'8 aes'16 bes'16 |
      des''2 ces''2 |
      ges'2 aes'4 ees'4~ |
      ees'4 f'2 aes'4~ |
      aes'2 bes'2 |
      ees''2 bes'2 |
      aes'2^\markup { \tiny \italic "Related-key subject" } ces''4 bes'4 |
      des''4 ces''4 ges'4. aes'8 |
      bes'2 aes'2 |
      aes'1 |
      ees''2. aes'4 |
      des''2. ges'4 |
      bes'4 des'8 ees'8 f'4 aes'4~ |
      aes'2 bes'2 |
      bes'4 ges'2 aes'4~ |
      aes'4 bes'2 aes'4~ |
      aes'4 f'4 ges'4 bes'4~ |
      bes'4 des''2 ees''4 |
      des''4 bes'2 aes'4 |
      ces''4 ees''2 ges''4 |
      r1 |
      ges'4 bes'2 ees''4~ |
      ees''4 bes'2 ees''4~ |
      ees''4 ces''2 ees''4~ |
      ees''4 ces''2 ees''4 |
      ces''8 bes'8 aes'2 ces''4~ |
      ces''4 aes'4 ces''4 aes'4 |
      ges'4 bes'2 ees''4~ |
      ees''4 bes'2 ees''4 |
      ges'4 ges''4 bes'2 |
      ees''2.~ ees''8 des''8 |
      ces''8 des''8 ees''4 ces'''2~ |
      ces'''2 ces''4 ces'''4 |
      aes''2.~ aes''8 ges''8 |
      f''4. ees''8 d''2 |
      f'8 ees'8 d'4 bes'4 d''4 |
      ees''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      ges''2 ees''4 ces''4 |
      aes'4 ces''4 des''4 ces''4~ |
      ces''4 des''2 bes'4 |
      aes'4 f'4 aes'4 ces''4 |
      ces''4 aes'4 f'4 bes'4~ |
      bes'4 ges'2 bes'4~ |
      bes'4 ges'2 bes'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key ees \minor \time 4/4
      ees'2^\markup { \tiny \italic "Subject" } ges'4 f'4 |
      aes'4 ges'4 des'4. ees'8 |
      f'2 ees'2 |
      ges'4.^\markup { \tiny \italic "Countersubject" } f'16 ges'16 f'4 ees'8 f'8 |
      ges'4 f'2~ f'8 ees'16 f'16 |
      aes'2 ges'2 |
      aes'2 ges'4 aes'4~ |
      aes'4 ees'8 f'8 ges'2 |
      f'4. ges'8 aes'2~ |
      aes'8 ges'4. aes'2~ |
      aes'8 ges'8 aes'8 ges'8 f'2~ |
      f'8 ees'4. des'2 |
      des'2 ces'2 |
      ees'2 des'8 ees'8 f'4 |
      ees'4 bes4 f'2~ |
      f'8 ees'8 des'4 ges2 |
      ges4 ces'4 ees'2 |
      bes1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fes'8 ges'8 aes'4 fes'8 ees'8 des'4 |
      bes4 ees'4 aes'8 bes'8 ces''4 |
      bes'8 aes'8 ges'4 aes'4 ges'4~ |
      ges'4 aes'2 c''4 |
      aes'8 ges'8 f'4 bes'4 ges'4 |
      ges'2 bes'4 des'4 |
      ces'4 bes4. ces'8 des'4~ |
      des'2 ges'2 |
      bes'2 f'4 ees'4 |
      bes2 d'4 des'4 |
      ees'1 |
      r1 |
      ges'2. bes'4 |
      ges'4. aes'8 bes'4 ges'4~ |
      ges'1~ |
      ges'1 |
      ees'4 ces'4 ees'4 ees''4 |
      ces''4. des''8 ees''4 ces''4 |
      ges'2 bes'4 ges'4~ |
      ges'2. bes'4 |
      bes'4 ges'4 ees'4 ges'4~ |
      ges'4 ees'4 ges'4 ees'4~ |
      ees'4 aes'4 ces''4 aes'4~ |
      aes'4 f'4 aes'2~ |
      aes'4 f'8 ges'8 aes'4 f'4~ |
      f'2 bes'4 f'4~ |
      f'2 bes'2~ |
      bes'4 ees'4 ges'4 ees'4~ |
      ees'4 ces'4 ees'4 ges'4 |
      ees'2^\markup { \tiny \italic "Subject" } ges'4 f'4 |
      aes'4 ges'4 des'4. ees'8 |
      f'2 ees'2 |
      ees'2 d'4 f'4 |
      ges'1 |
      ges'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "bass" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'2^\markup { \tiny \italic "Subject" } ges'4 f'4 |
      aes'4 ges'4 des'4. ees'8 |
      f'2 ees'2 |
      ges4.^\markup { \tiny \italic "Countersubject" } f16 ges16 f4 ees8 f8 |
      ges4 f2~ f8 ees16 f16 |
      aes2 ges2 |
      aes2 ges4 aes4~ |
      aes4 bes2.~ |
      bes2 ces'2 |
      bes2 aes2 |
      bes2 aes2~ |
      aes4 c'4 des'2 |
      ces'8 bes8 aes4 bes2 |
      ces'2 ges4 bes4 |
      aes8 bes8 ces'4 bes4 ees'4 |
      bes2 des'4 fes'4 |
      ces'2 fes'4 aes'4 |
      ees'4 bes4 ces'4 ees'4 |
      bes2 aes4 c'4 |
      bes4 aes4 c'4 f'4 |
      c'8 bes8 aes4 des'4 bes4 |
      bes4 ees'4 des'4 f'4 |
      ees'2 f'4 des'4 |
      aes2 bes4 ees'4 |
      bes2 aes4 bes4 |
      des'4. ces'8 bes4 f4 |
      ges4 ces'4 bes4 ees'4 |
      r1 |
      bes2 ees'4 ges'4 |
      ees'2 ges'4 ees'4 |
      ces'2 ees'4 ces'4 |
      ges2 ces'4 ges4 |
      aes2 ces'4 aes4 |
      ces'2 aes4 ces'4 |
      bes2 ees'4 ges'4 |
      ees'4. f'8 ges'4 ees'4 |
      ees'2 ges'4 ees'4~ |
      ees'4 ces'4 ees'4 ces'4~ |
      ces'2 aes4 ces'4 |
      aes4. bes8 ces'4 aes4~ |
      aes2 f2~ |
      f4 bes2 f'4 |
      bes2 f'4 bes4~ |
      bes2 ees'4 ges'4 |
      ees'4. des'8 ces'4 ees'4 |
      ees'2 des'4 f'4 |
      ees'4 des'4 bes4 des'4 |
      aes2 ces'4 aes4 |
      ces'4 ees'4 f'2 |
      ees'2 ges'4 ees'4 |
      bes2 ees'4 ges'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "bass" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2^\markup { \tiny \italic "Real answer" } des'4 c'4 |
      ees'4 des'4 aes4. bes8 |
      c'2 bes2 |
      bes4. aes8 ges4 ces4 |
      ces4.^\markup { \tiny \italic "Countersubject" } bes,16 ces16 bes,4 aes,8 bes,8 |
      ces4 bes,2~ bes,8 aes,16 bes,16 |
      des2 ces2 |
      ees8 f8 ges4 ces'4 aes4 |
      f2 ees8 f8 ges4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ces'2 des'4 ces'4 |
      aes4 des'4 bes4 des'4 |
      bes2 ees'2 |
      des'2 aes4 c'4 |
      bes2 f2 |
      ees2 des2 |
      r1 |
      aes2 ges4 fes4~ |
      fes4 ces4 ees2 |
      des2.~ des8 ees8 |
      fes4 ces4 des2 |
      ees1 |
      des2 f4 ges4 |
      ees4 f2. |
      ees4 f4 ges2 |
      ges2 des'4 aes4 |
      ees8 f8 ges4 f4 aes4 |
      f2 bes2 |
      ges4 des8 ees8 f4 bes4~ |
      bes2 f4 des4 |
      ges2 ees2 |
      r1 |
      ges2 ees2 |
      bes,2 ees2 |
      ges2 ees2 |
      ces4. des8 ees4 ces4 |
      ees2 aes2 |
      ees4 ces2. |
      ees4 ges4 ees2 |
      bes,2 ees2 |
      bes2 ges2~ |
      ges2 ees2~ |
      ees4 ees'4 ces'2~ |
      ces'4 ces4 aes,4 f,4~ |
      f,2 f2~ |
      f4 bes,4 f,2~ |
      f,4 bes,4 d8 ees8 f4 |
      ges4 bes,2. |
      ees4. f8 ges2 |
      aes2 des'4 aes4~ |
      aes4 des4 ges4 bes4 |
      f4 aes2. |
      ees2 bes,2 |
      ees2. ges4 |
      ees4 ges4 bes2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "bass" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,2^\markup { \tiny \italic "Real answer" } des4 c4 |
      ees4 des4 aes,4. bes,8 |
      c2 bes,2 |
      ces2 bes,8 aes,8 ges,4 |
      r1 |
      r1 |
      r1 |
      aes,2 des4 aes,4 |
      bes,2 ees4 ces4 |
      des2. ges4 |
      bes,4 f,4 aes,4 f,4 |
      c2 des2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,2 ges,2~ |
      ges,4 bes,2. |
      ges,2 ces4 ges,4 |
      ees,4 ges,4 ees,4 ges,4 |
      ces2. ees4 |
      aes,2 ees,4 aes,4 |
      bes,2. ees,4 |
      ges,2 bes,2 |
      bes,4 ees4 bes,4 ees4~ |
      ees2 ces2 |
      ees,2. aes,4~ |
      aes,2 f4 aes,4~ |
      aes,4 f2. |
      f,2. bes,,4~ |
      bes,,2 bes,2~ |
      bes,2 ges,2~ |
      ges,4 ees,4 ces2 |
      ces2 ges4 ces4~ |
      ces4 ges,2 des,4 |
      aes,2. ees,4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "bass" \key ees \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,2 ees4 aes,4 |
      ees,2^\markup { \tiny \italic "Subject" } ges,4 f,4 |
      aes,4 ges,4 des,4. ees,8 |
      f,2 ees,2 |
      ces,4. bes,,8 aes,,2 |
      bes,,4. aes,,8 ges,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fes,4.^\markup { \tiny \italic "Countersubject" } ees,16 fes,16 ees,4 des,8 ees,8 |
      fes,4 ees,2~ ees,8 des,16 ees,16 |
      ges,2 fes,2 |
      fes,1 |
      ees,4. des,8 ces,2 |
      ges,4.^\markup { \tiny \italic "Countersubject" } f,16 ges,16 f,4 ees,8 f,8 |
      ges,4 f,2~ f,8 ees,16 f,16 |
      aes,2 ges,2 |
      ees,2^\markup { \tiny \italic "Stretto subject" } ges,4 f,4 |
      aes,4 ges,4 des,4. ees,8 |
      f,2 ees,2 |
      ees,4 des,2 ges,4~ |
      ges,4 bes,2 des,4 |
      ces,2 ees,2 |
      r1 |
      ees,1~ |
      ees,1~ |
      ees,1~ |
      ees,1 |
      aes,,1~ |
      aes,,1 |
      ees,1~ |
      ees,1 |
      ees,1 |
      ces,1 |
      aes,,1~ |
      aes,,1 |
      f,,1 |
      bes,,1~ |
      bes,,1 |
      ees,2.~ ees,8 des,8 |
      ces,1 |
      ces,4.^\markup { \tiny \italic "Countersubject" } bes,,16 ces,16 bes,,4 aes,,8 bes,,8 |
      ces,4 bes,,2~ bes,,8 aes,,16 bes,,16 |
      des,2 ces,2 |
      ces,2 bes,,4 d,4 |
      ees,1 |
      ees,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
