\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "II. Prelude in C minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key c \minor \time 4/4
      \tempo "Allegro, incisivo" 4 = 104
      \mark \markup \box \small "Opening cell" c''16\p d''16 ees''16 c'''16 g''16 c''16 ees''16 g''16 r2 |
      c''16 g''16 ees''16 c'''16 g''16 c''16 ees''16 g''16 r2 |
      f''16 g''16 aes''16 f'''16 c'''16 f''16 aes''16 c'''16 r2 |
      b''16 d'''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 r2 |
      c''16 d''16 ees''16 c'''16 g''16 c''16 ees''16 g''16 r2 |
      aes'16 ees''16 c''16 aes''16 ees''16 aes'16 c''16 ees''16 r2 |
      d''16 ees''16 f''16 d'''16 aes''16 d''16 f''16 aes''16 r2 |
      g''16 d'''16 b''16 g'''16 d'''16 g''16 b''16 d'''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 b''16 d'''16 |
      \mark \markup \box \small "Contrasting span" g''16\mp aes''16 bes''16 ees''16 g''16 bes''16 ees''16 bes''16 g''16 ees'''16 bes''16 ees''16 g''16 bes''16 ees''16 bes''16 |
      d''16 bes''16 f''16 bes'16 d''16 f''16 bes'16 f''16 d''16 bes''16 f''16 bes'16 d''16 f''16 bes'16 f''16 |
      g''16 aes''16 bes''16 ees''16 g''16 bes''16 ees''16 bes''16 g''16 ees'''16 bes''16 ees''16 g''16 bes''16 ees''16 bes''16 |
      aes''16 ees'''16 c'''16 aes'''16 ees'''16 aes''16 c'''16 ees'''16 aes''16 ees'''16 c'''16 aes'''16 ees'''16 aes''16 c'''16 ees'''16 |
      aes''16 bes''16 c'''16 f''16 aes''16 c'''16 f''16 c'''16 aes''16 f'''16 c'''16 f''16 aes''16 c'''16 f''16 c'''16 |
      fis''16 d'''16 a''16 d''16 fis''16 a''16 d''16 a''16 fis''16 d'''16 a''16 d''16 fis''16 a''16 d''16 a''16 |
      d''16 b'16 c''16 d''16 g''16 b'16 d''16 g'16 d''16 b'16 g'16 d''16 g''16 b'16 d''16 g'16 |
      d''16 g'16 d''16 b'16 g'16 d''16 g''16 b'16 d''16 g'16 d''16 b'16 g'16 d''16 g''16 b'16 |
      \mark \markup \box \small "Development" c''16\mf ees''16 c''16 g''16 c'''16 ees''16 d''16 c''16 g''16 ees''16 c''16 g''16 c'''16 ees''16 g''16 c''16 |
      f''16 d''16 bes'16 f''16 bes''16 d''16 f''16 bes'16 f''16 d''16 bes'16 f''16 bes''16 d''16 f''16 bes'16 |
      ees''16 c''16 aes'16 ees''16 aes''16 c''16 bes'16 aes'16 ees''16 c''16 aes'16 ees''16 aes''16 c''16 ees''16 aes'16 |
      d''16 g'16 d''16 b'16 g'16 d''16 g''16 b'16 d''16 g'16 d''16 b'16 g'16 d''16 g''16 b'16 |
      \mark \markup \box \small "Return" c''16\mp aes'16 f'16 c''16 f''16 aes'16 g'16 f'16 c''16 aes'16 f'16 c''16 f''16 aes'16 c''16 f'16 |
      c''16 g''16 ees''16 c'''16 g''16 c''16 ees''16 g''16 r2 |
      des''16 ees''16 f''16 des'''16 aes''16 des''16 f''16 aes''16 r2 |
      b''16 d'''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 r2 |
      \mark \markup \box \small "Cadence" c''16\p d''16 ees''16 c'''16 g''16 c''16 ees''16 g''16 r2 |
      c''16 g''16 ees''16 c'''16 g''16 c''16 ees''16 g''16 r2 |
      g''16 d'''16 b''16 g'''16 d'''16 g''16 b''16 b''16 r2 |
      c'''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key c \minor \time 4/4
      r2 g'16 ees'16 c'16 g'16 ees'16 c''16 g'16 c'16 |
      r2 g'16 ees'16 c'16 g'16 ees'16 c''16 g'16 c'16 |
      r2 c'16 aes16 f16 c'16 aes16 f'16 c'16 f16 |
      r2 d'16 b16 g16 d'16 b16 g'16 d'16 g16 |
      r2 g'16 ees'16 c'16 g'16 ees'16 c''16 g'16 c'16 |
      r2 ees'16 c'16 aes16 ees'16 c'16 aes'16 ees'16 aes16 |
      r2 aes16 f16 d16 aes16 f16 d'16 aes16 d16 |
      b4 d'4 d'16 b16 g16 d'16 b16 g'16 d'16 g16 |
      g4\mp bes4 bes16 g16 ees16 bes16 g16 ees'16 bes16 ees16 |
      d'4 f'4 f'16 d'16 bes16 f'16 d'16 bes'16 f'16 bes16 |
      g'4 bes'4 bes'16 g'16 ees'16 bes'16 g'16 ees''16 bes'16 ees'16 |
      c''4 ees''4 ees''16 c''16 aes'16 ees''16 c''16 aes''16 ees''16 aes'16 |
      aes'4 c''4 c''16 aes'16 f'16 c''16 aes'16 f''16 c''16 f'16 |
      fis'4 a'4 a'16 fis'16 d'16 a'16 fis'16 d''16 a'16 d'16 |
      b'4 d''4 d''16 b'16 g'16 d''16 b'16 g''16 d''16 g'16 |
      b'4 d''4 d''16 b'16 g'16 d''16 b'16 g''16 d''16 g'16 |
      ees''4\mf g''4 g''16 ees''16 c''16 g''16 ees''16 c'''16 g''16 c''16 |
      d''4 f''4 f''16 d''16 bes'16 f''16 d''16 bes''16 f''16 bes'16 |
      c''4 ees''4 ees''16 c''16 aes'16 ees''16 c''16 aes''16 ees''16 c''16 |
      b'4 d''4 d''16 b'16 g'16 d''16 b'16 g''16 d''16 g'16 |
      aes'4\mp c''4 c''16 aes'16 f'16 c''16 aes'16 f''16 c''16 f'16 |
      r2 g'16 ees'16 c'16 g'16 ees'16 c''16 g'16 c'16 |
      r2 aes'16 f'16 des'16 aes'16 f'16 des''16 aes'16 des'16 |
      r2 d'16 b16 g16 d'16 b16 g'16 d'16 g16 |
      r2 g16 ees16 c16 g16 ees16 c'16 g16 c16 |
      r2 g16 ees16 c16 g16 ees16 c'16 g16 c16 |
      r2 d16 b,16 g,16 d16 b,16 g16 d16 f16 |
      ees1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key c \minor \time 4/4
      c,1\p |
      ees,1 |
      f,1 |
      g,1 |
      c,1 |
      aes,,2.~ aes,,8 g,,8 |
      f,,1 |
      g,,1 |
      ees,1\mp |
      bes,,1 |
      ees,1 |
      aes,1 |
      f,1 |
      d,1 |
      g,1 |
      g,1 |
      c,1\mf |
      bes,,1 |
      aes,,1 |
      g,,1 |
      f,,1\mp |
      ees,,1 |
      f,,1 |
      g,,1 |
      ees,1\p |
      g,1 |
      g,1 |
      c,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
