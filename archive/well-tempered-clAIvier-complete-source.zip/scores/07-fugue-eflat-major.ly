\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "VII. Fugue in Eb major — Wingbeats"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key ees \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 116
      \mark \markup \box \small "Continuous exposition" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4^\markup { \tiny \italic "Real answer" } d'''4 f'''2 |
      g'''4 f'''8 ees'''8 d'''4 ees'''4 |
      c'''2 bes''2 |
      c'''4^\markup { \tiny \italic "Countersubject" } bes''8 c'''8 d'''4. ees'''16 d'''16 |
      ees'''4 d'''4 ees'''8 d'''8 c'''4 |
      d'''2 c'''2 |
      bes''4 a''2 d'''4~ |
      d'''2. g''4 |
      ees'''2 d'''2 |
      \mark \markup \box \small "Eight-part sequential release" c'''2 f''4^\markup { \tiny \italic "Subject-head fragment" } aes''4 |
      f''2 ees''4^\markup { \tiny \italic "Subject-head fragment" } g''4 |
      \mark \markup \box \small "Relative-minor quartet" r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Subject-head sequence" r1 |
      r1 |
      \mark \markup \box \small "Answering quartet" c'''2 bes''4. c'''8 |
      des'''4 c'''8 bes''8 aes''2 |
      bes''4. c'''8 des'''2 |
      \mark \markup \box \small "Eight-part reunion" aes'''8 g'''8 f'''2 d'''4 |
      ees'''1 |
      \mark \markup \box \small "Stretto" ees'''4 bes'''2 d'''4 |
      c'''4 g''4 g'''4 f'''4 |
      aes''4^\markup { \tiny \italic "Stretto subject" } c'''4 ees'''2 |
      f'''4 ees'''8 des'''8 c'''4 des'''4 |
      bes''2 aes''2 |
      \mark \markup \box \small "Eight-part final return" g''2 d'''4 g'''4~ |
      g'''2. c'''4 |
      aes''2.~ aes''8 bes''8 |
      \mark \markup \box \small "Final cadence" c'''2 d'''2 |
      ees'''1^\markup { \tiny \italic "Cadential tonic arrival" } |
      ees'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key ees \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4^\markup { \tiny \italic "Real answer" } d'''4 f'''2 |
      g'''4 f'''8 ees'''8 d'''4 ees'''4 |
      c'''2 bes''2 |
      c'''1 |
      c''4^\markup { \tiny \italic "Countersubject" } bes'8 c''8 d''4. ees''16 d''16 |
      ees''4 d''4 ees''8 d''8 c''4 |
      d''2 c''2 |
      ees''4 f''4 c'''2 |
      bes''4 c'''4 f''4 g''4 |
      f''4. ees''8 d''4 ees''4 |
      g''2 bes'8 c''8 d''4 |
      g''8 aes''8 bes''4 ees''4 aes''4~ |
      aes''2 ees''2 |
      d''8 ees''8 f''2. |
      d''2. g''8 f''8 |
      ees''2 g'2 |
      ees''2 f''2 |
      bes'2 ees''2 |
      f''2 c'''4. d'''8 |
      ees'''2 d'''4. ees'''8 |
      f'''4 d'''4 c'''2 |
      bes''8 aes''8 g''4 aes''4. bes''8 |
      c'''2 bes''4^\markup { \tiny \italic "Subject-head fragment" } d'''4 |
      bes''2 aes''4^\markup { \tiny \italic "Subject-head fragment" } c'''4 |
      r1 |
      r1 |
      r1 |
      c'''8 bes''8 aes''4 bes''2~ |
      bes''4 g''4 c''2 |
      g'4 g'4 d''4 d''4 |
      ees''8 f''8 g''4 bes''4 f''4 |
      c''2~ c''8 d''8 ees''4 |
      c''2. bes'4 |
      des''2. c''4 |
      ees''4. f''8 g''2~ |
      g''2 ees''2 |
      aes''1 |
      aes''2 f''2 |
      ees''4. f''8 g''4 ees''4 |
      ees''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key ees \major \time 4/4
      r1 |
      r1 |
      r1 |
      bes'4^\markup { \tiny \italic "Real answer" } d''4 f''2 |
      g''4 f''8 ees''8 d''4 ees''4 |
      c''2 bes'2 |
      c''4^\markup { \tiny \italic "Countersubject" } bes'8 c''8 d''4. ees''16 d''16 |
      ees''4 d''4 ees''8 d''8 c''4 |
      d''2 c''2 |
      d''2 c''2 |
      d''4 c''4 bes'2 |
      c''4. d''8 ees''4 d''4 |
      ees''2.~ ees''8 d''8 |
      c''4 g'2.~ |
      g'4 bes'2 c''8 bes'8 |
      aes'4. bes'8 c''2 |
      bes'4 f''2. |
      bes'4 f'4 bes'2 |
      c''2 g''2 |
      g''1~ |
      g''4. f''8 ees''2 |
      aes'4. bes'8 c''2 |
      g'4 d''4 a''8 g''8 f''4 |
      bes'4 f'4 bes'2 |
      c''2 d''2 |
      ees''4 g'4 f'2~ |
      f'2 g'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      aes'4^\markup { \tiny \italic "Subdominant subject" } c''4 ees''2 |
      f''4 ees''8 des''8 c''4 des''4 |
      bes'2 aes'2 |
      c''2 bes'2~ |
      bes'2 aes'4 ees'4 |
      g'2 f'8 ees'8 d'4 |
      g'2. c'4~ |
      c'4 f'4 g'2 |
      c''2 f'4 des''4 |
      f''8 ees''8 des''4 f'4 c'4 |
      c''8 d''8 ees''4 g'2 |
      ees''4 bes''4 ees''4 aes'4 |
      f''2 aes'2 |
      aes''8 bes''8 c'''4 f''4 bes'4~ |
      bes'1 |
      bes'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key ees \major \time 4/4
      ees'4^\markup { \tiny \italic "Subject" } g'4 bes'2 |
      c''4 bes'8 aes'8 g'4 aes'4 |
      f'2 ees'2 |
      g'4^\markup { \tiny \italic "Countersubject" } f'8 g'8 a'4. bes'16 a'16 |
      bes'4 a'4 bes'8 a'8 g'4 |
      a'2 g'2 |
      g'8 aes'8 bes'2. |
      ees''4 bes'2 aes'4~ |
      aes'2 g'2 |
      g'4 a'8 bes'8 c''2~ |
      c''8 bes'8 f'4 g'2~ |
      g'8 f'4. g'2 |
      g'4 aes'8 bes'8 c''2 |
      g'1~ |
      g'4. f'8 ees'2 |
      f'8 g'8 aes'4 g'2 |
      g'4 a'8 bes'8 c''2 |
      d''4 f''2 ees''4 |
      f''2 bes'4. a'8 |
      g'2 d''4 g'4~ |
      g'2 ees''4 aes'4~ |
      aes'8 g'8 f'4 c'2 |
      g'4 a'4 d''2~ |
      d''2 bes'2 |
      ees'2 g'2 |
      c'1 |
      bes2.~ bes8 c'8 |
      d'2 ees'4 aes'4 |
      c''4^\markup { \tiny \italic "Relative-key subject" } ees''4 g''2 |
      aes''4 g''8 f''8 ees''4 f''8 ees''8 |
      d''2 c''2 |
      aes'8 g'8 f'2. |
      g'2 aes'2 |
      r1 |
      r1 |
      r1 |
      c''4 f'2 bes4~ |
      bes2 c'4. d'8 |
      ees'2 bes'2 |
      g'2 d''4 f'4 |
      aes'2 c'2 |
      c'2 f'2~ |
      f'2 aes'2 |
      ees'4^\markup { \tiny \italic "Subject" } g'4 bes'2 |
      c''4 bes'8 aes'8 g'4 aes'4 |
      f'2 ees'2 |
      ees'4 c''4 bes'4. aes'8 |
      g'1 |
      g'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key ees \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'4^\markup { \tiny \italic "Subject" } g'4 bes'2 |
      c''4 bes'8 aes'8 g'4 aes'4 |
      f'2 ees'2 |
      g4^\markup { \tiny \italic "Countersubject" } f8 g8 a4. bes16 a16 |
      bes4 a4 bes8 a8 g4 |
      a2 g2 |
      g4 c'4 ees'2 |
      g'2.~ g'8 f'8~ |
      f'8 ees'8 bes2 aes4~ |
      aes2 ees'2 |
      ees'4 d'4 c'4 f'4 |
      d''4 c''4 bes'2 |
      f'2 g'2 |
      ees'4 bes2. |
      g'4 bes4 ees'2 |
      f'2 g'2 |
      d'4 a2. |
      g4 a8 g8 f4 g4 |
      c'8 d'8 ees'4 bes2 |
      ees'8 d'8 c'4 aes8 g8 f4 |
      bes1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4^\markup { \tiny \italic "Countersubject" } ees'8 f'8 g'4. aes'16 g'16 |
      aes'4 g'4 aes'8 g'8 f'4 |
      g'2 f'2 |
      f2 bes2~ |
      bes4 ees2 c'4 |
      c'8 d'8 ees'4 f'4 bes4 |
      g'4 d'4. ees'8 f'4~ |
      f'2 c'2 |
      c'8 des'8 ees'4 f'2 |
      bes'4 des'4 aes2 |
      c'4^\markup { \tiny \italic "Countersubject" } bes8 c'8 d'4. ees'16 d'16 |
      ees'4 d'4 ees'8 d'8 c'4 |
      d'2 c'2 |
      aes4 ees4 bes2~ |
      bes4 g8 aes8 bes2 |
      bes1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "bass" \key ees \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c4 aes2. |
      ees4^\markup { \tiny \italic "Subject" } g4 bes2 |
      c'4 bes8 aes8 g4 aes4 |
      f2 ees2 |
      g4^\markup { \tiny \italic "Countersubject" } f8 g8 a4. bes16 a16 |
      bes4 a4 bes8 a8 g4 |
      a2 g2 |
      g4 d'2 g'4 |
      ees'4 bes2 aes4~ |
      aes2 g4. aes8 |
      bes4 f4 d'2~ |
      d'2. bes4 |
      ees'8 d'8 c'4 g4 bes4 |
      g4 c'2 f4~ |
      f4 bes2. |
      bes4 b4 c'4. bes8 |
      aes4^\markup { \tiny \italic "Countersubject" } g8 aes8 bes4 b4 |
      c'4. b8 c'8 bes8 aes4 |
      bes2 aes2 |
      aes8 bes8 c'4 d'2 |
      ees'4. d'8 c'2 |
      r1 |
      r1 |
      r1 |
      f'1 |
      ees'2.~ ees'8 d'8 |
      c'4 g'4 bes4 g'4~ |
      g'4 bes2 c'4~ |
      c'1 |
      aes'4 g'4 f'4 des'4~ |
      des'4 f'2 ees'4 |
      ees'4 bes4 g'4 d'4 |
      c'4 g2 ees'4 |
      f'8 g'8 aes'2 ees'4 |
      ees'2 bes2~ |
      bes1 |
      bes1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "bass" \key ees \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees4^\markup { \tiny \italic "Subject" } g4 bes2 |
      c'4 bes8 aes8 g4 aes4 |
      f2 ees2 |
      g4^\markup { \tiny \italic "Countersubject" } f8 g8 a4. bes16 a16 |
      bes4 a4 bes8 a8 g4 |
      a2 g2 |
      c'1 |
      d'8 c'8 bes2 g4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      aes2 ees2 |
      des4 ees4 f2 |
      ees2 f2 |
      f2 d4 bes,4~ |
      bes,2 ees4 c4 |
      g4 ees'4 bes4 bes4 |
      ees'4 bes2 aes4 |
      c'8 bes8 aes4 g2 |
      f4 c8 bes,8 aes,4 des4~ |
      des2. ees4 |
      ees2 d4 bes4 |
      g4 bes,4 c8 d8 ees4 |
      aes,2 ees,4 c4 |
      ees4 aes4 f'2 |
      bes4 ees'4 bes4 g4 |
      g1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "bass" \key ees \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,4^\markup { \tiny \italic "Real answer" } d4 f2 |
      g4 f8 ees8 d4 ees4 |
      c2 bes,2 |
      c4^\markup { \tiny \italic "Subject-head fragment" } ees4 aes,2 |
      bes,4^\markup { \tiny \italic "Subject-head fragment" } d4 ees2 |
      d2 c2~ |
      c2 bes,8 aes,8 g,4 |
      f,4 g,4 c,4 f,4 |
      g,2 c2 |
      f,4^\markup { \tiny \italic "Subject-head fragment" } aes,4 bes,2 |
      ees4^\markup { \tiny \italic "Subject-head fragment" } g4 c2 |
      r1 |
      r1 |
      r1 |
      f2 bes,2 |
      g,2 aes,2 |
      ees4^\markup { \tiny \italic "Stretto subject" } g4 bes2 |
      c'4 bes8 aes8 g4 aes4 |
      f2 ees2 |
      aes,4 ees,4 aes,4 bes,4 |
      des,4. ees,8 f,4 aes,4 |
      ees2 bes,4 g,4 |
      ees,8 f,8 g,4 c,2 |
      f,2 c,2 |
      c,4 aes,4 bes,2 |
      ees1^\markup { \tiny \italic "Cadential tonic bass" } |
      ees1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
