\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "I. Fugue in C major — A conversation"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key c \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 112
      \mark \markup \box \small "Continuous exposition" c''4^\markup { \tiny \italic "Subject" } e''4 g''4 d''8 e''8 |
      f''4 e''8 d''8 c''2 |
      e''8^\markup { \tiny \italic "Countersubject" } fis''8 g''4. fis''4 g''16 fis''16 |
      e''4 d''4 e''2 |
      \mark \markup \box \small "Subject-head sequence" a'4^\markup { \tiny \italic "Subject-head fragment" } c''4 f''8 g''8 a''4 |
      g''4^\markup { \tiny \italic "Subject-head fragment" } b''4 c'''2 |
      \mark \markup \box \small "Relative-key development" f''4^\markup { \tiny \italic "Countersubject" } e''8 f''8 g''4. a''16 g''16 |
      f''4. e''8 f''2 |
      \mark \markup \box \small "Minor-coloured sequential answer" a''2 g''4^\markup { \tiny \italic "Subject-head fragment" } b''4 |
      g''2 f''4^\markup { \tiny \italic "Subject-head fragment" } a''4 |
      \mark \markup \box \small "Return to C" a''2~ a''8 g''4.~ |
      g''4. f''8 e''2 |
      \mark \markup \box \small "Stretto" e''2 d''2 |
      c''4 c''4^\markup { \tiny \italic "Stretto subject" } e''4 g''4 |
      d''8 e''8 f''4 e''8 d''8 c''4~ |
      c''4 c''8 d''8 e''4. d''8 |
      \mark \markup \box \small "Closing conversation" c''4^\markup { \tiny \italic "Subject" } e''4 g''4 d''8 e''8 |
      f''4 e''8 d''8 c''2 |
      \mark \markup \box \small "Final cadence" c''2 d''2~ |
      d''8 c''2.~^\markup { \tiny \italic "Cadential tonic arrival" } c''8 |
      c''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "bass" \key c \major \time 4/4
      r1 |
      r1 |
      g4^\markup { \tiny \italic "Real answer" } b4 d'4 a8 b8 |
      c'4 b8 a8 g2 |
      a2 d4^\markup { \tiny \italic "Subject-head fragment" } f4 |
      g2 c4^\markup { \tiny \italic "Subject-head fragment" } e4 |
      a4^\markup { \tiny \italic "Relative-key subject" } c'4 e'8 d'16 c'16 b8 c'8 |
      d'4 c'4 a2 |
      d4^\markup { \tiny \italic "Subject-head fragment" } f4 g4 b,4 |
      c4^\markup { \tiny \italic "Subject-head fragment" } e4 f2 |
      f2 g4. f8 |
      e2.~ e8 d8 |
      c4^\markup { \tiny \italic "Stretto subject" } e4 g4 d8 e8 |
      f4 e8 d8 c2 |
      d2 e2 |
      f2 e2 |
      a8^\markup { \tiny \italic "Countersubject" } b8 c'4. b4 c'16 b16 |
      a4 g4 a2 |
      a2 g4 b,4 |
      c1^\markup { \tiny \italic "Cadential tonic bass" } |
      c1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
