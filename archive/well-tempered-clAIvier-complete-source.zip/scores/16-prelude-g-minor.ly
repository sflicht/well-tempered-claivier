\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XVI. Prelude in G minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key g \minor \time 4/4
      \tempo "Andante, poi mosso" 4 = 76
      \mark \markup \box \small "Opening cell" d'''2\p ees'''4 d'''4 |
      f'''2 c'''4 a''4 |
      g''4 f''8 ees''8 g''4 bes''4 |
      d'''2 c'''4 d'''4 |
      bes''2 a''4 bes''4 |
      g''2 a''4 g''4 |
      bes''4 a''8 g''8 f''4 g''4 |
      d''8 a'8 fis'8 d'8 fis'8 a'8 d''8 a'8 |
      \mark \markup \box \small "Contrasting span" d''8\mp bes'8 d''8 f''8 bes''8 f''8 d''8 bes'8 |
      g''8 ees''8 g''8 bes''8 ees'''8 bes''8 g''8 ees''8 |
      ees''8 c''8 ees''8 g''8 c'''8 g''8 ees''8 c''8 |
      a''8 ees''8 c''8 a'8 c''8 ees''8 a''8 ees''8 |
      cis''8 a'8 cis''8 e''8 a''8 e''8 cis''8 a'8 |
      fis''8 d''8 fis''8 a''8 d'''8 a''8 fis''8 d''8 |
      a''16 fis''16 d''16 fis''16 a''16 d'''16 a''16 fis''16 d''16 fis''16 a''16 d'''16 a''16 fis''16 d''16 fis''16 |
      a''16 d'''16 a''16 fis''16 d''16 fis''16 a''16 d'''16 a''16 fis''16 d''16 fis''16 a''16 d'''16 a''16 fis''16 |
      \mark \markup \box \small "Development" g''16\mf bes''16 g''16 bes''16 d'''16 g'''16 d'''16 bes''16 g''16 bes''16 d'''16 g'''16 d'''16 bes''16 g''16 bes''16 |
      bes''16 g''16 ees''16 g''16 bes''16 ees'''16 bes''16 g''16 ees''16 g''16 bes''16 ees'''16 bes''16 g''16 ees''16 g''16 |
      g''16 ees''16 c''16 ees''16 g''16 c'''16 g''16 ees''16 c''16 ees''16 g''16 c'''16 g''16 ees''16 c''16 ees''16 |
      a''16 d'''16 a''16 fis''16 d''16 fis''16 a''16 d'''16 a''16 fis''16 d''16 fis''16 a''16 d'''16 a''16 fis''16 |
      \mark \markup \box \small "Return" f''16\mp d''16 bes'16 d''16 f''16 bes''16 f''16 d''16 bes'16 d''16 f''16 bes''16 f''16 d''16 bes'16 d''16 |
      g''2 fis''4 g''4 |
      aes''2 g''4 aes''4 |
      a''2 fis''4 a''4 |
      \mark \markup \box \small "Cadence" d'''2\p ees'''4 d'''4 |
      d'''2 ees'''4 d'''4 |
      d'''2 a''4 fis''4 |
      g''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key g \minor \time 4/4
      bes2\p d'2 |
      c'2 a2 |
      g2 bes2 |
      fis2 a2 |
      bes2 d'2 |
      ees'2 g'2 |
      bes'2 bes'2 |
      fis'4 d'4 d'4 fis'4 |
      f'4\mp d'4 d'4 f'4 |
      bes'4 g'4 ees'4 g'4 |
      g'4 ees'4 c'4 ees'4 |
      ees'4 c'4 a4 c'4 |
      e'4 cis'4 cis'4 e'4 |
      a'4 a'4 fis'4 a'4 |
      a'4 fis'4 d'4 fis'4 |
      a'4 fis'4 fis'4 a'4 |
      bes'4\mf bes'4 g'4 bes'4 |
      bes'4 g'4 ees'4 g'4 |
      g'4 ees'4 c'4 ees'4 |
      a'4 fis'4 d'4 fis'4 |
      f'4\mp d'4 bes4 d'4 |
      ees'2 g'2 |
      ees'2 aes'2 |
      fis'2 a'2 |
      bes'2\p d''2 |
      bes'2 bes'2 |
      a'2 c''2 |
      bes'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key g \minor \time 4/4
      g,1\p |
      f,1 |
      ees,1 |
      d,1 |
      g,1 |
      c,1 |
      bes,,2.~ bes,,8 c,8 |
      d,1 |
      bes,,1\mp |
      ees,2.~ ees,8 d,8 |
      c,1 |
      c,1 |
      a,,1 |
      d,1 |
      d,1 |
      d,1 |
      g,1\mf |
      ees,2.~ ees,8 d,8 |
      c,1 |
      d,1 |
      bes,,1\mp |
      c,1 |
      c,1 |
      d,1 |
      bes,,1\p |
      d,1 |
      d,1 |
      g,,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
