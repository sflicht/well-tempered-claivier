\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXII. Fugue in Bb minor — A dark procession"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a2")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key bes \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 82
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''2^\markup { \tiny \italic "Subject" } f'''4 des'''4 |
      c'''8 bes''8 aes''4 bes''4 ges''4 |
      aes''2 bes''2 |
      des'''4.^\markup { \tiny \italic "Countersubject" } c'''16 des'''16 ees'''4 f'''4 |
      ees'''8 des'''8 c'''4 des'''8 c'''8 bes''4 |
      c'''2 des'''2 |
      des'''1 |
      aes''2 ges''8 aes''8 bes''4~ |
      bes''8 aes''4. des''4 ges''4 |
      \mark \markup \box \small "Sequential episode" ges''4. aes''8 bes''2 |
      a''8 bes''8 c'''4 des'''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'''2 c'''2 |
      g''4 c'''4 f''2 |
      c''2 f''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'''2 aes''8 g''8 f''4 |
      g''4 c''4 f''2 |
      c'''2 f''2 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Exposition 4" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 5" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" ees'''2 bes''2 |
      des'''4 ges'''4 ees'''4 f'''4 |
      des'''2 ces'''2 |
      \mark \markup \box \small "Linking episode" ees'''1 |
      d'''4 bes''2. |
      \mark \markup \box \small "Development" c'''2 aes'''4 e'''4 |
      f'''2^\markup { \tiny \italic "Related-key subject" } c''''4 aes'''4 |
      g'''8 f'''8 ees'''4 f'''4 des'''4 |
      ees'''2 f'''2 |
      \mark \markup \box \small "Stretto" des'''2. f'''4 |
      ees'''2 bes''2 |
      c'''2 bes''2^\markup { \tiny \italic "Stretto subject" } |
      f'''4 des'''4 c'''8 bes''8 aes''4 |
      bes''4 ges''4 aes''2 |
      bes''2 bes''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" des'''2. f'''4~ |
      f'''1 |
      ges'''1~ |
      ges'''1~ |
      ges'''4 bes'''4 ges'''4 bes'''4 |
      ges'''1 |
      f'''4 des''''2 f'''4~ |
      f'''1 |
      \mark \markup \box \small "Gathered development" bes'''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      f''''2 des''''4 f'''4 |
      bes''2. des'''4 |
      bes''4 des'''4 des''''4 ges'''4~ |
      ges'''2. bes''4 |
      ees'''1 |
      c'''1~ |
      c'''1 |
      a''2 c'''4 a''4 |
      c'''4 a''4 c'''4 c''''4~ |
      c''''4 a'''4 c'''2~ |
      c'''1 |
      a''2 c'''2~ |
      c'''1 |
      des'''4 f'''2 des'''4~ |
      des'''2 des''''4 f'''4 |
      bes'''2. ges'''4 |
      des'''2. ges'''4 |
      \mark \markup \box \small "Final return" ges'''2 f'''2~ |
      f'''2 ees'''2 |
      des'''2 ees'''2 |
      \mark \markup \box \small "Final cadence" ees'''2 f'''2 |
      des'''1 |
      des'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'''4. c'''8 bes''2 |
      bes''2^\markup { \tiny \italic "Subject" } f'''4 des'''4 |
      c'''8 bes''8 aes''4 bes''4 ges''4 |
      aes''2 bes''2 |
      des'''4.^\markup { \tiny \italic "Countersubject" } c'''16 des'''16 ees'''4 f'''4 |
      ees'''8 des'''8 c'''4 des'''8 c'''8 bes''4 |
      c'''2 des'''2 |
      bes''4. c'''8 des'''4 bes'''4 |
      des'''2 aes'''8 ges'''8 f'''4 |
      aes''2 des''4 bes''4 |
      f''4 c'''4 bes''2 |
      bes''4. aes''8 ges''2~ |
      ges''8 f''4. bes''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''8 aes''8 ges''4 f''4 bes''4 |
      c'''4 f''4 bes''4 ees''4 |
      aes''8 ges''8 f''4 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''4 des'''2. |
      f''4 des'''2. |
      des''2 des'''2~ |
      des'''4 des''4 bes''2~ |
      bes''4 bes'2. |
      bes''1~ |
      bes''4 bes'2. |
      bes''2. f'''4 |
      des'''4 f''2. |
      des'''4 bes'''4 bes''2~ |
      bes''4 bes'4 bes''2~ |
      bes''4 bes'4 bes''2~ |
      bes''4 bes'2. |
      bes''2 ees''2~ |
      ees''1~ |
      ees''1~ |
      ees''1~ |
      ees''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''2 des''2~ |
      des''4 bes''2.~ |
      bes''4 des''2. |
      bes''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''2^\markup { \tiny \italic "Subject" } f'''4 des'''4 |
      c'''8 bes''8 aes''4 bes''4 ges''4 |
      aes''2 bes''2 |
      des'''4.^\markup { \tiny \italic "Countersubject" } c'''16 des'''16 ees'''4 f'''4 |
      ees'''8 des'''8 c'''4 des'''8 c'''8 bes''4 |
      c'''2 des'''2 |
      des'''1 |
      aes''4 c'''4 bes''2~ |
      bes''8 aes''4. ges''2 |
      ges''8 f''8 ees''4 f''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''2 des''2~ |
      des''4 bes''2. |
      ges'''4 des'''4 ges''2~ |
      ges''2 bes'4 ges''4~ |
      ges''4 ees'''4 ges''2~ |
      ges''4 bes'2 bes''4~ |
      bes''2 des''2~ |
      des''4 bes''2. |
      bes''4 f'''2 bes''4~ |
      bes''2 bes'''4 bes''4~ |
      bes''2 bes'4 ges''4~ |
      ges''4 des'''4 ges''2~ |
      ges''4 ees'''4 ges''2 |
      ees'''2. ees''4~ |
      ees''1~ |
      ees''1~ |
      ees''1~ |
      ees''2. ees'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4 f''2. |
      bes'2 bes''2~ |
      bes''4 bes'4 ges''2~ |
      ges''4 des'''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''2^\markup { \tiny \italic "Subject" } f'''4 des'''4 |
      c'''8 bes''8 aes''4 bes''4 ges''4 |
      aes''2 bes''2 |
      des''4.^\markup { \tiny \italic "Countersubject" } c''16 des''16 ees''4 f''4 |
      ees''8 des''8 c''4 des''8 c''8 bes'4 |
      c''2 des''2 |
      des''2 ees''2 |
      f''4 a''4 bes''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'''4 f''2 bes'4~ |
      bes'4 f''2. |
      des'''4 ges''2 bes'4~ |
      bes'4 ges''2. |
      ees'''4 bes''2 ees''4~ |
      ees''4 bes''2.~ |
      bes''4 des''2 des'''4~ |
      des'''4 f''2. |
      f''2 des'''2~ |
      des'''4 des''2. |
      ges''4 bes''2.~ |
      bes''4 des''2. |
      ges''2. ges'4~ |
      ges'4 ees''2. |
      c'''1~ |
      c'''4 c''2.~ |
      c''1~ |
      c''1~ |
      c''4 f''2 c'''4~ |
      c'''4 f''2 c''4~ |
      c''4 f''2 c'''4~ |
      c'''4 f''2. |
      des'''2. f''4~ |
      f''4 bes'2. |
      ges''2. bes'4~ |
      bes'4 ges''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''2^\markup { \tiny \italic "Subject" } f'''4 des'''4 |
      c'''8 bes''8 aes''4 bes''4 ges''4 |
      aes''2 bes''2 |
      des''4.^\markup { \tiny \italic "Countersubject" } c''16 des''16 ees''4 f''4 |
      ees''8 des''8 c''4 des''8 c''8 bes'4 |
      c''2 des''2 |
      des''2 ees''2 |
      c''2 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''4 bes'2 f''4~ |
      f''2 bes'2~ |
      bes'4 ges''4 des'''4 ges''4~ |
      ges''4 des'''4 ges''2~ |
      ges''4 bes'2 ges''4~ |
      ges''2 ees''4 ges'4 |
      des''2 bes''2~ |
      bes''4 des''2. |
      des''2 bes''2~ |
      bes''4 des''2 f''4 |
      ges''2. bes'4~ |
      bes'4 ges''2 des''4 |
      ees''4 bes'4 bes''2~ |
      bes''4 ees''2 bes'4 |
      c''2 ees''2~ |
      ees''4 ges''2. |
      ees''2. ees'4~ |
      ees'4 ees''2. |
      f''2. c''4~ |
      c''4 f''4 c''4 f''4~ |
      f''4 c''4 f''2~ |
      f''4 c''2. |
      bes'4 des''4 bes'2~ |
      bes'4 f''2. |
      ges''2 des'''2~ |
      des'''4 ges''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      f''2^\markup { \tiny \italic "Real answer" } c'''4 aes''4 |
      g''8 f''8 ees''4 f''4 des''4 |
      ees''2 f''2 |
      ges''4.^\markup { \tiny \italic "Countersubject" } f''16 ges''16 aes''4 bes''4 |
      aes''8 ges''8 f''4 ges''8 f''8 ees''4 |
      f''2 ges''2 |
      aes''8 g''8 f''4 c''4. des''8 |
      ees''2 des''2~ |
      des''8 c''4. f''4. ees''8 |
      des''2~ des''8 c''8 bes'4 |
      c''4 f'8 ees'8 des'4 ges'4 |
      f'4. ees'8 des'2 |
      des'2 bes'4 ees'4 |
      c''4 f'4. ees'8 des'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des''4. ees''8 f''8 ees''8 des''4 |
      ges''2 f''4. ges''8 |
      aes''2 ges''2 |
      f''4. ees''8 des''8 c''8 bes'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ges''4 des''8 ees''8 f''4 bes'4 |
      ees''4 aes'4 des'4 bes'4 |
      f''2 des''8 c''8 bes'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'2 des''2 |
      f''2 des''2 |
      ges''2 des''2 |
      ges''2 des''2 |
      ges'2. ees''4~ |
      ees''2 bes'2~ |
      bes'4 f''4 bes'2 |
      f''2. bes'4 |
      bes'2 f''2 |
      bes''2. des''4~ |
      des''2 ges'4 des''4 |
      ges''2. bes'4~ |
      bes'2 ees'4 bes'4~ |
      bes'2 ges'4 ees''4 |
      ges'2. ees''4 |
      c'''2. c''4~ |
      c''2. c'4~ |
      c'2 c''2~ |
      c''1 |
      f''1~ |
      f''1~ |
      f''1~ |
      f''4 f'2 des''4~ |
      des''2 bes''2 |
      bes'2. ges''4~ |
      ges''2 des''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''2^\markup { \tiny \italic "Real answer" } c'''4 aes''4 |
      g''8 f''8 ees''4 f''4 des''4 |
      ees''2 f''2 |
      bes''4 des''2. |
      ges'4.^\markup { \tiny \italic "Countersubject" } f'16 ges'16 aes'4 bes'4 |
      aes'8 ges'8 f'4 ges'8 f'8 ees'4 |
      f'2 ges'2 |
      aes'2 g'4 f'4 |
      g'2 f'2 |
      g'2 aes'2 |
      des'4 ges'8 aes'8 bes'4 bes''4~ |
      bes''2 aes''4 des''4 |
      ees''4 f''4 des''4 ges'4~ |
      ges'8 f'4. des'2 |
      ges'2 bes'2 |
      f''2. bes'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2 aes'8 ges'8 f'4 |
      aes'8 bes'8 c''4 bes'2 |
      f'2 bes'2 |
      f''2 c''2 |
      ees'2 aes'4 des''4~ |
      des''8 c''4. aes'2 |
      des''2 f'4. ges'8 |
      aes'2 des'4 bes'4 |
      f'2 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2 f'4 bes'4 |
      ees'4 f'4 bes'2 |
      f'2 bes'4. c''8 |
      des''2 c''2 |
      ees'4 c''4 f'2 |
      c''2 aes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ges'4 des'4 aes'4 des'4 |
      aes'4 f''4 bes''4 ees''4 |
      aes'8 ges'8 f'4 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ges''2 bes'2~ |
      bes'4 ges''4 aes''2 |
      des'''2 ges''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2 f'2 |
      bes'2 f''2 |
      bes'2 ges''4 des''4~ |
      des''2 ges''2 |
      bes'1 |
      ees''2. ges''4 |
      bes'2. f''4 |
      bes'2 f''2 |
      f''2 bes'2~ |
      bes'4 f''2 bes'4~ |
      bes'2 ges''2 |
      bes'2 ges''2 |
      bes'2 ges''2 |
      ees''2 ges''2~ |
      ges''2 ges'2~ |
      ges'2 ees''2~ |
      ees''2 ees'2 |
      c''1~ |
      c''1~ |
      c''1~ |
      c''1 |
      f''1 |
      f'2 des''2 |
      f'2 des''2~ |
      des''2 ges'2 |
      des''2 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'2^\markup { \tiny \italic "Real answer" } c''4 aes'4 |
      g'8 f'8 ees'4 f'4 des'4 |
      ees'2 f'2 |
      ges'4.^\markup { \tiny \italic "Countersubject" } f'16 ges'16 aes'4 bes'4 |
      aes'8 ges'8 f'4 ges'8 f'8 ees'4 |
      f'2 ges'2 |
      f'4. g'8 aes'2 |
      bes'4 c''4 aes'4 bes'8 aes'8 |
      g'2 aes'8 g'8 f'4 |
      bes'4. c''8 des''4 f''4 |
      c''4 f'4 bes'4 ees''4 |
      c''2 bes'2 |
      bes'2 c''4 des''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2 aes'4 ges'8 f'8 |
      ees'4 aes'4 des'4 bes'4 |
      f''2 bes'8 c''8 des''4 |
      des''2 aes'4 f'4 |
      g'4 c''4 f'4 bes4 |
      ees'2 aes'4 des''4 |
      r1 |
      r1 |
      ees''2^\markup { \tiny \italic "Related-key subject" } bes''4 ges''4 |
      f''8 ees''8 des''4 ees''4 ces''4 |
      des''2 ees''2 |
      ces''4. bes'8 aes'2 |
      f'2 ees'8 f'8 ges'4 |
      ees'4 c'4 c''2 |
      f'2 ees'4 aes'4 |
      c''2 bes'4 g'4 |
      ees'2 des'2 |
      f'4 bes'4 des''4 aes'4~ |
      aes'2 des'4 ges'4 |
      ees''2 bes'2 |
      f'2 c''2 |
      ees'4 bes'4 f''2 |
      bes'2. f'4 |
      r1 |
      des''2 bes'4 f'4~ |
      f'4 des'4 f'2 |
      bes'2 ges'2 |
      bes'2. des''4 |
      ges''2. bes'4~ |
      bes'2 ees''4 bes'4~ |
      bes'2 f''4 bes'4~ |
      bes'2 des''4 bes'4 |
      f'2. des'4~ |
      des'2 f'4 des'4~ |
      des'4 bes'4 des''4 bes'4 |
      ges''4 bes'2.~ |
      bes'2. ges'4~ |
      ges'1~ |
      ges'1~ |
      ges'1 |
      ees''4 c''4 a'4 c'4 |
      a4 c'4 a2~ |
      a4 c'4 a'4 f'4 |
      a'4 f'4 a4 a'4 |
      c''2 a'4 c''4 |
      a'1 |
      bes'1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      f''2 bes'2 |
      des''1 |
      bes'2. des''4 |
      des''2 f'4 bes'4 |
      f'2 bes4 ges'4 |
      des''2 bes'4 ees''4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'2^\markup { \tiny \italic "Real answer" } c''4 aes'4 |
      g'8 f'8 ees'4 f'4 des'4 |
      ees'2 f'2 |
      ges'4.^\markup { \tiny \italic "Countersubject" } f'16 ges'16 aes'4 bes'4 |
      aes'8 ges'8 f'4 ges'8 f'8 ees'4 |
      f'2 ges'2 |
      aes'2~ aes'8 g'8 f'4 |
      g'2 aes'8 g'8 f'4 |
      g'2 aes'2~ |
      aes'8 ges'2 aes'8 bes'4 |
      a'4 f'4. ees'8 des'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'8 f'8 ges'4 des''4 ges''4 |
      des''2 aes'4 f'4 |
      bes'2 ges'4 ces''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'4 f'2. |
      c'4 ees'4 bes'4 ees'4 |
      aes'4 c''4 f''4 des''4 |
      aes'2. c''4 |
      ees''4 bes'4 aes'4 f'4 |
      bes'4 f'4 ges'4 bes'4 |
      r1 |
      f'4 bes'2. |
      f'2. bes'4 |
      ges'4 bes'2 ges'4 |
      des'4 ges'2 des'4 |
      ees'4 bes'2 ees''4 |
      ges'4 bes'2 ees''4 |
      bes'4 f'2 bes'4 |
      f'4 bes'2 f'4 |
      f'4 bes'2. |
      f'4 des'2. |
      bes'2. ges'4~ |
      ges'4 bes'2.~ |
      bes'4 ees''2 bes'4 |
      ees'4 bes'2 ges'4~ |
      ges'4 ees''2. |
      ges'2. ees''4 |
      ees'2. c''4~ |
      c''4 c'2. |
      c''1 |
      f'1~ |
      f'1~ |
      f'1~ |
      f'2. bes'4 |
      f'2. bes4~ |
      bes4 ges'4 bes'2~ |
      bes'4 des''2 bes'4 |
      bes'4 des''4 aes'4 des''4 |
      f''4 c''4 ees'4 bes4 |
      des'4 f'4 bes'4 ges'4 |
      ees'2 c''4 f''4 |
      bes'4 f'2 des'4~ |
      des'4 f'2 bes'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'2^\markup { \tiny \italic "Real answer" } c''4 aes'4 |
      g'8 f'8 ees'4 f'4 des'4 |
      ees'2 f'2 |
      ges'4.^\markup { \tiny \italic "Countersubject" } f'16 ges'16 aes'4 bes'4 |
      aes'8 ges'8 f'4 ges'8 f'8 ees'4 |
      f'2 ges'2 |
      aes'2~ aes'8 bes'8 c''4 |
      ees'2 des'2 |
      c'4. bes8 aes2 |
      bes1 |
      a2 bes8 c'8 des'4 |
      ges'8 f'8 ees'4 des'4 bes4~ |
      bes2 ees'4 aes'4 |
      des'4 bes4 ges'4 ees'4 |
      ees'4. des'8 ces'8 bes8 aes4 |
      f'4 bes'2 ees''4 |
      g'4 c'2. |
      f'2 c'4 f'4 |
      c'2 f'4 g'4~ |
      g'4 ees'4 bes'4 des''4 |
      f'4 des'4 f'4 aes'4~ |
      aes'2 f'4 ees'4 |
      c'4 ees'4 bes'4 f'4~ |
      f'2 aes'2 |
      ges'4 des'4 f'4 aes'4 |
      f'4 bes'2 des''4 |
      r1 |
      des'4 f'2 bes'4~ |
      bes'4 f'2 des'4~ |
      des'4 ges'2 bes'4~ |
      bes'4 ges'2 bes'4 |
      ges'4 ees'4 ges'4 ees'4 |
      ges'4 ees'4 ges'4 bes'4 |
      f'4 des'2 bes4 |
      des'4 f'2 bes'4 |
      bes'4 des''2 bes'4~ |
      bes'4 f'2 bes'4~ |
      bes'4 des'2 ges'4~ |
      ges'4 des'2 ges'4~ |
      ges'4 bes2 ees'4~ |
      ees'4 ges'2 ees'4~ |
      ees'2. c'4~ |
      c'4 ees'2.~ |
      ees'4 c''2 ees''4 |
      c''2. c'4~ |
      c'2. f'4~ |
      f'1~ |
      f'1~ |
      f'1~ |
      f'2 des'4 bes4 |
      des'4 f'2 bes'4~ |
      bes'4 ges'2 des'4 |
      ges'4 bes'2 ges'4 |
      des'2 f'2~ |
      f'4 aes'4 ges'4 bes'4 |
      f'4 des'4 ges'4 bes'4 |
      ges'4 bes'4 f'2~ |
      f'4 bes'2 f'4~ |
      f'4 des'2 f'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "treble" \key bes \minor \time 4/4
      bes2^\markup { \tiny \italic "Subject" } f'4 des'4 |
      c'8 bes8 aes4 bes4 ges4 |
      aes2 bes2 |
      des'4.^\markup { \tiny \italic "Countersubject" } c'16 des'16 ees'4 f'4 |
      ees'8 des'8 c'4 des'8 c'8 bes4 |
      c'2 des'2 |
      ees'2 des'4. ees'8 |
      f'2 ees'2 |
      des'8 ees'8 f'4 ees'2 |
      f'4. g'8 aes'2 |
      bes'8 aes'8 g'4 f'2 |
      g'8 f'8 ees'4 des'2 |
      des'1 |
      ees'4 c''4 bes'4 ees'8 des'8 |
      c'2 bes4. c'8 |
      des'4 bes'2. |
      f'4 c'4 bes2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes8 c'8 des'2 f'4 |
      des'2~ des'8 ees'8 f'4 |
      ees'8 des'8 c'4 ees'8 f'8 ges'4 |
      des'4 c'4 des'4 ges'4 |
      des'8 ees'8 f'4 ees'4 aes'4 |
      ees'4 g'4 aes'8 g'8 f'4 |
      ees'8 f'8 g'4 f'8 ees'8 des'4 |
      des'8 c'8 bes2 ees'4 |
      bes8 c'8 des'4 c'4 des'4 |
      aes8 bes8 c'4 bes4 ees'8 des'8 |
      c'8 bes8 aes4 des'4 ges'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes8 c'8 des'2 f'4 |
      ees'8 des'8 c'4 des'4 ees'4 |
      c'4 f'4 des'8 c'8 bes4~ |
      bes8 aes8 des'4 c'2 |
      ees'8 f'8 g'4 aes'8 g'8 f'4 |
      c'8 des'8 ees'4 des'8 ees'8 f'4 |
      des'2~ des'8 c'8 bes4 |
      c'4 f'4 des'4 ees'4 |
      aes'8 ges'8 f'4 bes8 c'8 des'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'4 des'4 aes4 des'4 |
      aes8 bes8 c'4 des'4 ees'4 |
      c'4 f'4 des'8 c'8 bes4 |
      des'8 ees'8 f'4 ees'4 c'4 |
      bes4 c'4 f'4 bes'4 |
      g'8 f'8 ees'4 des'8 ees'8 f'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ges'8 f'8 ees'2 aes'4 |
      bes'2~ bes'8 aes'8 ges'4 |
      ees''4 aes'2 g'4 |
      bes4 f'4 g'4 aes'4 |
      ees'2 bes2 |
      g4 c'4 f'4 des'4 |
      des'4 bes4 aes4 des'4 |
      ees'4 c'4 f'4 ges'4 |
      ees'4 c'4 des'4 bes4 |
      c'4 des'4 f'4 aes'4 |
      ees'4 ges'4 f'4 c'4 |
      des'4 bes4 ees'4 f'4 |
      r1 |
      des'4 bes2 des'4 |
      bes4 des'2 f'4 |
      des'4 bes2 des'4 |
      bes4 des'2 ges'4 |
      ees'4 ges'4 ees'4 ges'4 |
      ees'4 ges'2 ees'4 |
      des'4 bes2 des'4 |
      bes4 des'2 f'4 |
      f'4 des'4 bes4 des'4 |
      bes4 des'2 bes4~ |
      bes4 ges2 bes4 |
      des'4 ges'4 bes'4 ges'4 |
      bes'4 ges'2 ees'4 |
      ges'4 ees'2 ges'4 |
      ees'4 c'2 ees'4 |
      ges'4 ees'4 c'4 ees'4~ |
      ees'2. c'4~ |
      c'4 ees'2 c''4 |
      c'1~ |
      c'1~ |
      c'1~ |
      c'4 f'2.~ |
      f'4 bes2 des'4 |
      bes4 des'4 bes4 des'4~ |
      des'4 bes2 des'4~ |
      des'4 ges'2 bes'4 |
      ges'4 des'4 c'4 des'4 |
      aes4 c'4 ees'4 ges'4 |
      f'4 aes'4 ges'4 ees'4 |
      ges'4 ees'4 c'2 |
      bes4 des'2 f'4 |
      des'4 bes2 des'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "treble" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2^\markup { \tiny \italic "Subject" } f'4 des'4 |
      c'8 bes8 aes4 bes4 ges4 |
      aes2 bes2 |
      des'4.^\markup { \tiny \italic "Countersubject" } c'16 des'16 ees'4 f'4 |
      ees'8 des'8 c'4 des'8 c'8 bes4 |
      c'2 des'2 |
      bes4. c'8 des'2 |
      bes4. c'8 des'8 c'8 bes4 |
      c'4 f4 ees2 |
      des8 ees8 f4 bes2~ |
      bes8 aes4. ees'8 des'8 c'4 |
      ees'2 des'2~ |
      des'8 c'4 bes8 aes2 |
      bes4 des'2 ees'4 |
      des'8 c'8 bes4 f2 |
      aes2 ges8 aes8 bes4 |
      aes2 ges2 |
      ges4 des'4 ees'4. des'8 |
      c'8 bes8 a4 bes2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'4 des'4 aes'4 ges'8 f'8 |
      ees'8 des'8 c'4 des'8 c'8 bes4 |
      aes8 bes8 c'4 des'2 |
      des'8 ees'8 f'4 ees'8 des'8 c'4 |
      bes4 c'4 f'2 |
      ees'8 des'8 c'4 f'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ces'4 ees'4 f'4 ees'4 |
      bes4 des'4 ces'2 |
      bes4 des'4 ges'2 |
      ees'8 des'8 ces'4 ees'2 |
      f'4 bes4 ees'2 |
      g'4 ees'4 c'4 g4 |
      bes4 aes4 c'2~ |
      c'4 ees'4 des'2 |
      c'4 g4 bes2 |
      des'1 |
      aes4 c'4 des'4 ees'4~ |
      ees'2 des'2 |
      f'4 aes'2 f'4 |
      ees'4 des'4 c'2 |
      bes2 ges4 f4 |
      r1 |
      f'2. des'4~ |
      des'1 |
      des''2. des'4~ |
      des'1 |
      bes4 ges4 bes4 ges4 |
      bes1 |
      des'4 f'2 des'4~ |
      des'1 |
      des'4 bes4 des'4 f'4 |
      des'4 bes4 des'2 |
      bes4 des'4 ges'2 |
      des'4 bes4 des'4 bes4 |
      ges4 bes4 ees'2 |
      bes4 ges4 bes4 ees'4 |
      ges'4 ees'4 ges'2 |
      ees'4 c'4 ees'4 c'4 |
      ees'2 c'2 |
      ees'4 c'4 ees'4 c'4~ |
      c'1~ |
      c'1~ |
      c'1~ |
      c'2 f'2~ |
      f'4 des'4 f'2 |
      des'4 bes4 des'2 |
      bes4 des'4 bes2 |
      des'4 bes4 des'2 |
      bes2^\markup { \tiny \italic "Subject" } f'4 des'4 |
      c'8 bes8 aes4 bes4 ges4 |
      aes2 bes2 |
      bes2 a4 c'4 |
      des'1 |
      des'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2^\markup { \tiny \italic "Subject" } f'4 des'4 |
      c'8 bes8 aes4 bes4 ges4 |
      aes2 bes2 |
      des'4.^\markup { \tiny \italic "Countersubject" } c'16 des'16 ees'4 f'4 |
      ees'8 des'8 c'4 des'8 c'8 bes4 |
      c'2 des'2 |
      bes4. c'8 des'2 |
      aes2 ges2 |
      f8 ges8 aes4 ges2 |
      aes4. bes8 c'2 |
      bes8 aes8 g4 f2 |
      g2 f2 |
      des'8 c'8 bes4 f4 des'4 |
      ees'4 aes4 ges2 |
      f4. ees8 des2 |
      ges8 aes8 bes4 f2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2 c'4 bes4 |
      c'2 bes2 |
      c'8 bes8 aes4 des'2 |
      aes4. bes8 c'2 |
      g2 f4 bes8 aes8 |
      g8 f8 ees4 aes2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2 c'4 bes4 |
      c'2 bes2 |
      aes2 des'2 |
      aes4. bes8 c'2 |
      g2 f2 |
      ees8 f8 g4 aes2 |
      r1 |
      r1 |
      ges2 bes2 |
      f4 ges4 ces'2 |
      ges4 bes4 ees'2 |
      ges2 aes4 ees4 |
      bes4. aes8 ges2 |
      r1 |
      r1 |
      r1 |
      r1 |
      f2 aes2 |
      c'2 bes2 |
      aes2 des'2 |
      c'4 aes4 c'2 |
      bes2 c'2 |
      f'4 des'4 bes2 |
      r1 |
      bes2 des'4 bes4 |
      des'2 bes4 des'4 |
      bes2 des'4 bes4 |
      ges4 bes4 ges2 |
      bes2 ees'2 |
      bes2 ges2 |
      bes2 des'4 f'4 |
      des'2 bes2 |
      bes4 f4 bes2 |
      des'2 bes4 des'4~ |
      des'4 bes4 ges2 |
      bes2 ges2~ |
      ges4 ees4 ges4 bes4 |
      ges2 ees2~ |
      ees4 ges4 ees4 ges4~ |
      ges2 ees4 c'4~ |
      c'2 ees'2~ |
      ees'2 c'2~ |
      c'1~ |
      c'1~ |
      c'1~ |
      c'2 f2~ |
      f4 bes4 des'2 |
      f'2 des'4 bes4~ |
      bes2 des'4 bes4~ |
      bes2 ges2 |
      ges4 bes4 c'4 bes4 |
      c'2 bes2 |
      aes2 ees'2 |
      bes2 c'2 |
      f'4 des'4 bes4 des'4 |
      bes2 des'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2^\markup { \tiny \italic "Subject" } f'4 des'4 |
      c'8 bes8 aes4 bes4 ges4 |
      aes2 bes2 |
      des4.^\markup { \tiny \italic "Countersubject" } c16 des16 ees4 f4 |
      ees8 des8 c4 des8 c8 bes,4 |
      c2 des2 |
      ees8 f8 ges4 f4 ges4 |
      aes2 ges2 |
      f8 ges8 aes4 ges2 |
      f8 g8 aes2. |
      bes4 ees'4 des'2~ |
      des'8 c'8 g4 f2 |
      ges4. f8 ees2 |
      c2 bes,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ges8 aes8 bes4 f4 bes4 |
      ees'4 f'4 des'8 c'8 bes4 |
      f4 c'4 bes2 |
      aes8 g8 f4 aes2 |
      bes8 aes8 g4 aes4 bes4 |
      ees8 des8 c4 f2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c4 ees2 g,4 |
      f,4 aes,4 ees4 c4~ |
      c4 g,4 bes,4 g4 |
      c'4 ees'4 bes2 |
      bes4 f2. |
      aes2 des'4 bes4 |
      ees4 aes4 f2 |
      aes2 f2 |
      bes,4 des4 aes2 |
      des4 f4 bes2 |
      r1 |
      f4 des4 f2 |
      des4 f4 bes2~ |
      bes4 ges4 bes2 |
      des'4 bes4 des'4 bes4~ |
      bes4 ees'4 bes2~ |
      bes4 ges4 bes4 ges4 |
      des2 f2 |
      bes4 f4 bes2 |
      des4 f4 des2 |
      f2 bes2 |
      des4 ges4 bes2~ |
      bes4 ges2 bes4~ |
      bes2 ges2~ |
      ges4 bes2 ees4~ |
      ees2 c2 |
      ees4 c'2. |
      ees2 c'2~ |
      c'4 ees4 c'2~ |
      c'4 f2.~ |
      f1~ |
      f1~ |
      f1~ |
      f2 bes2~ |
      bes4 f4 bes2 |
      des2 ges2 |
      bes4 ges4 bes2 |
      des'4 bes4 aes4 f4 |
      aes2 ees2 |
      aes4 f4 ees2 |
      ees4 bes,4 f2 |
      des'4 bes4 des'4 bes4 |
      f2 bes2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2^\markup { \tiny \italic "Subject" } f'4 des'4 |
      c'8 bes8 aes4 bes4 ges4 |
      aes2 bes2 |
      des4.^\markup { \tiny \italic "Countersubject" } c16 des16 ees4 f4 |
      ees8 des8 c4 des8 c8 bes,4 |
      c2 des2 |
      ees8 f8 ges4 f4 ges4 |
      aes2 ges2 |
      f8 ges8 aes4 ges2 |
      f8 g8 aes2. |
      ees2 aes8 g8 f4 |
      g2 f2 |
      des4 ges2. |
      f1 |
      ges2 f4 ges4 |
      bes4 des4 aes4 ces'4 |
      ges'4 bes4 ees4 ges4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f2 des4 aes4~ |
      aes4 ees4 des4 bes4 |
      ees'4 aes4 des4 f4~ |
      f2 c4 f4 |
      bes4 des4 aes,4 f4~ |
      f2 ees4 bes4 |
      r1 |
      bes4 f4 des2~ |
      des4 bes,4 des4 bes,4~ |
      bes,4 des2 ges4~ |
      ges2 bes2~ |
      bes4 ees2 bes,4~ |
      bes,4 ees4 bes2~ |
      bes4 des'4 bes4 f4~ |
      f4 des4 f4 des4 |
      des2 f2~ |
      f4 bes,4 f4 des'4~ |
      des'4 ges2 des4~ |
      des2 ges2~ |
      ges2 bes4 ees4~ |
      ees4 bes,4 ees2~ |
      ees4 c'2 ees4~ |
      ees2 c'2~ |
      c'4 ees2.~ |
      ees4 c'2.~ |
      c'2 f2~ |
      f1~ |
      f1~ |
      f1~ |
      f2 bes,4 f4~ |
      f4 bes4 f4 des'4~ |
      des'4 ges4 des4 ges4~ |
      ges4 des4 ges4 des4 |
      des4 bes4 f2 |
      c4 f4 bes4 ees'4 |
      aes2 ees4 ges4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 16" shortInstrumentName = "V16" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f2^\markup { \tiny \italic "Real answer" } c'4 aes4 |
      g8 f8 ees4 f4 des4 |
      ees2 f2 |
      ges4.^\markup { \tiny \italic "Countersubject" } f16 ges16 aes4 bes4 |
      aes8 ges8 f4 ges8 f8 ees4 |
      f2 ges2 |
      ges4. f8 ees2 |
      c8 bes,8 a,4 bes,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f8 g8 aes4 c'2 |
      bes4 c'8 bes8 aes4 bes8 aes8 |
      g8 f8 ees4 aes8 g8 f4 |
      f4 ges4 f4 ges4~ |
      ges4 bes,4 c4 bes,4 |
      c4 f4 bes4 ees4 |
      aes,8 ges,8 f,4 bes,8 c8 des4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'4. ees'8 f'2 |
      c'4 f'4 des'8 c'8 bes4 |
      aes8 bes8 c'4 bes8 aes8 ges4 |
      des8 ees8 f4 ees4 aes4 |
      ees2 des8 ees8 f4 |
      ees8 des8 c4 f8 g8 aes4 |
      bes8 aes8 ges4 f4 bes4 |
      ees4 f4 bes,2 |
      f8 ges8 aes4 des'8 c'8 bes4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ges8 aes8 bes4 aes4 des'4 |
      aes2 des'4 ees'4 |
      c'2 bes4 ges4 |
      des'4 aes2. |
      ees2 aes,4 bes,4 |
      ees2 des8 ees8 f4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 des4 c4 f4 |
      bes,4 ees4 aes,4 f4 |
      c2 aes4 f4 |
      r1 |
      r1 |
      ces'2 bes2~ |
      bes2 aes2 |
      ges4 f4 ees2 |
      ees1 |
      bes,4 f4 ges2 |
      g4 aes4 ees4 c4 |
      bes,4 des4 c2 |
      ees4 g4 f4 bes,4 |
      ees4 c4 bes,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,4 des2 f,4~ |
      f,4 bes,2. |
      des2 ges2~ |
      ges4 des4 bes,2 |
      ees2. bes4~ |
      bes4 ees2. |
      f2 des2~ |
      des4 bes,2 des4 |
      des2 des'4 f4~ |
      f4 bes2. |
      des'2 bes2 |
      des2 bes,4 des4 |
      ges,4 ges4 ees4 ges4 |
      bes1 |
      ges2. ees4 |
      c4 ees,4 ges,4 ees,4 |
      c4 ees2.~ |
      ees1 |
      c2 f4 a4 |
      c4 a,4 c2 |
      f4 c'2 a4 |
      f2 c2 |
      f,4 des2 f4~ |
      f4 des4 f4 des4~ |
      des4 ges2 bes4 |
      ges4 bes,2. |
      bes,4 des,4 aes,4 f4~ |
      f4 aes,4 ees4 bes4 |
      des2 bes2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 17" shortInstrumentName = "V17" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f2^\markup { \tiny \italic "Real answer" } c'4 aes4 |
      g8 f8 ees4 f4 des4 |
      ees2 f2 |
      des4. c8 bes,2 |
      ges,4.^\markup { \tiny \italic "Countersubject" } f,16 ges,16 aes,4 bes,4 |
      aes,8 ges,8 f,4 ges,8 f,8 ees,4 |
      f,2 ges,2 |
      bes,2 ees4 bes,4 |
      a,4 f,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,8 g,8 aes,4 ees4 c4 |
      g,4 c4 f,4 bes,4 |
      ees2 aes4 des'4 |
      ges4 des4 aes,4 f,4 |
      ees,8 des,8 c,4 des,8 c,8 bes,,4 |
      c,4 f,4 des4 ges4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,2 f2~ |
      f4 bes,4 f,4 des4~ |
      des2 bes,4 ges4~ |
      ges4 bes,2 ges,4~ |
      ges,2 ees2~ |
      ees4 bes,4 ees,4 bes,4~ |
      bes,2 f,4 des4 |
      f2 des2 |
      bes,2 f,4 des4~ |
      des4 f4 bes,2~ |
      bes,4 ges4 des2~ |
      des4 ges,4 des,4 bes,4~ |
      bes,4 ees,4 bes,2~ |
      bes,4 ees2 ges,4~ |
      ges,2 ees4 c'4~ |
      c'2 c2~ |
      c2. c'4~ |
      c'2 c2~ |
      c1~ |
      c1~ |
      c1~ |
      c2. f4~ |
      f2. bes,4~ |
      bes,2 des,4 bes,4~ |
      bes,2 ges,4 des4~ |
      des2 ges,4 des4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 18" shortInstrumentName = "V18" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,2^\markup { \tiny \italic "Real answer" } c4 aes,4 |
      g,8 f,8 ees,4 f,4 des,4 |
      ees,2 f,2 |
      ges,4.^\markup { \tiny \italic "Countersubject" } f,16 ges,16 aes,4 bes,4 |
      aes,8 ges,8 f,4 ges,8 f,8 ees,4 |
      f,2 ges,2 |
      bes,2 a,4 bes,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f2 c2 |
      g4 c8 bes,8 aes,4 f4 |
      c2 f,8 g,8 aes,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,2 bes,2 |
      f2. bes,4 |
      des,2. bes,4~ |
      bes,2 ges4 bes,4~ |
      bes,2 ees,2 |
      bes,2 ges4 bes,4 |
      des,2. bes,4~ |
      bes,2 f,4 des4 |
      f4 bes,2 f,4~ |
      f,2 des2 |
      des,2 bes,2 |
      ges,2 bes,,4 ges,4~ |
      ges,2 ees4 ges,4~ |
      ges,2 ees2 |
      ees,2 c2~ |
      c1 |
      c,1 |
      c1~ |
      c1~ |
      c1~ |
      c1~ |
      c2. f,4~ |
      f,1 |
      bes,2. des,4~ |
      des,2 des4 ges,4~ |
      ges,2 des2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 19" shortInstrumentName = "V19" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,2^\markup { \tiny \italic "Real answer" } c4 aes,4 |
      g,8 f,8 ees,4 f,4 des,4 |
      ees,2 f,2 |
      bes,4. aes,8 ges,2 |
      f,4. ees,8 des,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des2 f,2~ |
      f,2 des2 |
      ges,2. des4 |
      ges,2 des4 ges,4~ |
      ges,2 bes,,2 |
      ges,2 bes,,2 |
      bes,2. des,4~ |
      des,2 bes,2 |
      des2 f,4 bes,4~ |
      bes,2 f,2 |
      bes,2. des,4~ |
      des,2 bes,2 |
      ees,2 bes,,2 |
      ges,2. bes,4 |
      ees2 ges,2 |
      ees2. ees,4~ |
      ees,2 ees2 |
      ees,1 |
      c2. f,4~ |
      f,2 c2 |
      f,2 c,4 f,4~ |
      f,2 f2 |
      des4 bes,4 f,2~ |
      f,4 des2. |
      ges,4 bes,2. |
      des,2 bes,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 20" shortInstrumentName = "V20" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,2^\markup { \tiny \italic "Real answer" } c4 aes,4 |
      g,8 f,8 ees,4 f,4 des,4 |
      ees,2 f,2 |
      ges,4. f,8 ees,2 |
      f,4. ees,8 des,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des,2 bes,2 |
      des,2 bes,4 des,4~ |
      des,2 bes,2 |
      des,2. bes,4~ |
      bes,2 ges2 |
      bes,2. bes,,4~ |
      bes,,2 bes,2 |
      des,2. bes,4 |
      bes,2 des,4 bes,4 |
      des,2. bes,4~ |
      bes,2 des,2 |
      ges,,2. ges,4~ |
      ges,2 bes,,4 ges,4 |
      bes,,2 ges,2 |
      ees2. ees,4~ |
      ees,2 ees2~ |
      ees4 ees,2.~ |
      ees,1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des,2 bes,2 |
      des,1 |
      bes,2. bes,,4~ |
      bes,,2 ges,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 21" shortInstrumentName = "V21" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,,2^\markup { \tiny \italic "Subject" } f,4 des,4 |
      c,8 bes,,8 aes,,4 bes,,4 ges,,4 |
      aes,,2 bes,,2 |
      bes,,4 ges,2. |
      f,4. ees,8 des,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,,4 f,2 des4 |
      des,2. bes,4~ |
      bes,4 des,2. |
      bes,4 des,2. |
      bes,1 |
      bes,,1~ |
      bes,,4 bes,2. |
      bes,,4 f,2. |
      bes,,2. f,4~ |
      f,4 des2 des,4~ |
      des,2. bes,4~ |
      bes,2 bes,,2~ |
      bes,,4 ges,2.~ |
      ges,4 bes,,2 ges,4~ |
      ges,2. ges,,4~ |
      ges,,4 ees,2.~ |
      ees,2. ees4~ |
      ees4 ees,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,,4 f,2. |
      des2. des,4~ |
      des,2 bes,2~ |
      bes,4 des,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 22" shortInstrumentName = "V22" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,2~ bes,8 aes,8 ges,4 |
      bes,,2^\markup { \tiny \italic "Subject" } f,4 des,4 |
      c,8 bes,,8 aes,,4 bes,,4 ges,,4 |
      aes,,2 bes,,2 |
      bes,,8 aes,,8 ges,,2 ees,4 |
      f,4. ees,8 des,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des,2. bes,4~ |
      bes,4 des,2.~ |
      des,4 bes,2 des,4~ |
      des,4 bes,2 bes,,4~ |
      bes,,4 bes,2 bes,,4~ |
      bes,,4 bes,2. |
      bes,,2. bes,4~ |
      bes,4 bes,,2. |
      bes,,4 bes,2 des,4~ |
      des,2. des4~ |
      des4 des,2 ges,,4~ |
      ges,,4 ges,2. |
      ges,,2. ees,4~ |
      ees,1~ |
      ees,4 ees,,2 ees,4~ |
      ees,2 ees,,2~ |
      ees,,4 ees,2.~ |
      ees,1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des,2. bes,4~ |
      bes,4 des,2.~ |
      des,4 bes,2 des,4~ |
      des,2. ges,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 23" shortInstrumentName = "V23" } {
      \clef "bass" \key bes \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,,2^\markup { \tiny \italic "Subject" } f,4 des,4 |
      c,8 bes,,8 aes,,4 bes,,4 ges,,4 |
      aes,,2 bes,,2 |
      bes,,8 aes,,8 ges,,4 f,,4 bes,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ces,4.^\markup { \tiny \italic "Countersubject" } bes,,16 ces,16 des,4 ees,4 |
      des,8 ces,8 bes,,4 ces,8 bes,,8 aes,,4 |
      bes,,2 ces,2 |
      ces,1 |
      bes,,4 d,,4 ees,,4. des,,8 |
      c,,4 aes,,4 c,2 |
      des,4.^\markup { \tiny \italic "Countersubject" } c,16 des,16 ees,4 f,4 |
      ees,8 des,8 c,4 des,8 c,8 bes,,4 |
      c,2 des,2 |
      bes,,2^\markup { \tiny \italic "Stretto subject" } f,4 des,4 |
      c,8 bes,,8 aes,,4 bes,,4 ges,,4 |
      aes,,2 bes,,2 |
      aes,,4 f,,2. |
      ges,,4 bes,,4 f,,2 |
      des,,2 ees,,4 des,,4 |
      r1 |
      bes,,1~ |
      bes,,1~ |
      bes,,1~ |
      bes,,1 |
      ees,,1~ |
      ees,,1 |
      bes,,1~ |
      bes,,1 |
      bes,,1~ |
      bes,,1 |
      ges,,1~ |
      ges,,1 |
      ees,,1~ |
      ees,,1~ |
      ees,,1~ |
      ees,,1 |
      c,,1~ |
      c,,1 |
      f,,1~ |
      f,,1~ |
      f,,1~ |
      f,,1 |
      bes,,1~ |
      bes,,1 |
      ges,,1~ |
      ges,,1 |
      ges,,4.^\markup { \tiny \italic "Countersubject" } f,,16 ges,,16 aes,,4 bes,,4 |
      aes,,8 ges,,8 f,,4 ges,,8 f,,8 ees,,4 |
      f,,2 ges,,2 |
      ges,,2 f,,4 a,,4 |
      bes,,1 |
      bes,,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
