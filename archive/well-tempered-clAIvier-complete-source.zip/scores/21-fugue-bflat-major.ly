\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXI. Fugue in Bb major — Many windows"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a2")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key bes \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 116
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'''2 c'''2 |
      bes''4^\markup { \tiny \italic "Subject" } d'''4 g'''2 |
      f'''8 g'''8 a'''4 bes'''8 a'''8 g'''4 |
      ees'''4 c'''4 bes''2 |
      d'''4^\markup { \tiny \italic "Countersubject" } c'''4 f'''4. g'''16 f'''16 |
      e'''8 f'''8 g'''4 a'''4 f'''4 |
      d'''4 e'''4 d'''2 |
      f'''4 c'''4 g'''4 c'''4 |
      d'''2.~ d'''8 ees'''8 |
      f'''4. ees'''8 d'''2~ |
      d'''8 c'''4. g''2 |
      \mark \markup \box \small "Sequential episode" g''2 f''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4. g''8 f''2 |
      c'''2 f'''2 |
      bes''2 f''2 |
      bes''4. a''8 g''4 bes''4 |
      f''2. bes''4 |
      ees''2 bes''2 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 4" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Exposition 5" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" a'''4. g'''8 f'''2 |
      g'''2 f'''2~ |
      f'''4 c'''4 f'''4. e'''8 |
      \mark \markup \box \small "Linking episode" d'''2 c'''4. d'''8 |
      \mark \markup \box \small "Development" ees'''4^\markup { \tiny \italic "Related-key subject" } g'''4 c''''2 |
      bes'''8 c''''8 d''''4 ees''''8 d''''8 c''''4 |
      aes'''4 f'''4 ees'''2 |
      d'''2.~ d'''8 ees'''8 |
      f'''4 ees'''4 bes''2~ |
      bes''4 f''4 g''2 |
      \mark \markup \box \small "Stretto" g''4 a''4 bes''4 bes'''4 |
      a'''8 bes'''8 c''''4 g'''2 |
      g''8 f''8 ees''4 bes''4^\markup { \tiny \italic "Stretto subject" } d'''4 |
      g'''2 f'''8 g'''8 a'''4 |
      bes'''8 a'''8 g'''4 ees'''4 c'''4 |
      bes''2 bes''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" f'''1~ |
      f'''2 d'''4 f'''4 |
      g'''1~ |
      g'''1 |
      bes'''2 g'''2 |
      bes'''2. g'''4 |
      f'''2. d'''4~ |
      d'''1 |
      \mark \markup \box \small "Gathered development" bes''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } d'''2~ |
      d'''1 |
      bes''4 d'''4 d''''4 bes'''4 |
      g'''4 bes'''4 d'''2 |
      ees'''4 bes''4 ees'''4 bes''4~ |
      bes''4 bes'''4 g'''2~ |
      g'''2. ees'''4 |
      g'''2 ees'''2~ |
      ees'''1 |
      ees''''2 c''''4 ees'''4 |
      f'''4 c'''2 f''4 |
      a''1 |
      c'''1~ |
      c'''2 f''2 |
      d'''1~ |
      d'''2 bes''4 f'''4 |
      g'''4 d'''2 bes''4 |
      g''4 bes''4 bes'''4 d'''4 |
      \mark \markup \box \small "Final return" d'''1 |
      f'''4 ees'''4 d'''2 |
      ees'''4 f'''4 ees'''2 |
      \mark \markup \box \small "Final cadence" ees'''2 c'''2 |
      d'''1 |
      d'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'''2 d'''4. c'''8 |
      bes''4^\markup { \tiny \italic "Subject" } d'''4 g'''2 |
      f'''8 g'''8 a'''4 bes'''8 a'''8 g'''4 |
      ees'''4 c'''4 bes''2 |
      d'''4^\markup { \tiny \italic "Countersubject" } c'''4 f'''4. g'''16 f'''16 |
      e'''8 f'''8 g'''4 a'''4 f'''4 |
      d'''4 e'''4 d'''2 |
      d'''4. c'''8 bes''2 |
      f'''2 bes''2~ |
      bes''4 ees'''4 d'''2 |
      bes'''2 ees'''2 |
      c'''2 bes''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g''4 d'''8 c'''8 bes''2 |
      f''4 c'''4 f''4 bes''4 |
      ees''2 bes''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'''2 d''2~ |
      d''4 bes''2.~ |
      bes''4 g'''4 bes''2~ |
      bes''4 g'''2. |
      bes''2 bes'2 |
      bes''2 bes'2~ |
      bes'4 bes''2. |
      d''4 d'''2. |
      f''4 bes'4 f''2~ |
      f''4 bes'4 f''2 |
      g''4 d''2. |
      bes''1 |
      ees''2 bes''2~ |
      bes''4 g'''2. |
      c'''4 ees'''2.~ |
      ees'''4 g''2. |
      c'''1~ |
      c'''1 |
      f''1 |
      c''2. f''4~ |
      f''2 c''2 |
      f''2 c''2 |
      d''4 bes''2. |
      d''1 |
      g''2 d''2~ |
      d''2 d'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4^\markup { \tiny \italic "Subject" } d'''4 g'''2 |
      f'''8 g'''8 a'''4 bes'''8 a'''8 g'''4 |
      ees'''4 c'''4 bes''2 |
      d''4^\markup { \tiny \italic "Countersubject" } c''4 f''4. g''16 f''16 |
      e''8 f''8 g''4 a''4 f''4 |
      d''4 e''4 d''2 |
      d''2 ees''2 |
      f''8 g''8 a''4 bes''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4 d''4 bes''8 a''8 g''4 |
      c''4 f''4 d'''4 g''4~ |
      g''4 c''4 g''8 a''8 bes''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'''2. f''4~ |
      f''2 d'''2 |
      g''4 bes''2 d''4~ |
      d''2 bes''2~ |
      bes''4 g'''4 g''2~ |
      g''4 bes'4 bes''2~ |
      bes''2 d''2~ |
      d''4 bes''2. |
      bes''2 d''2~ |
      d''4 bes''2 bes'4~ |
      bes'4 g''2 bes'4~ |
      bes'4 g''4 bes'4 g''4~ |
      g''2 bes'4 bes''4 |
      ees''2. ees'''4~ |
      ees'''2 ees''2~ |
      ees''4 c'''2. |
      c''1~ |
      c''1~ |
      c''1~ |
      c''4 f''2.~ |
      f''1~ |
      f''1~ |
      f''1 |
      d'''4 d''2 bes''4~ |
      bes''1 |
      d''4 bes''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4^\markup { \tiny \italic "Subject" } d'''4 g'''2 |
      f'''8 g'''8 a'''4 bes'''8 a'''8 g'''4 |
      ees'''4 c'''4 bes''2 |
      d''4^\markup { \tiny \italic "Countersubject" } c''4 f''4. g''16 f''16 |
      e''8 f''8 g''4 a''4 f''4 |
      d''4 e''4 d''2 |
      d''4 ees''4 f''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4 d''2 bes''4~ |
      bes''2 d''2~ |
      d''4 bes''2.~ |
      bes''4 d''2 g'4~ |
      g'4 ees''2 bes''4~ |
      bes''4 bes'2 bes''4~ |
      bes''4 d''2 bes''4~ |
      bes''2 d''2 |
      d''4 bes''2 f''4~ |
      f''4 d'''2 d''4~ |
      d''2 bes''2 |
      d''4 bes''2 bes'4~ |
      bes'4 bes''2 ees''4~ |
      ees''4 g'2 g''4~ |
      g''2 ees'''2 |
      g''4 c''2.~ |
      c''1~ |
      c''1~ |
      c''4 f''2.~ |
      f''1~ |
      f''1~ |
      f''1~ |
      f''2. f'4~ |
      f'4 d''2.~ |
      d''4 d'''2 g''4~ |
      g''4 bes'2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'4^\markup { \tiny \italic "Subject" } d''4 g''2 |
      f''8 g''8 a''4 bes''8 a''8 g''4 |
      ees''4 c''4 bes'2 |
      d''4^\markup { \tiny \italic "Countersubject" } c''4 f''4. g''16 f''16 |
      e''8 f''8 g''4 a''4 f''4 |
      d''4 e''4 d''2 |
      g'2. c''8 bes'8 |
      a'2 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4 bes'4 f''2~ |
      f''4 bes''2 d''4~ |
      d''2 g''2~ |
      g''4 d'''4 g''2~ |
      g''4 bes'4 ees''2~ |
      ees''4 bes''2 bes'4~ |
      bes'2 f''4 bes'4~ |
      bes'4 f''2. |
      d''2. bes'4 |
      f''2. bes'4~ |
      bes'2 g''4 d'''4~ |
      d'''2 g''2~ |
      g''4 g'4 ees''2~ |
      ees''4 bes''4 ees''2~ |
      ees''4 c'''4 g''4 c''4~ |
      c''4 g'4 ees''2~ |
      ees''4 c'''2 c''4~ |
      c''1~ |
      c''2 f''2~ |
      f''1~ |
      f''1~ |
      f''1~ |
      f''2 f'4 d''4~ |
      d''4 bes''4 d''2~ |
      d''4 bes''4 d''4 g''4~ |
      g''2 bes'4 d''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      f''4^\markup { \tiny \italic "Real answer" } a''4 d'''2 |
      c'''8 d'''8 e'''4 f'''8 e'''8 d'''4 |
      bes''4 g''4 f''2 |
      f''8 ees''8 d''4 ees''2 |
      g'4^\markup { \tiny \italic "Countersubject" } f'4 bes'4. c''16 bes'16 |
      a'8 bes'8 c''4 d''4 bes'4 |
      g'4 a'4 g'2 |
      a'2 bes'2 |
      c''4. bes'8 a'2 |
      bes'4. c''8 d''2 |
      c''1~ |
      c''8 bes'4. g''4 d''4~ |
      d''4 f'4 bes'2 |
      c''2 d''2 |
      d''4 c''2 d''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees''2 bes'4. c''8 |
      d''8 ees''8 f''4 g''4 d''4 |
      c''2 bes'4 ees''8 f''8 |
      g''4 f''8 ees''8 d''4 g''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'4. a'8 g'8 a'8 bes'4 |
      f''4 c''4 f''4 g''4~ |
      g''8 f''8 ees''4 bes'8 a'8 g'4 |
      d''4 f'8 e'8 d'8 e'8 f'4 |
      c''2 a''4 d''4 |
      g'2 d''4 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g'4 d''4 g'8 a'8 bes'4 |
      f''2. g''4 |
      bes'4 f''4 bes'8 a'8 g'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'''4 g''4 c''4 f''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2 f'4 d''4~ |
      d''2 bes''2 |
      d''2 g'2 |
      d''2. g''4~ |
      g''2 bes'2~ |
      bes'4 ees''2. |
      bes'2. f''4 |
      bes'2 d''2 |
      d''2 f'4 bes'4~ |
      bes'2 bes''4 d''4~ |
      d''2 g'4 bes'4~ |
      bes'2 g''2~ |
      g''4 bes'2 g'4~ |
      g'2. ees''4~ |
      ees''2 g'2 |
      ees''2. c'''4~ |
      c'''2 c''2~ |
      c''1~ |
      c''1~ |
      c''1~ |
      c''1~ |
      c''2 f''2~ |
      f''2. bes'4~ |
      bes'2 bes''2 |
      d''2 g'2 |
      d''2. bes''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''4^\markup { \tiny \italic "Real answer" } a''4 d'''2 |
      c'''8 d'''8 e'''4 f'''8 e'''8 d'''4 |
      bes''4 g''4 f''2 |
      ees''2 f''8 ees''8 d''4 |
      g'4^\markup { \tiny \italic "Countersubject" } f'4 bes'4. c''16 bes'16 |
      a'8 bes'8 c''4 d''4 bes'4 |
      g'4 a'4 g'2 |
      f'4. g'8 a'4 bes'4 |
      c''4. bes'8 a'2 |
      bes'4. c''8 d''2 |
      d''1~ |
      d''4 f'2 g'4 |
      ees''4. f''8 g''4 bes'8 a'8 |
      g'2. c''4 |
      f'4. ees'8 d'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g''4 d''4 bes'2 |
      f'2 bes'2 |
      g''4 f''8 ees''8 d''2 |
      d''4 a'8 g'8 f'2 |
      g'4 c'4 f'2 |
      bes'2 f'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''2 bes'2 |
      f'2 bes'2 |
      g''2 d''4 g''4 |
      d''2 bes'2 |
      ees''4 bes'2. |
      ees'2 bes'2 |
      d''2 bes'2 |
      f'2 d'2 |
      d''2 bes'2 |
      f'2 d'4 bes'4~ |
      bes'2 d''2 |
      g'4 d''4 bes'2 |
      g''2 ees''2~ |
      ees''4 bes'4 ees''2~ |
      ees''4 g'4 c''2 |
      g'2. c''4~ |
      c''2 ees'2~ |
      ees'4 c''2.~ |
      c''1~ |
      c''1~ |
      c''1 |
      f'1 |
      f''2 bes'2 |
      f'4 d'2. |
      bes'2 g'2 |
      d'2 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4^\markup { \tiny \italic "Real answer" } a'4 d''2 |
      c''8 d''8 e''4 f''8 e''8 d''4 |
      bes'4 g'4 f'2 |
      g'4^\markup { \tiny \italic "Countersubject" } f'4 bes'4. c''16 bes'16 |
      a'8 bes'8 c''4 d''4 bes'4 |
      g'4 a'4 g'2 |
      f'2 a'2~ |
      a'4 c'4 f'2 |
      g'2 d'8 e'8 f'4 |
      bes'4. a'8 g'2 |
      a'8 g'8 f'4 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g'4 d'4 bes'4 g''4 |
      c''2 f'4 bes4 |
      g'4 c'4 g'4 d'8 ees'8 |
      f'2~ f'8 g'8 a'4 |
      c'2 a'4 d''4 |
      g'2 d''4 a'4 |
      r1 |
      r1 |
      f'4^\markup { \tiny \italic "Related-key subject" } a'4 d''2 |
      c''8 d''8 e''4 f''8 e''8 d''4 |
      bes'4 g'4 f'2 |
      f'4 g'2 a'4 |
      g'2.~ g'8 aes'8 |
      bes'4 aes'4 g'2 |
      c''4 bes'8 aes'8 g'4 aes'4 |
      bes'4^\markup { \tiny \italic "Related-key subject" } d''4 g''2 |
      f''8 g''8 a''4 bes''8 a''8 g''4 |
      ees''4 c''4 bes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'2 d''2 |
      bes'2 f'2 |
      bes'2 g'4 d''4 |
      g'2. d'4 |
      g'2 ees''4 bes'4~ |
      bes'2 ees'4 bes'4~ |
      bes'2 d''2 |
      bes'2 f'4 bes'4 |
      d''4 f''2.~ |
      f''2. f'4 |
      d''2 g''2 |
      bes'4 g'2 bes'4~ |
      bes'1 |
      g''2 bes'4 ees''4~ |
      ees''1 |
      ees'2 g'2 |
      ees'1~ |
      ees'1 |
      c''4 a'2 c'4~ |
      c'2 f'2~ |
      f'2 a'4 a''4~ |
      a''4 c''4 a'2 |
      bes'2^\markup { \tiny \italic "Subject-head fragment in augmentation" } d''2 |
      f''2. bes'4~ |
      bes'2. g'4 |
      bes1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4^\markup { \tiny \italic "Real answer" } a'4 d''2 |
      c''8 d''8 e''4 f''8 e''8 d''4 |
      bes'4 g'4 f'2 |
      g'4^\markup { \tiny \italic "Countersubject" } f'4 bes'4. c''16 bes'16 |
      a'8 bes'8 c''4 d''4 bes'4 |
      g'4 a'4 g'2 |
      f'4 e'4 f'8 g'8 a'4 |
      c'2. bes4 |
      d'8 c'8 bes4 d'4 a4 |
      bes4 c'2 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'4 f'4 ees'4 bes4 |
      f'2. g'4~ |
      g'4 c''4 g'8 a'8 bes'4 |
      d'8 e'8 f'4 d'4 f'4 |
      c''2. f'4 |
      bes4 g'4 a'8 g'8 f'4 |
      r1 |
      r1 |
      d'4 a'2 d''4 |
      g'4 bes4 f4 a4 |
      d'4 g4 d'8 e'8 f'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4 d'2 g'4 |
      c'4 f'4 bes'4 ees'4 |
      bes4 c'4 d'8 ees'8 f'4 |
      g'4 bes'4 d''4 a'4 |
      d'4 bes4 ees'4 c''4 |
      f'4 bes'2 g'4 |
      r1 |
      d'4 bes2 d'4 |
      f'4 d'2 bes4 |
      d'4 g'2 bes'4 |
      d''4 bes'2 g'4~ |
      g'4 bes'2 g'4 |
      ees'4 g'4 ees'4 g'4 |
      d'4 bes2 d'4 |
      f'4 bes'2 f'4 |
      f'4 bes'4 f'4 d'4 |
      f'4 bes'2. |
      d'2. g'4 |
      d'4 g'2. |
      bes4 ees'2. |
      g'4 bes'2 ees'4~ |
      ees'2 c'4 g'4~ |
      g'4 c''2. |
      ees'2. c''4~ |
      c''2. c'4~ |
      c'2. f'4~ |
      f'1~ |
      f'1~ |
      f'1 |
      f4 d'4 f'4 d'4 |
      bes'2. d'4~ |
      d'4 g'2 bes'4 |
      d''2. bes'4 |
      bes'4 a'4 g'4 bes'4 |
      f''4 c''4 f'4 bes'4~ |
      bes'4 f'4 bes'4 g'4 |
      g'4 ees'4 c''4 f'4 |
      d'4 f'2 d'4 |
      bes4 d'2 f'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4^\markup { \tiny \italic "Real answer" } a'4 d''2 |
      c''8 d''8 e''4 f''8 e''8 d''4 |
      bes'4 g'4 f'2 |
      g'4^\markup { \tiny \italic "Countersubject" } f'4 bes'4. c''16 bes'16 |
      a'8 bes'8 c''4 d''4 bes'4 |
      g'4 a'4 g'2 |
      a'2~ a'8 g'8 f'4 |
      c'2 f'4 a'4~ |
      a'8 g'4. d'8 e'8 f'4 |
      d'8 c'8 bes4 c'2 |
      f'1 |
      f'4 c'8 bes8 a2 |
      c'4 g4 c'4 f'4~ |
      f'4 c''4 f'8 e'8 d'4 |
      f'4 d''4 g'4 c'4 |
      c'4 g'4. f'8 ees'4 |
      f'2 bes4 ees'4~ |
      ees'4 bes'4 ees'8 d'8 c'4~ |
      c'8 bes8 f'8 ees'8 d'4 g'4 |
      c'4 ees4 f4 bes4~ |
      bes4 f'4 bes8 c'8 d'4 |
      d'4 a4 g8 a8 bes4 |
      f'4. ees'8 d'4 ees'4~ |
      ees'2 d'4 bes4~ |
      bes4 d'4 f'4 d'4~ |
      d'4 g'4 c''4 f'4~ |
      f'4 g'2 bes'4 |
      r1 |
      d'4 f'2 d'4~ |
      d'4 f'2 bes'4~ |
      bes'4 g'2 d'4~ |
      d'4 g'2 bes'4 |
      g'4 ees'2 g'4~ |
      g'4 ees'4 g'4 ees'4 |
      d'4 f'4 d'4 bes4~ |
      bes4 d'2 f'4 |
      f'2 d'4 f'4~ |
      f'4 d'4 f'4 d'4~ |
      d'4 g'2 d'4~ |
      d'2 g'2~ |
      g'4 ees'2 g'4~ |
      g'4 ees'4 g'4 ees'4~ |
      ees'4 g'4 ees'4 c'4 |
      ees'4 g'2 ees'4~ |
      ees'2. c'4~ |
      c'2 ees'4 c''4~ |
      c''4 f'2.~ |
      f'1~ |
      f'1~ |
      f'1~ |
      f'4 bes2 d'4~ |
      d'2 f'4 bes'4~ |
      bes'4 g'2 d'4~ |
      d'4 g'4 bes'4 g'4 |
      g'4 d'4 bes4 d'4 |
      c'2 f'4 g'4~ |
      g'4 c'4 ees'4 bes4 |
      bes4 g4 c'4 f'4~ |
      f'4 d'2 f'4~ |
      f'2 d'4 bes4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "treble" \key bes \major \time 4/4
      bes4^\markup { \tiny \italic "Subject" } d'4 g'2 |
      f'8 g'8 a'4 bes'8 a'8 g'4 |
      ees'4 c'4 bes2 |
      d'4^\markup { \tiny \italic "Countersubject" } c'4 f'4. g'16 f'16 |
      e'8 f'8 g'4 a'4 f'4 |
      d'4 e'4 d'2 |
      d'8 ees'8 f'4 ees'2 |
      bes1 |
      d'4 c'4 g2~ |
      g4 c'4 g2 |
      d'4 e'4 f'2 |
      g'2 f'2 |
      bes2 a2 |
      c2 c'4 g'4 |
      bes1 |
      f2 d'2 |
      ees'2 d'2 |
      d'4 ees'4 f'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g'8 f'8 ees'4 d'4 f'4 |
      d'4 bes4. c'8 d'8 ees'8 |
      f'2. ees'4 |
      bes4 f4 bes8 c'8 d'4 |
      d'8 e'8 f'4 d'8 e'8 f'4 |
      c'4 g4 d'4. e'8 |
      f'4 g'4 d'8 e'8 f'4 |
      d'8 ees'8 f'4 d'4 bes4 |
      d'4 c'4 bes8 c'8 d'4 |
      g'8 f'8 ees'4 bes8 c'8 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g'4 d'2 g'4 |
      d'4 ees'4 f'8 ees'8 d'4 |
      c'8 d'8 ees'4 d'8 c'8 bes4 |
      d'8 e'8 f'2 d'4 |
      a4 g4 c'4 d'4 |
      g'8 a'8 bes'4 a'8 g'8 f'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'4 f'4 g'8 f'8 ees'4 |
      c'4 f'2 ees'8 f'8 |
      g'4 f'8 ees'8 d'8 c'8 bes4~ |
      bes8 a8 f'4. e'8 d'4 |
      g4 c'2 d'4 |
      g'8 a'8 bes'4 f'8 e'8 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 g'2 f'4~ |
      f'8 ees'8 d'4 ees'8 d'8 c'4 |
      f8 g8 aes4 bes4 c'4 |
      ees'4 bes4 c'8 d'8 ees'4 |
      g'4 d'4. c'8 bes4 |
      c'2 bes4 d'4 |
      g'4 f'4 bes'8 a'8 g'4 |
      g'4 d'4. c'8 bes4 |
      c'2 d'8 c'8 bes4 |
      ees'4 g'2 f'4 |
      d'4 bes2 a4 |
      d'2 c'2 |
      d'4 bes2 d'4 |
      r1 |
      f'4 d'2 f'4 |
      d'4 bes2 d'4 |
      g'4 d'2 bes4 |
      g4 bes2 d'4 |
      ees'4 g'2 ees'4 |
      bes4 g4 bes4 ees'4 |
      f'4 d'2 f'4 |
      d'4 bes2 d'4 |
      d'4 bes2 d'4 |
      bes4 d'2 bes4 |
      d'4 bes2 d'4 |
      bes4 d'2 g'4 |
      bes'4 g'2 ees'4 |
      bes4 ees'2 g'4 |
      ees'4 c'2 ees'4 |
      c'4 ees'2 c'4 |
      ees'4 c'2 ees'4 |
      c'4 ees'2 c'4~ |
      c'1~ |
      c'1 |
      f'1~ |
      f'1~ |
      f'4 d'2 f'4 |
      d'4 bes2 d'4 |
      bes4 d'4 bes4 d'4 |
      bes4 g2 bes4 |
      d'4 f'4 d'4 bes4 |
      c'4 ees'4 f'4 d'4 |
      g'4 f'4 g'4 ees'4 |
      ees'4 g'4 f'4 c'4 |
      bes4 d'2 bes4 |
      d'4 f'2 d'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes4^\markup { \tiny \italic "Subject" } d'4 g'2 |
      f'8 g'8 a'4 bes'8 a'8 g'4 |
      ees'4 c'4 bes2 |
      d'4^\markup { \tiny \italic "Countersubject" } c'4 f'4. g'16 f'16 |
      e'8 f'8 g'4 a'4 f'4 |
      d'4 e'4 d'2 |
      ees'8 d'8 c'4 bes2~ |
      bes1 |
      f4. ees8 d4 ees4~ |
      ees4 f4 g2 |
      a2. d'4 |
      g'2 d'2~ |
      d'8 c'8 bes4 a2 |
      bes2~ bes8 a8 g4 |
      a4 f4 bes2~ |
      bes4 c'4 g4. a8 |
      bes8 c'8 d'4 g2~ |
      g8 f2.~ f8 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'4 bes8 c'8 d'2 |
      f'4 ees'4 d'2 |
      ees'4. f'8 g'2 |
      d'4 a4 f'2 |
      c'4 g4 f8 g8 a4 |
      bes4. c'8 d'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ees'4 f'4 ees'4. d'8 |
      c'2 bes2~ |
      bes4 f4 bes2 |
      a8 bes8 c'4 d'8 e'8 f'4 |
      c'4. bes8 a4 bes4~ |
      bes2 f'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4 a4 g2 |
      c'2 bes2~ |
      bes4 f4 bes2 |
      f4. g8 a2 |
      c'4. bes8 a2 |
      bes2 d'2 |
      r1 |
      r1 |
      a8 bes8 c'4 d'8 e'8 f'4 |
      c'4 bes4 c'8 bes8 a4 |
      bes4 c'8 bes8 a2 |
      a4 bes8 a8 g4 c'4 |
      c'4 d'4 c'8 d'8 ees'4 |
      bes4 f4 bes8 aes8 g4 |
      aes4 bes4 ees'2 |
      bes4 a4 bes2 |
      f4 c4 f4 g4~ |
      g4 c'4 d'2 |
      d'8 ees'8 f'4 d'4. ees'8 |
      f'2 g'8 f'8 ees'4 |
      ees4 c'4 g'8 a'8 bes'4 |
      bes4 d2 f4 |
      g4 bes4 a2 |
      bes4 g2. |
      r1 |
      d''1~ |
      d''2 f'4 d'4~ |
      d'1~ |
      d'2 d''2 |
      g'2 bes'4 bes4 |
      g2 g'4 bes'4 |
      d'2. f4~ |
      f1 |
      bes4 d'4 f'2 |
      d'2 bes2~ |
      bes4 g4 bes2 |
      d'4 bes4 g2~ |
      g4 bes4 g2 |
      bes4 g4 ees2 |
      g4 c'4 ees'4 g'4 |
      ees'4 c'4 ees'2 |
      c'4 ees'4 c'2 |
      ees'4 c'2.~ |
      c'1~ |
      c'1~ |
      c'1~ |
      c'4 f2.~ |
      f4 bes2. |
      d'4 f'4 d'4 bes4 |
      d'4 bes4 d'2~ |
      d'4 bes4 g2 |
      bes4^\markup { \tiny \italic "Subject" } d'4 g'2 |
      f'8 g'8 a'4 bes'8 a'8 g'4 |
      ees'4 c'4 bes2 |
      bes2 f2 |
      bes1 |
      bes1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes4^\markup { \tiny \italic "Subject" } d'4 g'2 |
      f'8 g'8 a'4 bes'8 a'8 g'4 |
      ees'4 c'4 bes2 |
      d4^\markup { \tiny \italic "Countersubject" } c4 f4. g16 f16 |
      e8 f8 g4 a4 f4 |
      d4 e4 d2 |
      g8 a8 bes2. |
      d'4 c'4 bes2 |
      c'2 g2 |
      a2.~ a8 bes8 |
      c'4. bes8 a2~ |
      a8 g4. a2 |
      bes2 c'2~ |
      c'4 f2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4 a4 g2 |
      c'2 f4 ees8 f8 |
      g4 c'4 g2 |
      d4 e4 d2 |
      g2 c'4 d'4 |
      g2 a2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 e4 f8 g8 a4 |
      g2 c4 d8 e8 |
      f4 g4 d2 |
      d4 g4 c'2 |
      g8 aes8 bes4 c'2 |
      f'4 aes4 ees8 f8 g4 |
      c4 f4 g8 f8 ees4 |
      bes4 f4 g2 |
      c'2 f8 ees8 d4 |
      bes,4 c4 g2 |
      g4 f4 g2 |
      c'2 bes4. a8 |
      g4. a8 bes4. c'8 |
      d'2 bes4 f4 |
      d2 ees4 f4 |
      bes2 g2 |
      r1 |
      d2 f2 |
      bes4 d'4 bes2 |
      g2 bes4 g4 |
      bes2 g2 |
      ees2 g4 bes4 |
      ees'2 bes2 |
      f2 bes2 |
      d'2 bes2 |
      f2 bes2 |
      d'4 bes4 f4 bes4~ |
      bes2 g2 |
      bes2 d'4 bes4 |
      g2 bes2 |
      g2 bes4 g4~ |
      g4 ees4 g2 |
      c'2 g4 c4~ |
      c2 ees2 |
      c'1 |
      c1 |
      f1~ |
      f1~ |
      f1~ |
      f2 bes4 f4 |
      bes2 f4 d4~ |
      d2 g2 |
      bes4 d'4 bes2 |
      bes4 f4 g2 |
      c'2 bes4 d'4 |
      bes4 c'4 g2 |
      ees2 f2 |
      d'2 bes2 |
      f4 d4 f2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes4^\markup { \tiny \italic "Subject" } d'4 g'2 |
      f'8 g'8 a'4 bes'8 a'8 g'4 |
      ees'4 c'4 bes2 |
      d4^\markup { \tiny \italic "Countersubject" } c4 f4. g16 f16 |
      e8 f8 g4 a4 f4 |
      d4 e4 d2 |
      ees4 d4 ees2 |
      f4. ees8 d4 ees4~ |
      ees4 f4 g2 |
      a1 |
      c'4 g4 f2 |
      g8 a8 bes4 a2~ |
      a8 g4. f2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4 d'8 c'8 bes2 |
      f2 bes2~ |
      bes4 f'4 bes2 |
      f'4 c'4 d'2 |
      g'4 c'4 f2 |
      bes2 d2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes4 f4 bes2 |
      f4 c4 g2 |
      bes4 ees'4 bes4 f4 |
      bes4 g4 d4 a4~ |
      a8 g4. c2 |
      f4 ees4 g2 |
      r1 |
      bes4 f4 d4 bes,4 |
      d2 f2 |
      d4 bes,4 d2 |
      g2 bes2~ |
      bes4 g4 ees2 |
      g4 bes4 g2 |
      bes4 f2. |
      bes4 f4 bes2 |
      bes4 f2. |
      bes4 f4 bes4 d'4~ |
      d'4 g4 d2 |
      g2 bes2~ |
      bes4 ees4 bes,2 |
      ees4 g4 ees'2 |
      g2 c2 |
      g2 c'2~ |
      c'4 ees2.~ |
      ees2 c'2~ |
      c'2 f2~ |
      f1~ |
      f1~ |
      f1~ |
      f2 d2 |
      bes,4 f4 bes2~ |
      bes4 d2. |
      g4 d4 g2 |
      g4 a4 d'4 g'4 |
      c'4 ees4 bes2~ |
      bes4 f'4 bes2 |
      g2 c2 |
      f4 bes4 d'2~ |
      d'4 bes4 f2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,4^\markup { \tiny \italic "Subject" } d4 g2 |
      f8 g8 a4 bes8 a8 g4 |
      ees4 c4 bes,2 |
      d4^\markup { \tiny \italic "Countersubject" } c4 f4. g16 f16 |
      e8 f8 g4 a4 f4 |
      d4 e4 d2 |
      ees4 d4 ees2 |
      f4. ees8 d4 ees4~ |
      ees4 f4 g2 |
      f1 |
      g2 f2 |
      g4 bes,4 a,2 |
      bes,8 a,8 g,2 ees4 |
      f4. ees8 d2 |
      d4 e4 d2 |
      g8 a8 bes4 a2 |
      d4 c4 d2 |
      d2 e4 f4 |
      g1 |
      f2 ees2~ |
      ees4 f4 c2 |
      d1 |
      c8 d8 ees4 d2 |
      ees4 f8 ees8 d2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes4 d'4 bes4 f4~ |
      f4 bes,4 d2 |
      bes,4 d4 bes,4 d4 |
      bes,2 d4 bes,4~ |
      bes,4 ees4 bes,4 ees4~ |
      ees4 bes,4 ees4 bes,4~ |
      bes,4 d4 f2~ |
      f4 d4 f4 d4 |
      f4 d4 bes2 |
      d1 |
      bes2. d4~ |
      d2 bes4 g4~ |
      g1 |
      ees2 bes,2 |
      g1~ |
      g1 |
      a1~ |
      a1~ |
      a4 f4 c4 a,4 |
      c1 |
      a,2 c2 |
      c'4 a4 c2 |
      f,1~ |
      f,4 bes,4 d2~ |
      d1~ |
      d1 |
      r1 |
      r1 |
      r1 |
      ees4 bes,4 f2~ |
      f4 bes,2 d4~ |
      d2 bes,4 d4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 16" shortInstrumentName = "V16" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4^\markup { \tiny \italic "Real answer" } a4 d'2 |
      c'8 d'8 e'4 f'8 e'8 d'4 |
      bes4 g4 f2 |
      c8 d8 ees4 c2 |
      g,4^\markup { \tiny \italic "Countersubject" } f,4 bes,4. c16 bes,16 |
      a,8 bes,8 c4 d4 bes,4 |
      g,4 a,4 g,2 |
      g,2 c4 bes,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a4 f2 bes4 |
      g2 f8 g8 a4 |
      d4 g4 a8 g8 f4 |
      bes,2~ bes,8 c8 d4~ |
      d4 f8 ees8 d4 g,4~ |
      g,4 c4 d4 g4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes4 f4 g8 f8 ees4 |
      c'4 f2 bes4 |
      ees4 c'4 r2 |
      d4 a2 d'4 |
      g4 c'4 f4 bes4 |
      d4 g4 d8 e8 f4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,4 f2 bes4~ |
      bes4 f2 bes,4~ |
      bes,2 g2~ |
      g4 d2. |
      bes,2. g4~ |
      g2 bes,2~ |
      bes,4 f2 bes4~ |
      bes4 d2 bes,4 |
      bes,4 f2 bes,4~ |
      bes,2 d2~ |
      d4 bes2 g4~ |
      g4 d2 g,4~ |
      g,4 ees4 g4 bes4~ |
      bes4 ees2 g,4~ |
      g,4 ees4 c'4 g4~ |
      g4 ees4 c4 ees4~ |
      ees2 c'2~ |
      c'4 c2.~ |
      c1~ |
      c1~ |
      c4 f2.~ |
      f1~ |
      f4 f,2 bes,4~ |
      bes,4 d2.~ |
      d4 g,2 d4~ |
      d4 g,2 d,4 |
      r1 |
      r1 |
      r1 |
      g,4 bes,4 c2 |
      f,2. bes,4~ |
      bes,4 f2 bes4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 17" shortInstrumentName = "V17" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4^\markup { \tiny \italic "Real answer" } a,4 d2 |
      c8 d8 e4 f8 e8 d4 |
      bes,4 g,4 f,2 |
      g,4^\markup { \tiny \italic "Countersubject" } f,4 bes,4. c16 bes,16 |
      a,8 bes,8 c4 d4 bes,4 |
      g,4 a,4 g,2 |
      g,8 a,8 bes,4 g,8 f,8 ees,4 |
      f,1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,8 bes,8 c4 d2 |
      e4 c'4 f2 |
      bes,2 f,8 g,8 a,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,2 bes,2~ |
      bes,4 f4 bes,2~ |
      bes,4 d,4 bes,2~ |
      bes,4 d4 g4 bes,4~ |
      bes,4 ees,4 bes,2~ |
      bes,4 g2 bes,4~ |
      bes,2 f,4 d4~ |
      d4 f4 bes,2 |
      bes,4 d,2 bes,4~ |
      bes,4 f4 bes,2~ |
      bes,4 d,4 bes,,4 g,4~ |
      g,2 d,4 bes,4~ |
      bes,2. ees4~ |
      ees2 g,2~ |
      g,4 c,4 g,4 c4~ |
      c4 g4 c2~ |
      c4 c,2 c4~ |
      c2 c,4 c4~ |
      c1~ |
      c1~ |
      c1~ |
      c2. f,4~ |
      f,2 d4 bes,4~ |
      bes,4 f,4 bes,,2~ |
      bes,,4 g,4 bes,2~ |
      bes,4 g4 d4 g4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 18" shortInstrumentName = "V18" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4^\markup { \tiny \italic "Real answer" } a,4 d2 |
      c8 d8 e4 f8 e8 d4 |
      bes,4 g,4 f,2 |
      g,4. f,8 ees,4 c4 |
      f,4. ees,8 d,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,2 d,2 |
      bes,2. f4 |
      bes,2 d,2 |
      bes,4 g,4 d,4 bes,4~ |
      bes,2 ees,2 |
      bes,2. g4 |
      bes,2. f,4~ |
      f,2 d2 |
      d2 d,2~ |
      d,4 f,2 d4~ |
      d2. g,4~ |
      g,2 g4 bes,4~ |
      bes,2 ees,2 |
      bes,2. g4 |
      g,2 g,,4 ees,4~ |
      ees,2 c2~ |
      c1 |
      c,2 c2~ |
      c1~ |
      c1~ |
      c2 f,2~ |
      f,1~ |
      f,1 |
      bes,,2 f,4 d4~ |
      d2 d,2 |
      bes,2 d2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 19" shortInstrumentName = "V19" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4^\markup { \tiny \italic "Real answer" } a,4 d2 |
      c8 d8 e4 f8 e8 d4 |
      bes,4 g,4 f,2 |
      g,4 c8 bes,8 a,4 bes,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d2 f,2 |
      bes,,2 f,2 |
      d4 g,2. |
      bes,,2 g,2 |
      ees2 g,2 |
      bes,,2 g,2 |
      d2 f,2~ |
      f,4 bes,,4 f,2 |
      f,2 bes,,4 f,4 |
      bes,,2. bes,4~ |
      bes,2 d,2~ |
      d,4 g,,2. |
      g,1 |
      bes,,2 g,2 |
      ees2. g,4 |
      c,2 ees,,2 |
      c,1~ |
      c,1 |
      c1 |
      f,1~ |
      f,1~ |
      f,1~ |
      f,1~ |
      f,4 bes,,2. |
      bes,2. d,4 |
      g,,2 d,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 20" shortInstrumentName = "V20" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4^\markup { \tiny \italic "Real answer" } a,4 d2 |
      c8 d8 e4 f8 e8 d4 |
      bes,4 g,4 f,2 |
      bes,,2 ees,8 d,8 c,4 |
      f,,2 bes,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d,2 bes,2 |
      d,2. bes,4 |
      bes,,2. g,4~ |
      g,2 bes,,2 |
      g,2. bes,,4~ |
      bes,,1 |
      bes,2. d,4~ |
      d,2 bes,4 d,4 |
      d,2 d4 f,4~ |
      f,2 d2 |
      d,2. bes,4~ |
      bes,2 bes,,2~ |
      bes,,2 g,4 ees4 |
      ees,2. ees,,4 |
      ees,2. c4~ |
      c2 c,2~ |
      c,1~ |
      c,1~ |
      c,1~ |
      c,1~ |
      c,2 f,2~ |
      f,1~ |
      f,2 f2 |
      f,2 d4 d,4~ |
      d,2 bes,2~ |
      bes,4 d,2 g,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 21" shortInstrumentName = "V21" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,,8 bes,,8^\markup { \tiny \italic "Ascending passing resolution" } c,8 d,8 ees,4 ees,4 |
      bes,,4^\markup { \tiny \italic "Subject" } d,4 g,2 |
      f,8 g,8 a,4 bes,8 a,8 g,4 |
      ees,4 c,4 bes,,2 |
      bes,,4 c,8 bes,,8 a,,4 bes,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4 bes,,2. |
      f,2. d4 |
      d,2. bes,4 |
      d,1 |
      bes,4 bes,,2.~ |
      bes,,4 bes,2. |
      bes,,1 |
      f,2. bes,,4 |
      bes,,2. bes,4~ |
      bes,4 d,2. |
      g,,4 bes,,2. |
      g,2. d,4 |
      g,,1 |
      ees,2. bes,,4 |
      c,4 g,,2.~ |
      g,,4 ees,2 g,4 |
      c,2. ees,,4~ |
      ees,,4 ees,2. |
      c,2. c4~ |
      c4 f,2. |
      c,2. f,4 |
      c,4 f,2 c,4 |
      bes,,4 d,2 bes,4~ |
      bes,4 d,2. |
      g,,4 bes,,2. |
      g,2. d4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 22" shortInstrumentName = "V22" } {
      \clef "bass" \key bes \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,,4^\markup { \tiny \italic "Subject" } d,4 g,2 |
      f,8 g,8 a,4 bes,8 a,8 g,4 |
      ees,4 c,4 bes,,2 |
      bes,,2 c,4. bes,,8 |
      a,,2 bes,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d,4^\markup { \tiny \italic "Countersubject" } c,4 f,4. g,16 f,16 |
      e,8 f,8 g,4 a,4 f,4 |
      d,4 e,4 d,2 |
      d,8 c,8 bes,,4 c,8 bes,,8 a,,4 |
      c,4^\markup { \tiny \italic "Countersubject" } bes,,4 ees,4. f,16 ees,16 |
      d,8 ees,8 f,4 g,4 ees,4 |
      c,4 d,4 c,2 |
      g,,4^\markup { \tiny \italic "Countersubject" } f,,4 bes,,4. c,16 bes,,16 |
      a,,8 bes,,8 c,4 d,4 bes,,4 |
      g,,4 a,,4 g,,2 |
      bes,,4^\markup { \tiny \italic "Stretto subject" } d,4 g,2 |
      f,8 g,8 a,4 bes,8 a,8 g,4 |
      ees,4 c,4 bes,,2 |
      bes,,2. d,,4 |
      bes,,4 bes,,,4 c,,4 f,,4 |
      d,,4 ees,,4 bes,,,2 |
      r1 |
      bes,,1~ |
      bes,,1~ |
      bes,,1~ |
      bes,,1 |
      ees,,1~ |
      ees,,1 |
      bes,,1~ |
      bes,,1 |
      bes,,1~ |
      bes,,1 |
      g,,1~ |
      g,,1 |
      ees,,1~ |
      ees,,1 |
      c,,1~ |
      c,,1~ |
      c,,1~ |
      c,,1 |
      f,,1~ |
      f,,1~ |
      f,,1~ |
      f,,1 |
      bes,,1~ |
      bes,,1 |
      g,,1~ |
      g,,1 |
      g,,4^\markup { \tiny \italic "Countersubject" } f,,4 bes,,4. c,16 bes,,16 |
      a,,8 bes,,8 c,4 d,4 bes,,4 |
      g,,4 a,,4 g,,2 |
      g,,2 a,,2 |
      bes,,1 |
      bes,,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
