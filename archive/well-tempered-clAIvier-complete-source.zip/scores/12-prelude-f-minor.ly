\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XII. Prelude in F minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key f \minor \time 4/4
      \tempo "Andante, ostinato" 4 = 76
      \mark \markup \box \small "Ground stated" c'''2\p bes''4 aes''4 |
      bes''2 aes''4 g''4 |
      aes''2 g''4 f''4 |
      g''2 f''4 e''4 |
      \mark \markup \box \small "Fragmented reply" f''4 c''8 aes'8 c''4 c''4 |
      ees''4 bes'8 g'8 bes'4 bes'4 |
      des''4 aes'8 f'8 aes'4 des''4 |
      g''4 e''8 f''8 g''4 g''4 |
      \mark \markup \box \small "Eighth-note variation" aes''8\mp bes''8 c'''8 aes''8 f'''8 c'''8 aes''8 f''8 |
      g''8 ees''8 bes''8 g''8 ees'''8 bes''8 g''8 ees''8 |
      f''8 g''8 aes''8 f''8 des'''8 aes''8 f''8 des''8 |
      c'''8 g''8 e''8 c''8 g''8 e''8 c'''8 g''8 |
      \mark \markup \box \small "Suspended motion" aes''4. c'''8 bes''4 aes''4 |
      bes''4. bes''8 aes''4 g''4 |
      aes''4. g''8 f''4 f''4~^\markup { \tiny \italic "Prepared suspension" } |
      f''8 e''4^\markup { \tiny \italic "Resolution" } e''8 f''4 g''4 |
      \mark \markup \box \small "Sixteenth-note culmination" aes''16\mf bes''16 c'''16 aes''16 f'''16 c'''16 aes''16 f''16 c'''16 aes''16 f'''16 c'''16 aes''16 f''16 c'''16 aes''16 |
      g''16 ees''16 bes''16 g''16 ees'''16 bes''16 g''16 ees''16 bes''16 g''16 ees'''16 bes''16 g''16 ees''16 bes''16 g''16 |
      f''16 des''16 aes''16 f''16 des'''16 aes''16 f''16 g''16 aes''16 f''16 des'''16 aes''16 f''16 des''16 aes''16 f''16 |
      c'''16 g''16 e''16 c''16 g''16 e''16 c'''16 g''16 e''16 c''16 g''16 e''16 c'''16 g''16 e''16 c''16 |
      \mark \markup \box \small "Dissolving the ground" bes''8\mp f''8 bes''4 bes''4 f''4 |
      aes''8 ees''8 aes''4 g''4 aes''4 |
      g''8 des''8 g''4 f''4 g''4 |
      g''8 e''8 ees''4 e''4 g''4 |
      \mark \markup \box \small "Cadence" c'''2\p bes''4 aes''4 |
      aes''2 g''4 aes''4 |
      g''2 f''4 e''4 |
      f''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key f \minor \time 4/4
      aes2\p c'2 |
      ees'2 g'2 |
      f'2 aes'2 |
      e'2 g'2 |
      aes'2 aes'2 |
      g'2 g'2 |
      f'2 f'2 |
      g'4 g'4 e'4 g'4 |
      c''4\mp aes'4 f'4 aes'4 |
      bes'4 g'4 ees'4 g'4 |
      aes'4 f'4 des'4 f'4 |
      g'4 g'4 e'4 g'4 |
      c''4 aes'4 f'4 aes'4 |
      bes'4 g'4 ees'4 g'4 |
      aes'4 f'4 des'4 f'4 |
      g'4 g'4 e'4 g'4 |
      c''4\mf aes'4 f'4 aes'4 |
      bes'4 g'4 ees'4 g'4 |
      aes'4 f'4 des'4 f'4 |
      g'4 e'4 c'4 e'4 |
      f'4\mp des'4 bes4 des'4 |
      c'2 c'2 |
      bes2 des'2 |
      g'2 g'2 |
      aes'2\p c''2 |
      aes'2 aes'2 |
      g'2 bes'2 |
      aes'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key f \minor \time 4/4
      f,1\p |
      ees,1 |
      des,1 |
      c,1 |
      f,1 |
      ees,1 |
      des,1 |
      c,1 |
      f,1\mp |
      ees,1 |
      des,1 |
      c,1 |
      f,1 |
      ees,1 |
      des,1 |
      c,1 |
      f,1\mf |
      ees,1 |
      des,1 |
      c,1 |
      bes,,1\mp |
      aes,,1 |
      bes,,1 |
      c,1 |
      aes,,1\p |
      c,1 |
      c,1 |
      f,,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
