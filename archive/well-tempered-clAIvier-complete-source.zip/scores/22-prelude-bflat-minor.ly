\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXII. Prelude in B-flat minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key bes \minor \time 3/4
      \tempo "Largo, con fermezza" 4 = 70
      \mark \markup \box \small "Ground stated" f''4.\p ees''8 des''4 |
      ees''4. c''8 c''4 |
      des''4. bes'8 ges'4 |
      c'4. a8 c'4 |
      ges'4. ges'8 bes'4~^\markup { \tiny \italic "Prepared suspension" } |
      bes'4 a'8^\markup { \tiny \italic "Resolution" } a'8 c''4 |
      bes'4. aes'8 ges'4 |
      c'4. a8 c'4 |
      \mark \markup \box \small "First variation" des'4\mp f'8 bes'8 des''4 |
      ees''4 ees''8 aes''8 ees''4 |
      ges''4 des''8 ges''8 des''4 |
      a'4 a'8 f'8 a'4 |
      bes'4 bes'8 ees''8 ees''4 |
      c''4 c''8 f''8 f''4 |
      des''4 des''8 ges''8 des''4 |
      a'4 a'8 f'8 a'4 |
      \mark \markup \box \small "Flowing variation" bes'8\mf f''8 bes''8 des''8 f''8 des''8 |
      aes'8 ees''8 aes''8 c''8 ees''8 c''8 |
      ges'8 des''8 ges''8 bes'8 des''8 bes'8 |
      c''8 a'8 f'8 c''8 f''8 a'8 |
      ees'8 bes'8 ees''8 ges'8 bes'8 ges'8 |
      f'8 c''8 f''8 a'8 c''8 a'8 |
      bes'8 des''8 ges''8 bes'8 des''8 bes'8 |
      c''8 a'8 f'8 c''8 f''8 a'8 |
      \mark \markup \box \small "Figured culmination" bes'16 des''16 ees''16 f''16 bes''16 des''16 f''16 des''16 bes'16 f''16 bes''16 des''16 |
      ees''16 c''16 aes'16 ees''16 aes''16 c''16 ees''16 c''16 aes'16 ees''16 aes''16 c''16 |
      des''16 bes'16 ges'16 des''16 ges''16 bes'16 des''16 bes'16 ges'16 des''16 c''16 bes'16 |
      f''16 a'16 c''16 a'16 f'16 c''16 f''16 a'16 c''16 a'16 f'16 c''16 |
      bes'16 ges'16 aes'16 bes'16 ees''16 ges'16 bes'16 ges'16 ees'16 bes'16 ees''16 ges'16 |
      c''16 a'16 f'16 c''16 f''16 a'16 c''16 a'16 f'16 c''16 f''16 a'16 |
      bes'16 bes'16 ges'16 des''16 ges''16 bes'16 des''16 bes'16 ges'16 des''16 c''16 bes'16 |
      f''16 a'16 c''16 a'16 f'16 c''16 f''16 a'16 c''16 a'16 f'16 c''16 |
      \mark \markup \box \small "Epilogue and cadence" des''4.\mp des''8 des''4 |
      f''4. f''8 f''4~^\markup { \tiny \italic "Prepared suspension" } |
      f''4 ees''8^\markup { \tiny \italic "Resolution" } ges''8 ees''4 |
      ces''4. ees''8 ces''4 |
      des''4.\p c''8 bes'4 |
      c''4. a'8 f'4 |
      f'4. des'8 f'4 |
      bes'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key bes \minor \time 3/4
      des'4.\p f'4. |
      c'4. ees'4. |
      bes4. des'4. |
      a4. f4. |
      ges4. bes4. |
      c'4. c'4. |
      bes4. des'4. |
      a4. f4. |
      bes4.\mp f'4. |
      aes'4. c''4. |
      des''4 bes'4 ges'4 |
      f'4 f'4 f'4 |
      ges'4 ges'4 ees'4 |
      a'4 a'4 a'4 |
      bes'4 bes'4 ges'4 |
      f'4 f'4 f'4 |
      f'4\mf des'4 bes4 |
      c'4 c'4 aes4 |
      bes4 bes4 bes4 |
      c'4 a4 a4 |
      bes4 ges4 ees4 |
      a4 a4 f4 |
      bes4 bes4 bes4 |
      c'4 a4 a4 |
      bes4 des'4 bes4 |
      c'4 c'4 aes4 |
      bes4 bes4 bes4 |
      c'4 a4 f4 |
      ges4 ges4 ees4 |
      a4 a4 a4 |
      bes4. des'4. |
      a4. c'4. |
      des'4.\mp f'4. |
      f'4. aes'4. |
      ges'4. bes'4. |
      ges'4. ges'4. |
      f'4.\p des'4. |
      a4. c'4. |
      des'4. bes4. |
      bes2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key bes \minor \time 3/4
      bes,,2.\p |
      aes,,2. |
      ges,,2. |
      f,,2. |
      ees,,2. |
      f,,2. |
      ges,,2. |
      f,,2. |
      bes,,2.\mp |
      aes,,2. |
      ges,,2. |
      f,,2. |
      ees,,2. |
      f,,2. |
      ges,,2. |
      f,,2. |
      bes,,2.\mf |
      aes,,2. |
      ges,,2. |
      f,,2. |
      ees,,2. |
      f,,2. |
      ges,,2. |
      f,,2. |
      bes,,2. |
      aes,,2. |
      ges,,2. |
      f,,2. |
      ees,,2. |
      f,,2. |
      ges,,2. |
      f,,2. |
      bes,,2.\mp |
      des,2. |
      ees,2. |
      ees,2. |
      f,2.\p |
      f,2. |
      bes,,2. |
      bes,,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
