\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "VII. Prelude in E-flat major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key ees \major \time 4/4
      \tempo "Maestoso, ma cantabile" 4 = 72
      \mark \markup \box \small "Opening cell" g''2\p bes''2 |
      aes''2 c'''2~^\markup { \tiny \italic "Prepared suspension" } |
      c'''8 bes''8^\markup { \tiny \italic "Resolution" } bes''8 c'''8 bes''2 |
      aes''2 aes''2 |
      f''2 f''2 |
      g''2 g''2 |
      ees''4 g''8 aes''8 g''4 ees''4 |
      d''4 ees''8 d''8 ees''4 d''4 |
      \mark \markup \box \small "Contrasting span" aes''4\mp g''8 aes''8 g''4 aes''4 |
      aes''4 bes''8 c'''8 bes''4 aes''4 |
      a''4 c'''8 d'''8 c'''4 c'''4~^\markup { \tiny \italic "Prepared suspension" } |
      c'''8 bes''8^\markup { \tiny \italic "Resolution" } aes''8 bes''8 aes''4 bes''4 |
      g''4 aes''8 g''8 f''4 ees''4 |
      g''4 aes''8 g''8 aes''4 g''4 |
      ees''4 g''8 aes''8 g''4 ees''4 |
      ees''4 f''8 ees''8 f''4 ees''4 |
      \mark \markup \box \small "Return" g''4\mp aes''8 bes''8 aes''4 bes''4 |
      aes''4 bes''8 ces'''8 bes''4 aes''4 |
      ces'''4 ces'''8 c'''8 ces'''2 |
      bes''2 bes''2 |
      \mark \markup \box \small "Cadence" g''2\p g''2 |
      aes''2 aes''2 |
      f''4 g''8 f''8 d''2 |
      ees''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key ees \major \time 4/4
      g'2\p g'2 |
      ees'2 c'2 |
      g2 bes2 |
      aes2 c'2 |
      d'2 f'2 |
      g'2 bes'2 |
      g'2 ees'2 |
      bes2 d'2 |
      c'2\mp ees'2 |
      c'2 c'2 |
      a2 c'2 |
      d'2 f'2 |
      ees'2 ees'2 |
      b2 d'2 |
      ees'2 ees'2 |
      c'2 c'2 |
      bes2\mp bes2 |
      ces'2 ees'2 |
      ces'2 fes'2 |
      d'2 f'2 |
      g'2\p bes'2 |
      c''2 ees''2 |
      d''2 bes'2 |
      bes'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key ees \major \time 4/4
      g1\p |
      ees1 |
      bes,1 |
      c1 |
      f1 |
      bes1 |
      g1 |
      d1 |
      ees1\mp |
      c1 |
      c1 |
      d1 |
      ees1 |
      d1 |
      g1 |
      ees1 |
      g1\mp |
      ees1 |
      aes1 |
      f1 |
      g1\p |
      ees1 |
      aes1 |
      g1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key ees \major \time 4/4
      ees,1\p |
      aes,1 |
      g,1 |
      aes,1 |
      bes,1 |
      ees,1 |
      c,1 |
      g,1 |
      aes,1\mp |
      aes,1 |
      f,1 |
      bes,1 |
      c1 |
      g,1 |
      c,1 |
      aes,,1 |
      g,,1\mp |
      aes,,1 |
      aes,,1 |
      bes,,1 |
      ees,1\p |
      aes,1 |
      bes,1 |
      ees,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
