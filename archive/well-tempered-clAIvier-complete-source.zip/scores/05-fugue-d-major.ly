\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "V. Fugue in D major — The open gate"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key d \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 104
      \mark \markup \box \small "Continuous exposition" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''2^\markup { \tiny \italic "Real answer" } e'''8 d'''8 cis'''4 |
      fis'''4 e'''4 d'''8 cis'''8 b''4 |
      cis'''2 a''2 |
      b''4.^\markup { \tiny \italic "Countersubject" } cis'''16 b''16 cis'''4 d'''4~ |
      d'''8 e'''16 d'''16 cis'''4 b''4 cis'''4 |
      d'''4. cis'''8 b''2 |
      a''2 e''2 |
      a''4 b''2. |
      e''2 fis''2 |
      \mark \markup \box \small "Six-part sequential release" fis''2 e''4^\markup { \tiny \italic "Subject-head fragment" } b''4 |
      a''2 d''4^\markup { \tiny \italic "Subject-head fragment" } a''4 |
      \mark \markup \box \small "Relative-minor interior" b''4. cis'''8 d'''2~ |
      d'''2 cis'''2 |
      b''1 |
      \mark \markup \box \small "Subject-head sequence" e''4^\markup { \tiny \italic "Subject-head fragment" } b''4 a''2 |
      d''4^\markup { \tiny \italic "Subject-head fragment" } a''4 b''2 |
      \mark \markup \box \small "The six parts reconvene" b''2 cis'''4 a''4~ |
      a''1 |
      \mark \markup \box \small "Stretto" fis''8 e''8 d''4 fis''2 |
      d''4 e''8 fis''8 g''2 |
      d'''2^\markup { \tiny \italic "Stretto subject" } a'''8 g'''8 fis'''4 |
      b'''4 a'''4 g'''8 fis'''8 e'''4 |
      fis'''2 d'''2 |
      \mark \markup \box \small "Six-part final return" d'''4. e'''8 fis'''2 |
      b''4 fis''4 b''8 a''8 g''4 |
      a''2 g''2 |
      \mark \markup \box \small "Cadential head sequence" g''4. fis''8 e''4^\markup { \tiny \italic "Subject-head fragment" } b''4 |
      cis'''8 b''8 a''4 d''4^\markup { \tiny \italic "Subject-head fragment" } a''4 |
      \mark \markup \box \small "Final cadence" g''2 a''4 cis'''4 |
      d'''1^\markup { \tiny \italic "Cadential tonic arrival" } |
      d'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key d \major \time 4/4
      r1 |
      r1 |
      r1 |
      a''2^\markup { \tiny \italic "Real answer" } e'''8 d'''8 cis'''4 |
      fis'''4 e'''4 d'''8 cis'''8 b''4 |
      cis'''2 a''2 |
      fis''4. e''8 d''4. cis''8 |
      b'4.^\markup { \tiny \italic "Countersubject" } cis''16 b'16 cis''4 d''4~ |
      d''8 e''16 d''16 cis''4 b'4 cis''4 |
      d''4. cis''8 b'2 |
      d''2 e''4. d''8 |
      cis''4 b'8 cis''8 d''4 e''4~ |
      e''2 d''4 cis''4 |
      d''2 cis''8 b'8 a'4 |
      d''4 e''8 fis''8 g''2 |
      d''2 fis''2 |
      cis''1 |
      d''4 b'4. cis''8 d''4~ |
      d''8 cis''4. fis''4. e''8 |
      d''4. cis''8 b'4 e''4~ |
      e''2 d''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'2 a'2~ |
      a'2 d''2 |
      d'4 fis'4 fis''4 a'4 |
      g'4 e'2 e''4 |
      a'4 d'8 e'8 fis'4 fis''4 |
      d''2 g'4 e''4 |
      a''4. g''8 fis''4 b''4 |
      b'4.^\markup { \tiny \italic "Countersubject" } cis''16 b'16 cis''4 d''4~ |
      d''8 e''16 d''16 cis''4 b'4 cis''4 |
      d''4. cis''8 b'2 |
      d''2 e''4 g''4 |
      e''8 d''8 cis''4 d''2 |
      d''8 cis''8 b'4 cis''4 a'4~ |
      a'1 |
      a'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key d \major \time 4/4
      d''2^\markup { \tiny \italic "Subject" } a''8 g''8 fis''4 |
      b''4 a''4 g''8 fis''8 e''4 |
      fis''2 d''2 |
      fis'4.^\markup { \tiny \italic "Countersubject" } gis'16 fis'16 gis'4 a'4~ |
      a'8 b'16 a'16 gis'4 fis'4 gis'4 |
      a'4. gis'8 fis'2 |
      fis'2 g'2~ |
      g'8 fis'4 g'8 a'2 |
      d''4 a'4 b'8 a'8 g'4 |
      a'2 b'2 |
      a'8 gis'8 fis'4 e'2 |
      a'4 b'4 a'4 b'4~ |
      b'8 a'2. gis'8 |
      fis'1 |
      g'4 e'4. fis'8 g'4 |
      a'4. g'8 fis'2 |
      fis'8 gis'8 a'4 cis''4 e''4 |
      fis''4 b'8 cis''8 d''2 |
      e''2 a'2 |
      fis'4 b'4 g'4 e'4~ |
      e'2 fis'2 |
      b'2^\markup { \tiny \italic "Relative-key subject" } fis''4 d''8 e''16 fis''16 |
      g''4 fis''4 e''8 d''8 cis''4 |
      d''2 b'2 |
      b'2 cis''8 b'8 a'4 |
      fis'2 g'2 |
      g'8 fis'8 e'2. |
      d'4 a2. |
      a4 b4 cis'4 a'4 |
      b'4 e'4. d'8 cis'4 |
      d'4 d''4 d'2~ |
      d'2 e'8 d'8 cis'4 |
      cis'2 d'4 d'4 |
      fis'4 g'4 a'2 |
      fis'4 cis'8 d'8 e'4 g'4 |
      d''1 |
      d''8 cis''8 b'4 g'2 |
      a'1 |
      d'2 a2 |
      fis'4. g'8 a'2 |
      a'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key d \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a2 b2 |
      d'2^\markup { \tiny \italic "Subject" } a'8 g'8 fis'4 |
      b'4 a'4 g'8 fis'8 e'4 |
      fis'2 d'2 |
      fis4.^\markup { \tiny \italic "Countersubject" } gis16 fis16 gis4 a4~ |
      a8 b16 a16 gis4 fis4 gis4 |
      a4. gis8 fis2 |
      fis4. g8 a2 |
      b4 e'2. |
      a2 b2 |
      cis'4. d'8 e'2 |
      a4 e'4 b2 |
      a4. b8 cis'2 |
      b1 |
      e2 a2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4. fis8 e2 |
      fis4. g8 a2 |
      fis'2 cis''4 cis'4 |
      d'4 a'4 e'4 g4 |
      fis8 g8 a4 d4 b4 |
      d4 a4 e'4 g4 |
      a8 b8 cis'4 a4 b4 |
      d'2^\markup { \tiny \italic "Subject" } a'8 g'8 fis'4 |
      b'4 a'4 g'8 fis'8 e'4 |
      fis'2 d'2 |
      b2. e'4 |
      a'1 |
      b'2 e'2 |
      d'1 |
      d'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "bass" \key d \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d2^\markup { \tiny \italic "Subject" } a8 g8 fis4 |
      b4 a4 g8 fis8 e4 |
      fis2 d2 |
      fis4.^\markup { \tiny \italic "Countersubject" } gis16 fis16 gis4 a4~ |
      a8 b16 a16 gis4 fis4 gis4 |
      a4. gis8 fis2 |
      b,4^\markup { \tiny \italic "Subject-head fragment" } fis4 g2 |
      a4^\markup { \tiny \italic "Subject-head fragment" } e'4 a2 |
      g4.^\markup { \tiny \italic "Countersubject" } a16 g16 a4 b4~ |
      b8 cis'16 b16 a4 g8 fis8 e4 |
      fis2 g2 |
      g2 a4^\markup { \tiny \italic "Subject-head fragment" } e'4 |
      d'4 a4 g4^\markup { \tiny \italic "Subject-head fragment" } d'4 |
      e'2 a2 |
      fis1 |
      fis'4 fis8 g8 a2 |
      d'4 cis'4 b4 g4 |
      a4 d'4 a4 d'4 |
      b4 d4 cis8 d8 e4 |
      cis4 a4 d'2 |
      d8 cis8 b,4 a,2 |
      d4 fis4 g2 |
      fis8 e8 d2. |
      g4^\markup { \tiny \italic "Subject-head fragment" } d'4 b2 |
      a4^\markup { \tiny \italic "Subject-head fragment" } e'4 d'2 |
      b8 a8 g4 e2 |
      fis1 |
      fis1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "bass" \key d \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,2^\markup { \tiny \italic "Real answer" } e8 d8 cis4 |
      fis4 e4 d8 cis8 b,4 |
      cis2 a,2 |
      b,8 cis8 d4 e2 |
      cis2 d8 e8 fis4 |
      e2 d4. cis8 |
      b,4 d4 e2 |
      d2 e2 |
      e4. d8 cis2 |
      d4. cis8 b,4. a,8 |
      g,2 a,4 cis4 |
      d1 |
      d2^\markup { \tiny \italic "Stretto subject" } a8 g8 fis4 |
      b4 a4 g8 fis8 e4 |
      fis2 d2 |
      d4 fis,4 e,4 e4 |
      a,4 fis,4 fis4 g4 |
      b,4 g,4 fis,2 |
      d4 a,4 e,2 |
      d,8 e,8 fis,4 g,4 b,4 |
      b,2 e2 |
      a,2 fis,2 |
      g,4 b,4 a,2 |
      d1^\markup { \tiny \italic "Cadential tonic bass" } |
      d1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
