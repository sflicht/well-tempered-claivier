\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XIV. Prelude in F-sharp minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key fis \minor \time 3/4
      \tempo "Moderato, sempre danzante" 4 = 86
      \mark \markup \box \small "Chaconne stated" fis''4\p cis''8 fis'8 cis''4 |
      eis''4 gis''8 cis''8 gis''4 |
      a''4 cis'''8 b''8 a''4 |
      fis''4 d''8 d''8 fis''4 |
      gis''4 b''8 e''8 b''4~^\markup { \tiny \italic "Prepared suspension" } |
      b''8 a''8^\markup { \tiny \italic "Resolution" } e''8 a'8 e''4 |
      d''4 d''8 cis''8 b'4 |
      gis'4 eis'8 eis'8 gis'4 |
      \mark \markup \box \small "Flowing variation" fis'8\mp a'8 fis''8 a'8 a'8 cis''8 |
      cis''8 eis''8 cis'''8 eis''8 eis''8 gis''8 |
      fis''8 a''8 fis'''8 a''8 a''8 cis'''8 |
      d''8 cis''8 b'8 d''8 b''8 d''8 |
      e'8 gis'8 e''8 gis'8 gis'8 b'8 |
      a'8 cis''8 a''8 cis''8 cis''8 e''8 |
      gis'8 b'8 gis''8 b'8 b'8 d''8 |
      eis'8 gis'8 cis'8 eis'8 cis''8 eis'8 |
      \mark \markup \box \small "Figured variation" fis'16\mf a'16 fis''16 a'16 a'16 gis'16 fis'16 a'16 fis''16 a'16 a'16 cis''16 |
      cis''16 eis''16 cis'''16 eis''16 eis''16 gis''16 cis''16 eis''16 cis'''16 eis''16 eis''16 gis''16 |
      fis''16 a''16 fis'''16 a''16 a''16 gis''16 fis''16 a''16 fis'''16 a''16 a''16 cis'''16 |
      d'''16 fis'''16 b''16 d'''16 b'''16 d'''16 d'''16 fis'''16 b''16 d'''16 b'''16 d'''16 |
      e''16 gis''16 e'''16 gis''16 gis''16 fis''16 e''16 gis''16 e'''16 gis''16 gis''16 b''16 |
      a''16 cis'''16 a'''16 cis'''16 cis'''16 e'''16 a''16 cis'''16 a'''16 cis'''16 cis'''16 e'''16 |
      gis''16 b''16 gis'''16 b''16 b''16 a''16 gis''16 b''16 gis'''16 b''16 b''16 d'''16 |
      eis''16 gis''16 cis''16 eis''16 cis'''16 eis''16 eis''16 gis''16 cis''16 eis''16 cis'''16 eis''16 |
      \mark \markup \box \small "Contrasting phrase" a''4. b''8 cis'''4 |
      b''4. b''8 e'''4 |
      a''4. a''8 d''4~^\markup { \tiny \italic "Prepared suspension" } |
      d''8 cis''4^\markup { \tiny \italic "Resolution" } eis'8 gis'4 |
      d''4. fis''8 b''4 |
      fis''4. cis''8 fis''4 |
      g''4. d''8 d''4 |
      gis'4. eis'8 gis'4 |
      \mark \markup \box \small "Return and cadence" a'4\mp cis''8 fis'8 cis''4 |
      d''4 a'8 d'8 a'4 |
      d''4 fis''8 e''8 d''4 |
      gis'4 eis'8 eis'8 gis'4 |
      cis''4\p cis''8 fis'8 cis''4 |
      fis''4 cis''8 fis'8 cis''4 |
      cis''4 gis'8 cis'8 eis'4 |
      fis'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key fis \minor \time 3/4
      a4.\p cis'4. |
      gis4. gis4. |
      a4. cis'4. |
      d'4. fis'4. |
      gis'4. gis'4. |
      e'4. cis'4. |
      b4. d'4. |
      cis'4. cis'4. |
      cis'4.\mp fis'4. |
      eis'4. gis'4. |
      cis''4 a'4 fis'4 |
      fis'4 d'4 b4 |
      b4 e'4 e'4 |
      e'4 cis'4 a4 |
      b4 b4 gis4 |
      cis'4 gis4 cis'4 |
      cis'4\mf a4 fis4 |
      gis4 eis4 eis4 |
      fis4 fis4 a4 |
      d'4 d'4 d'4 |
      gis'4 gis'4 e'4 |
      e'4 cis'4 cis'4 |
      d'4 b4 d'4 |
      gis'4 eis'4 cis'4 |
      e'4 cis'4 a4 |
      b4 gis4 e4 |
      fis4 fis4 fis4 |
      gis4 eis4 cis4 |
      fis4 d4 d4 |
      cis4 cis4 cis4 |
      d4. g4. |
      eis4. gis4. |
      a4.\mp cis'4. |
      d'4. a4. |
      d'4. fis'4. |
      eis'4. cis'4. |
      fis'4.\p cis'4. |
      fis'4. cis'4. |
      cis'4. b4. |
      a2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key fis \minor \time 3/4
      fis,2.\p |
      eis,2 fis,8 gis,8 |
      a,2. |
      b,2. |
      e,2. |
      a,2. |
      b,2. |
      cis2. |
      fis,2.\mp |
      eis,2 fis,8 gis,8 |
      a,2. |
      b,2. |
      e,2. |
      a,2. |
      b,2. |
      cis2. |
      fis,2.\mf |
      eis,2 fis,8 gis,8 |
      a,2. |
      b,2. |
      e,2. |
      a,2. |
      b,2. |
      cis2. |
      a,2. |
      e,2. |
      d,2. |
      cis,2. |
      b,,2. |
      a,,2. |
      b,,2. |
      cis,2. |
      fis,2.\mp |
      d,2. |
      b,,2. |
      cis,2. |
      a,,2.\p |
      cis,2. |
      cis,2. |
      fis,,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
