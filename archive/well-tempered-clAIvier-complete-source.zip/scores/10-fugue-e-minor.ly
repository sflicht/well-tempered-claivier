\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "X. Fugue in E minor — A restless circle"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a3")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key e \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 96
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'''4^\markup { \tiny \italic "Subject" } g'''4 b'''4 a'''8 g'''8 |
      fis'''2 g'''4 b'''4 |
      d'''2 e'''2 |
      g'''4^\markup { \tiny \italic "Countersubject" } fis'''8 g'''8 a'''4 g'''4 |
      a'''4. g'''8 fis'''8 g'''8 a'''4 |
      fis'''2 g'''2 |
      \mark \markup \box \small "Sequential episode" c'''4. d'''8 e'''2 |
      fis'''2 b'''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g''8 a''8 b''4 g''4 a''4 |
      d'''4 a''4 g''4 fis''4 |
      b''2 g''2 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Development" c''''2 b'''8 c''''8 d''''4~ |
      d''''2 c''''4 b'''4~ |
      b'''2 a'''2 |
      \mark \markup \box \small "Linking episode" a'''1~ |
      a'''8 gis'''4. a'''2 |
      \mark \markup \box \small "Development" b'''4^\markup { \tiny \italic "Related-key subject" } d''''4 fis''''4 e''''8 d''''8 |
      cis''''2 d''''4 fis''''4 |
      a'''2 b'''2 |
      \mark \markup \box \small "Stretto" g'''8 fis'''8 e'''4 fis'''2 |
      a'''2 b'''2 |
      b''4 fis'''4 e'''4^\markup { \tiny \italic "Stretto subject" } g'''4 |
      b'''4 a'''8 g'''8 fis'''2 |
      g'''4 b'''4 d'''2 |
      e'''2 fis'''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" b'''1~ |
      b'''1 |
      c''''4 g'''2. |
      g''''1 |
      c''''8 d''''8 e''''4 c''''2~ |
      c''''1 |
      b'''1~ |
      b'''1 |
      \mark \markup \box \small "Gathered development" e'''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } g'''2 |
      e'''2 c''''2~ |
      c''''1 |
      a''''8 g''''8 fis''''4 a'''4 c'''4 |
      a'''2~ a'''8 g'''8 fis'''4 |
      dis'''4. e'''8 fis'''2 |
      b'''4 dis''''4 fis'''2 |
      b''2 e'''2~ |
      e'''1 |
      \mark \markup \box \small "Final return" a'''4 b'''2 c''''4 |
      a'''2 g'''4 fis'''4 |
      g'''2 a'''2 |
      \mark \markup \box \small "Final cadence" a'''8 b'''8 c''''4 b'''2 |
      g'''1 |
      g'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'''4^\markup { \tiny \italic "Subject" } g'''4 b'''4 a'''8 g'''8 |
      fis'''2 g'''4 b'''4 |
      d'''2 e'''2 |
      g'''4^\markup { \tiny \italic "Countersubject" } fis'''8 g'''8 a'''4 g'''4 |
      a'''4. g'''8 fis'''8 g'''8 a'''4 |
      fis'''2 g'''2 |
      e'''1~ |
      e'''8 dis'''8 b''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'''4 fis'''2 b'''4 |
      e'''4 a''4 fis'''2 |
      d'''8 e'''8 fis'''4 b''2 |
      b''2 fis'''2~ |
      fis'''4 a'''4 d'''2 |
      fis''4 d'''4 g''2 |
      d'''4 a''4 d'''2~ |
      d'''4 b''2. |
      e'''4 a''4 fis'''2 |
      r1 |
      e'''4 b''2. |
      e'''4 b''4 e'''2 |
      c'''8 d'''8 e'''2. |
      g'''4 c'''8 d'''8 e'''2 |
      a'''4 e'''4 a''2~ |
      a''4 c'''4 e'''2~ |
      e'''4 b''4 e'''2 |
      g'''8 a'''8 b'''4 g'''2 |
      b''8 a''8 g''2. |
      e'''4. d'''8 c'''2~ |
      c'''4 e'''2 a''4~ |
      a''2 fis'''4 fis''4 |
      fis'''2. fis''4~ |
      fis''2 fis'''2~ |
      fis'''4 b''2.~ |
      b''2 e''2~ |
      e''4 g''2. |
      e'''4 g''4 d''4 a''4~ |
      a''2 d'''2~ |
      d'''4 g'''4 c'''2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''4^\markup { \tiny \italic "Real answer" } d'''4 fis'''4 e'''8 d'''8 |
      cis'''2 d'''4 fis'''4 |
      a''2 b''2 |
      c'''4^\markup { \tiny \italic "Countersubject" } b''8 c'''8 d'''4 c'''4 |
      d'''4. c'''8 b''8 c'''8 d'''4 |
      b''2 c'''2 |
      c'''2 b''2 |
      a''4 e''2 a''4 |
      g''8 a''8 b''4 g''4 e''4~ |
      e''4 g''4 c'''4 f'''4 |
      r1 |
      r1 |
      e'''4 fis'''4 cis'''4 e''4~ |
      e''4 a''4 d'''4 a''4~ |
      a''4 d'''4 g''4 b''4 |
      b''4 e'''4 d'''4 fis''4 |
      d''8 e''8 fis''4 b''2~ |
      b''4 a''4 e''4 b''4~ |
      b''4 fis''4 a''4 d'''4~ |
      d'''2 b''2 |
      e''4 a''4 fis''4 a''4 |
      r1 |
      b''8 a''8 g''4 e''4 g''4~ |
      g''4 e''2 g''4~ |
      g''2 e''4 g''4~ |
      g''4 e''4 g''4 c'''4~ |
      c'''2 a''4 c'''4~ |
      c'''4 a''4 e''4 a''4 |
      b''8 a''8 g''4 e''4 g''4~ |
      g''4 e''4 g''4 b''4 |
      g''8 a''8 b''4 g''4 e''4~ |
      e''4 g''2 c'''4~ |
      c'''2 a''2~ |
      a''4 c''4 a''2~ |
      a''4 fis'''4 fis''2~ |
      fis''4 b'4 fis''2~ |
      fis''4 b''4 fis'''4 b''4~ |
      b''4 e''4 b''4 e'''4~ |
      e'''4 c'''2 g''4 |
      a''4 g''4 d'''4 a''4~ |
      a''4 fis''4 b''2~ |
      b''4 d'''4 a''4 e''4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      b'4^\markup { \tiny \italic "Real answer" } d''4 fis''4 e''8 d''8 |
      cis''2 d''4 fis''4 |
      a'2 b'2 |
      c''4^\markup { \tiny \italic "Countersubject" } b'8 c''8 d''4 c''4 |
      d''4. c''8 b'8 c''8 d''4 |
      b'2 c''2 |
      b'4 fis'4 cis''4. b'8~ |
      b'8 a'2. b'8 |
      cis''2 d''2 |
      e''2 a''2 |
      fis''8 e''8 dis''4 e''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c''4 d''4. e''8 fis''4~ |
      fis''4 d''4 e''4 d''4~ |
      d''8 e''8 fis''4 g''8 fis''8 e''4 |
      r1 |
      a''4^\markup { \tiny \italic "Related-key subject" } c'''4 e'''4 d'''8 c'''8 |
      b''2 c'''4 e'''4 |
      g''2 a''2 |
      f''1 |
      e''1 |
      e''4 d''4 cis''8 d''8 e''4~ |
      e''2 d''4 cis''4 |
      d''2. e''4 |
      e''4 b'4 d''4 fis''4~ |
      fis''4 d''4. c''8 b'4 |
      d''8 e''8 fis''4 b''4 g''4 |
      fis''2. b'4~ |
      b'4 d''2 fis''4 |
      e''8 d''8 c''4 a'4 c''4 |
      r1 |
      e''8 fis''8 g''2 e''4~ |
      e''4 g''2 e''4~ |
      e''4 g''2 e''4~ |
      e''4 g''2 e''4~ |
      e''4 a''2 e''4~ |
      e''4 c''2 e''4~ |
      e''4 g''2 e''4~ |
      e''4 g''2 e''4 |
      b'2 b''4 g''4~ |
      g''2 e''2~ |
      e''1 |
      c''2~ c''8 b'8 a'4 |
      a''2 a'2 |
      fis''4. e''8 dis''2~ |
      dis''4 fis''4 dis'''4 dis''4 |
      e''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } g''2 |
      g'2 c''4 e''4 |
      a'4 d''2 e''4 |
      fis''8 e''8 d''2. |
      g''8 a''8 b''4 a''4 c'''4 |
      a''4 e''4 b''4 fis''4 |
      g''8 fis''8 e''2 b'4~ |
      b'4 e''2 g''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'4^\markup { \tiny \italic "Real answer" } d''4 fis''4 e''8 d''8 |
      cis''2 d''4 fis''4 |
      a'2 b'2 |
      c''4^\markup { \tiny \italic "Countersubject" } b'8 c''8 d''4 c''4 |
      d''4. c''8 b'8 c''8 d''4 |
      b'2 c''2 |
      d''2 cis''4. d''8 |
      e''2 fis''2~ |
      fis''4 cis''4 d''2 |
      e''4. d''8 c''8 b'8 a'4 |
      b'4. a'8 g'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'8 g'8 f'4 a'2 |
      e''4 b'4 c''4 a'4 |
      e'4 a'8 b'8 cis''4 b'4 |
      a'8 b'8 cis''4 a'4 fis'4~ |
      fis'4 a'4 d''4 b'4 |
      b'8 a'8 g'4 fis'4 a'4~ |
      a'4 d''4 b'4 d''4 |
      b'8 c''8 d''4 b'2~ |
      b'4 c''4 a'4 b'4 |
      g'4 fis'4 b'2~ |
      b'4 e''4 c''4 a'4 |
      r1 |
      g'4 e'4 g'4 b'4~ |
      b'4 e''4 b'4 g'4~ |
      g'4 e'4 g'4 c''4~ |
      c''4 e''4 c''4 e''4 |
      c''8 b'8 a'4 c''4 a'4 |
      c''8 d''8 e''4 c''4 a'4 |
      g'8 fis'8 e'4 g'4 b'4~ |
      b'4 e''4 b'4 g'4 |
      e'4 g'4 b'4 e''4~ |
      e''4 c''4 e''4 c''4~ |
      c''4 a'2 c''4~ |
      c''4 a'4 fis'4 a'4~ |
      a'4 fis'4 a'4 fis''4~ |
      fis''2 b'2~ |
      b'4 fis'4 b'2~ |
      b'4 e''4 b'4 g'4~ |
      g'4 e'4 g'4 e'4 |
      e'4 d'8 e'8 fis'4 a'4 |
      d''8 e''8 fis''4 d''4 b'4~ |
      b'4 g'4 c''4 a'4 |
      a'4. g'8 fis'4 b'4~ |
      b'4 e''4 b'4 g'4~ |
      g'4 e'4 g'4 b'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4^\markup { \tiny \italic "Subject" } g'4 b'4 a'8 g'8 |
      fis'2 g'4 b'4 |
      d'2 e'2 |
      g'4^\markup { \tiny \italic "Countersubject" } fis'8 g'8 a'4 g'4 |
      a'4. g'8 fis'8 g'8 a'4 |
      fis'2 g'2 |
      g'2. fis'4~ |
      fis'2 e'4 fis'4~ |
      fis'2 e'2 |
      e'2 dis'4 e'4 |
      f'4 g'4 e'4 f'4 |
      d'2 g'4 b'4 |
      g'8 f'8 e'4 c'8 b8 a4 |
      c'2 f'4 a'4 |
      e'2 a'4 c''4~ |
      c''8 b'8 a'4 fis'4 g'4 |
      e'2 a'4 cis''4 |
      a'8 g'8 fis'4 d'4 g'4 |
      g''2 d''4 c''4 |
      d''2. g'4 |
      b'4 d'4 g'4 b'4 |
      fis'2~ fis'8 e'8 d'4~ |
      d'2. b4~ |
      b4 c'2. |
      r1 |
      g''1~ |
      g''2. g'4~ |
      g'4 c''2.~ |
      c''1 |
      e'4 c'4 e'2~ |
      e'1 |
      g'1~ |
      g'1 |
      g'2 e'2 |
      g'8 fis'8 e'4 g'4 e'4 |
      c'4. d'8 e'4 a'4 |
      c''2 a'4 fis'4 |
      a'4. g'8 fis'2~ |
      fis'4 b'4 fis'4 b'4 |
      fis'2. b'4~ |
      b'4. a'8 g'4 e'4 |
      g'4. fis'8 e'4 c'4 |
      e'4^\markup { \tiny \italic "Subject" } g'4 b'4 a'8 g'8 |
      fis'2 g'4 b'4 |
      d'2 e'2 |
      e'2 dis'2 |
      e'4. fis'8 g'2 |
      g'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key e \minor \time 4/4
      e'4^\markup { \tiny \italic "Subject" } g'4 b'4 a'8 g'8 |
      fis'2 g'4 b'4 |
      d'2 e'2 |
      g4^\markup { \tiny \italic "Countersubject" } fis8 g8 a4 g4 |
      a4. g8 fis8 g8 a4 |
      fis2 g2 |
      a4 b8 a8 g4 a4 |
      b2.~ b8 c'8 |
      d'2 c'2 |
      d'2 cis'2~ |
      cis'8 b8 a2.~ |
      a8 b8 cis'4 b2 |
      c'8 d'8 e'4 c'4 e'4 |
      dis'8 e'8 fis'4 g'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4 d'4 b4 c'4 |
      a2 b4. c'8 |
      d'2 c'2 |
      r1 |
      c'8 d'8 e'4 b4 a4 |
      b2 e'4 b4 |
      e'2 a'2 |
      a'2 d'2 |
      b'2 a'2 |
      g'4 d'4 a4 b4 |
      cis'8 b8 a2. |
      d'2 b2 |
      e'2 b4 c'4 |
      a2 d'2 |
      fis'2 g'2 |
      d'4 c'4 d'2 |
      b4. c'8 d'2 |
      b4 a4 c'2 |
      r1 |
      e'2 b2 |
      g4. a8 b2 |
      e'4. d'8 c'2 |
      g2 c'2 |
      e'2. c'4 |
      a4. b8 c'2 |
      e'2 b2 |
      g4. a8 b2 |
      b2 e'2 |
      g2 c'2 |
      e'4. d'8 c'2 |
      a1 |
      fis'1 |
      fis2 b2 |
      fis'2 b2~ |
      b8 a8 g4 e'4 g'4 |
      e'4. d'8 c'2 |
      c'4 d'8 c'8 b4 e'4 |
      d'4 a4 b2 |
      d'2 c'2 |
      e'2 b2~ |
      b4 g4 b2 |
      e'8 fis'8 g'4 e'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "bass" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4^\markup { \tiny \italic "Subject" } g4 b4 a8 g8 |
      fis2 g4 b4 |
      d2 e2 |
      g4^\markup { \tiny \italic "Countersubject" } fis8 g8 a4 g4 |
      a4. g8 fis8 g8 a4 |
      fis2 g2 |
      a4 g2 a4 |
      b1~ |
      b2 a2 |
      b4 a4. b8 cis'4~ |
      cis'4 a2.~ |
      a2 g2 |
      g2 a2 |
      fis4 b,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a4 g2 d4~ |
      d2 e2 |
      g2 f2 |
      f4 c4 d2 |
      b,4 e2~ e8 f8 |
      g4 a2 e4~ |
      e4 cis4 fis2 |
      a2 g2 |
      g2 d'4 a4~ |
      a2 g2~ |
      g8 fis8 a4 g4 e4 |
      fis4. e8 d4 fis4 |
      d4. e8 fis4 b4 |
      g8 fis8 e4 a4 fis4 |
      r1 |
      g2 b4 g4 |
      b4. a8 g4 b4 |
      g2 c'4 e'4 |
      c'4 g4 e4 g4 |
      a4 c'2 e'4 |
      c'2 a4 c'4 |
      g2 b4 g4 |
      b4 g4 e4 g4 |
      g'2 b2 |
      e4 c'4 g2 |
      a1 |
      fis1 |
      dis1 |
      b,2. fis4~ |
      fis1 |
      g4. a8 b2 |
      c'2 g2 |
      c'4 g4 fis4 e4 |
      a2 d4 fis4 |
      b2 e'4 c'4 |
      e4 a4 fis'4 b4~ |
      b2 g4 e4 |
      g4. a8 b4 g4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "bass" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4^\markup { \tiny \italic "Subject" } g4 b4 a8 g8 |
      fis2 g4 b4 |
      d2 e2 |
      e4 a4 b8 a8 g4 |
      c4 g,2 a,4 |
      d4 g2. |
      b,4 e4 a,4 c4 |
      r1 |
      r1 |
      e4 a,2 e4 |
      a4 e4 fis4 cis4 |
      fis4 d2 g,4 |
      g,4 b,2 fis4~ |
      fis2 d4 g4 |
      d4 a,4 e4 b,4 |
      d4 fis2. |
      b,2. fis,4 |
      g,4 c2. |
      r1 |
      g,4 b,2 e4 |
      b4 g2. |
      e4 c4 e4 c4 |
      e2~ e8 d8 c4 |
      a,2. e4 |
      a4 e2. |
      b,4 e2 b,4 |
      e4 b,2 e4 |
      g4 e2 g4~ |
      g4 c2 e4~ |
      e4 c2 a,4~ |
      a,4 fis2. |
      a,2 fis2~ |
      fis1 |
      b,1~ |
      b,4 g4 e2 |
      g,4 c4 e4 g4 |
      e4 b,4 fis4 a,4~ |
      a,4 d2. |
      g,4. fis,8 e,4 a,4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "bass" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,4^\markup { \tiny \italic "Real answer" } d4 fis4 e8 d8 |
      cis2 d4 fis4 |
      a,2 b,2 |
      e,2 c2 |
      b,2 g,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 c4 g,4 d4~ |
      d4 g,2~ g,8 a,8 |
      b,4 g4 c4 f,4 |
      r1 |
      r1 |
      b,4 fis2 b,4 |
      e2 a,2~ |
      a,4 fis4 b4 g4 |
      b2 fis4 a,4~ |
      a,4 fis,4 d4 b4~ |
      b4 fis4 b,2~ |
      b,4 fis2 b4~ |
      b4 fis2 d4 |
      g4 c2. |
      r1 |
      b,2 g,2~ |
      g,4 b,2 e4 |
      g4 c2 g,4~ |
      g,4 c2 g,4 |
      e,2. a,4 |
      e,4 a,2 e,4~ |
      e,4 b,2 e,4~ |
      e,4 b,2. |
      b,4 e2 g,4~ |
      g,4 c2 e,4~ |
      e,4 a,4 e,4 c,4~ |
      c,4 a,2 fis4~ |
      fis4 fis,2.~ |
      fis,4 fis2 b,4~ |
      b,4 b,,2. |
      b,2. e,4~ |
      e,4 c2. |
      e,4 b,4 b4 e4 |
      a,4 d,2 b,4~ |
      b,2 e,2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key e \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,,4^\markup { \tiny \italic "Real answer" } d,4 fis,4 e,8 d,8 |
      cis,2 d,4 fis,4 |
      a,,2 b,,2 |
      c,1 |
      b,,4 dis,,4 e,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4^\markup { \tiny \italic "Countersubject" } e,8 f,8 g,4 f,4 |
      g,4. f,8 e,8 f,8 g,4 |
      e,2 f,2 |
      f,2~ f,8 e,8 d,4 |
      e,4. d,8 c,2 |
      g,4^\markup { \tiny \italic "Countersubject" } fis,8 g,8 a,4 g,4 |
      a,4. g,8 fis,8 g,8 a,4 |
      fis,2 g,2 |
      e,4^\markup { \tiny \italic "Stretto subject" } g,4 b,4 a,8 g,8 |
      fis,2 g,4 b,4 |
      d,2 e,2 |
      d,4 a,4 d,4 b,,4~ |
      b,,2. d,4 |
      g,,4 a,,2. |
      r1 |
      e,1~ |
      e,1~ |
      e,1~ |
      e,1 |
      a,,1~ |
      a,,1 |
      e,1~ |
      e,1 |
      e,1 |
      c,1 |
      a,,1~ |
      a,,1 |
      fis,,1 |
      b,,1~ |
      b,,1 |
      e,2.~ e,8 d,8 |
      c,1 |
      c,4^\markup { \tiny \italic "Countersubject" } b,,8 c,8 d,4 c,4 |
      d,4. c,8 b,,8 c,8 d,4 |
      b,,2 c,2 |
      c,4 a,,4 b,,2 |
      e,1 |
      e,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
