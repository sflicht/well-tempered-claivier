\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXIV. Fugue in B minor — All the threads"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a2")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key b \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 84
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2^\markup { \tiny \italic "Subject" } fis'''4 g'''4 |
      e'''2 d'''4 fis'''4 |
      d'''2 b''2 |
      d'''2^\markup { \tiny \italic "Countersubject" } e'''4 fis'''8 e'''8 |
      d'''2 cis'''8 d'''8 e'''8 d'''8 |
      cis'''2 d'''2 |
      d'''2 a''4 g''4~ |
      g''2 a''2 |
      d'''2.~ d'''8 cis'''8 |
      \mark \markup \box \small "Sequential episode" b''2 ais''4 b''4 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2 cis'''8 d'''8 e'''4 |
      b''4. cis'''8 d'''4 cis'''8 b''8 |
      a''2 g''2 |
      d'''2 cis'''4 a''4 |
      b''2 cis'''2~ |
      cis'''4 fis''8 gis''8 a''2 |
      b''2 d''4 g''4~ |
      g''2 d''2 |
      a''4 d'''2. |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 4" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Exposition 5" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" fis'''2 e'''4 d'''4~ |
      d'''2 e'''2 |
      a''2 b''2 |
      \mark \markup \box \small "Linking episode" d'''2 fis'''2 |
      eis'''2 fis'''2 |
      \mark \markup \box \small "Development" e'''2^\markup { \tiny \italic "Related-key subject" } b'''4 c''''4 |
      a'''2 g'''4 b'''4 |
      g'''2 e'''2 |
      g'''2 fis'''4 d'''4 |
      e'''2 fis'''2~ |
      fis'''4 d'''4 e'''2 |
      \mark \markup \box \small "Stretto" d'''1 |
      g'''2 b''4 ais''8 b''16^\markup { \tiny \italic "Upward leading-note resolution in an ascending scalar line" } cis'''16 |
      d'''4 b''4 b''2^\markup { \tiny \italic "Stretto subject" } |
      fis'''4 g'''4 e'''2 |
      d'''4 fis'''4 d'''2 |
      b''2 a''4 g''4 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" b''1^\markup { \tiny \italic "Augmented subject" } |
      fis'''2 g'''2 |
      e'''1 |
      d'''2 fis'''2 |
      d'''1 |
      b''1 |
      fis'''4 b'''2 d''''4 |
      d'''1 |
      \mark \markup \box \small "Gathered development" b''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      fis'''2 d'''2 |
      b''4 g'''4 b'''2 |
      d''''4 b'''4 d'''2 |
      e'''4 g'''2 b'''4~ |
      b'''2 e'''4 g''4~ |
      g''1~ |
      g''1 |
      e'''1~ |
      e'''1 |
      cis'''2. ais''4 |
      fis'''2 cis'''2~ |
      cis'''1~ |
      cis'''4 ais''4 cis'''2 |
      d'''4 d''''4 fis'''4 d''''4 |
      b'''4 d'''2. |
      b''2 g'''4 b'''4~ |
      b'''2 d'''2 |
      \mark \markup \box \small "Final return" d'''2 cis'''4 b''4~ |
      b''2 d'''4 cis'''4 |
      d'''2 e'''2 |
      \mark \markup \box \small "Final cadence" e'''4 b''4 ais''4 cis'''4 |
      d'''1 |
      d'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2^\markup { \tiny \italic "Subject" } fis'''4 g'''4 |
      e'''2 d'''4 fis'''4 |
      d'''2 b''2 |
      d'''2^\markup { \tiny \italic "Countersubject" } e'''4 fis'''8 e'''8 |
      d'''2 cis'''8 d'''8 e'''8 d'''8 |
      cis'''2 d'''2 |
      d'''2. g''4 |
      e'''2 b''8 cis'''8 d'''4~ |
      d'''1 |
      b''2. e''4 |
      fis''4. e''8 d''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''4 b''4 fis''2 |
      b''2 fis''4 d'''8 cis'''8 |
      b''2 fis''2~ |
      fis''8 e''8 d''4 g''2~ |
      g''8 fis''4. cis''4 a''4 |
      d'''2 a''4 gis''4 |
      cis'''2 fis''4. e''8 |
      d''2. b''4~ |
      b''2 d''2 |
      b''4. a''8 g''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g''4 d''4 a''4 d''4 |
      b''2. fis'''4 |
      fis''4 d'''4 g''2~ |
      g''8 fis''4. cis''4 fis''4 |
      d'''2 a''4 e'''4 |
      e''4 a''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2. d''4 |
      b''1~ |
      b''2 b'2 |
      b''1~ |
      b''4 d''2. |
      b''2 d''2 |
      b''2 d''2 |
      b''4 d''4 b''2 |
      b''2 d''2 |
      b''4 b'4 b''2 |
      b'2 b''2~ |
      b''4 b'4 g''2~ |
      g''2 e'''2~ |
      e'''4 e''2.~ |
      e''1~ |
      e''1~ |
      e''1 |
      e'''2. e''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''4 d''2. |
      d'''1 |
      d''1 |
      b''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''1 |
      b''2^\markup { \tiny \italic "Subject" } fis'''4 g'''4 |
      e'''2 d'''4 fis'''4 |
      d'''2 b''2 |
      d'''2^\markup { \tiny \italic "Countersubject" } e'''4 fis'''8 e'''8 |
      d'''2 cis'''8 d'''8 e'''8 d'''8 |
      cis'''2 d'''2 |
      b''4. cis'''8 d'''8 cis'''8 b''4~ |
      b''2 fis''2 |
      b''2 d'''2 |
      g''1~ |
      g''8 fis''2.~ fis''8 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g''8 a''8 b''4 fis''4 b'4~ |
      b'2 fis''2~ |
      fis''4 b''4. a''8 g''4 |
      d'''4 a''8 b''8 cis'''4 fis''4 |
      gis''8 a''8 b''4 fis''4 cis'''4~ |
      cis'''2 fis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2 d''2~ |
      d''4 b''2.~ |
      b''4 b'4 b''2~ |
      b''4 b'2 b''4~ |
      b''2 d''2~ |
      d''4 b''2 d''4~ |
      d''4 d'''2 fis''4~ |
      fis''4 d'''2. |
      fis''1~ |
      fis''4 d'''2 fis''4 |
      b'2. b''4~ |
      b''1 |
      e'''2 g''2 |
      e'''2. e''4~ |
      e''1~ |
      e''1 |
      e'''2. e''4~ |
      e''2 e'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2 d''2~ |
      d''4 b''2.~ |
      b''2 d''2~ |
      d''4 d'''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2^\markup { \tiny \italic "Subject" } fis'''4 g'''4 |
      e'''2 d'''4 fis'''4 |
      d'''2 b''2 |
      d'''2^\markup { \tiny \italic "Countersubject" } e'''4 fis'''8 e'''8 |
      d'''2 cis'''8 d'''8 e'''8 d'''8 |
      cis'''2 d'''2 |
      cis'''2 b''2~ |
      b''4. cis'''8 d'''2 |
      e'''4 b''4 fis''2 |
      b'1 |
      g''2 fis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''2 a''4 d''4 |
      g'8 a'8 b'2 fis''4~ |
      fis''4 b''2 g''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''4 d''2 b''4~ |
      b''4 d''2 b''4~ |
      b''1~ |
      b''4 d''2 d'''4~ |
      d'''4 fis''2 b'4~ |
      b'4 fis''2.~ |
      fis''4 d'''2. |
      fis''2. b'4 |
      b'4 fis''2.~ |
      fis''4 b'2 b''4~ |
      b''4 d''2 b''4~ |
      b''2. b'4~ |
      b'4 g''2. |
      b'2. g''4~ |
      g''4 g'4 e''2~ |
      e''1~ |
      e''4 e'''2. |
      e''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'''4 fis'''2 fis''4~ |
      fis''2 b'2~ |
      b'4 b''2.~ |
      b''4 d''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2^\markup { \tiny \italic "Subject" } fis'''4 g'''4 |
      e'''2 d'''4 fis'''4 |
      d'''2 b''2 |
      d''2^\markup { \tiny \italic "Countersubject" } e''4 fis''8 e''8 |
      d''2 cis''8 d''8 e''8 d''8 |
      cis''2 d''2 |
      b'2 d''2 |
      e''4 g''4 a''2~ |
      a''4 fis''4 d''2 |
      d''2 e''2 |
      cis''2 d''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'4 fis''2 b''4~ |
      b''2 d''4 g'4~ |
      g'2 g''2~ |
      g''4 b'2.~ |
      b'4 fis''4 b''4 d''4~ |
      d''4 fis''2 b'4~ |
      b'2 b''2~ |
      b''4 fis''2. |
      b'2. fis''4~ |
      fis''2 b'4 fis''4 |
      g''2 d'''2~ |
      d'''4 g''2 d''4 |
      g''2. b'4~ |
      b'4 g''2 b'4 |
      cis''4 e''2.~ |
      e''4 e'2 e''4~ |
      e''2 e'''2~ |
      e'''4 e''2. |
      fis''4 cis''4 fis''2~ |
      fis''4 cis'''4 fis''4 cis''4~ |
      cis''4 fis''2 cis''4~ |
      cis''4 fis''2. |
      d''4 b'4 d''4 fis''4~ |
      fis''4 d''2. |
      g''2. d'''4~ |
      d'''4 g''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      fis''2^\markup { \tiny \italic "Real answer" } cis'''4 d'''4 |
      b''2 a''4 cis'''4 |
      a''2 fis''2 |
      g''2^\markup { \tiny \italic "Countersubject" } a''4 b''8 a''8 |
      g''2 fis''8 g''8 a''8 g''8 |
      fis''2 g''2 |
      a''2 gis''4 fis''4~ |
      fis''2. e''4 |
      fis''2~ fis''8 e''8 d''4 |
      d''4. e''8 fis''4 e''4~ |
      e''2 fis''8 e''8 d''4~ |
      d''2. b'4 |
      b'2 fis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''4. cis''8 b'4 d''4 |
      g''2 fis''4 b''4 |
      e''2 fis''4 cis''4 |
      fis''2 b''8 a''8 g''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''2 a'4 d''4 |
      g''8 fis''8 e''4 b''4 fis''4 |
      b'4. a'8 g'8 a'8 b'4 |
      d'4 a'4 e'4 a'4 |
      d''2 a''4 e''4 |
      a'2 d''8 e''8 fis''4 |
      fis''2. b''4 |
      g''2 d''8 cis''8 b'4 |
      cis''4 e'4 b'4 d'4 |
      b'1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2 fis''4 b'4 |
      g''2 d''4 a''4 |
      d''2 g''4 d''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''2 fis'4 d''4~ |
      d''2 b''2 |
      e''2 b''2~ |
      b''4 g''4 b'4 fis''4 |
      b'2. fis''4~ |
      fis''2 b'4 d''4 |
      fis'2 b'2 |
      fis''2. d'''4 |
      d''2. fis'4 |
      d''2 b''2 |
      d''2. g'4~ |
      g'2 g''2~ |
      g''4 b'2 e'4 |
      e''1 |
      e'2. cis''4~ |
      cis''1~ |
      cis''1~ |
      cis''1~ |
      cis''1 |
      fis''1~ |
      fis''1~ |
      fis''1~ |
      fis''2. b''4 |
      d''2. b''4 |
      d''2. b''4 |
      d'''2 g''4 d'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''2^\markup { \tiny \italic "Real answer" } cis'''4 d'''4 |
      b''2 a''4 cis'''4 |
      a''2 fis''2 |
      g''2^\markup { \tiny \italic "Countersubject" } a''4 b''8 a''8 |
      g''2 fis''8 g''8 a''8 g''8 |
      fis''2 g''2 |
      fis''2 e''4 d''4 |
      fis'2. gis'4 |
      a'2 d''2 |
      g'2 fis'4 e'8 fis'8 |
      g'8 a'8 b'4 d''4. e''8 |
      fis''4 b'4 d''2 |
      d''4 g'8 fis'8 e'2 |
      cis'2 d'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''2 cis''4 a'4 |
      b'2 fis''4 cis''8 d''8 |
      e''2 d''2 |
      g''2 d''4 g'8 a'8 |
      b'4. cis''8 d''4. cis''8 |
      b'8 cis''8 d''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''2 a'4 d''4 |
      g''8 fis''8 e''4 fis''2~ |
      fis''8 e''8 d''2. |
      d''2 a'2 |
      d''4 fis'4 cis''2~ |
      cis''4 a'2. |
      d'4 g'4 d'4 b'4~ |
      b'2 fis''2~ |
      fis''2 b'2 |
      r1 |
      r1 |
      a'2 cis'4 a'4 |
      fis''2 a'4 e''4 |
      a''2 d''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'2 fis''2 |
      b'2. g''4~ |
      g''2 b'2 |
      d'2 b'2 |
      fis''2. d''4~ |
      d''2 b''2 |
      fis''2 b'2~ |
      b'4 fis''2. |
      fis''2 b''2 |
      d''2. b''4~ |
      b''2 d''2 |
      g'2 d''4 b''4~ |
      b''4 e''2. |
      g'2 e''2~ |
      e''2 g'2~ |
      g'4 e''2. |
      cis'''2 cis''2 |
      cis'2. cis''4~ |
      cis''1~ |
      cis''1 |
      fis''1~ |
      fis''1~ |
      fis''2 fis'2~ |
      fis'2 d''2~ |
      d''2 g'2~ |
      g'4 d''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''2^\markup { \tiny \italic "Real answer" } cis'''4 d'''4 |
      b''2 a''4 cis'''4 |
      a''2 fis''2 |
      d''2~ d''8 cis''8 b'4 |
      g'2^\markup { \tiny \italic "Countersubject" } a'4 b'8 a'8 |
      g'2 fis'8 g'8 a'8 g'8 |
      fis'2 g'2 |
      a'4. b'8 cis''4 fis''4~ |
      fis''2. e''4 |
      a'1 |
      b'2 a'4 d''4 |
      e''2 fis''8 e''8 d''4~ |
      d''2 g'4. a'8 |
      b'2. e''8 d''8 |
      cis''4 fis'8 e'8 d'8 cis'8 b4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''4. e''8 fis''4 b''4 |
      e''2 fis''4 cis''4 |
      b'2 d''4 g''4 |
      d''2 cis''4 a'4 |
      b'4 fis'8 gis'8 a'4 gis'4 |
      cis''2 fis''4 d''4 |
      fis''2 b''4 fis''4 |
      b'2 fis'4 b'4 |
      e'4 b'8 cis''8 d''4 a'4 |
      b'2 d'4 g'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c''2 b'4 g''4 |
      c''2 g'4 d'4 |
      g'4 b'4 a'4 e''4 |
      g'4 d''4 fis'4 d''4 |
      g'4 b'4 fis'2 |
      d''2 g''4 e''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''2 b'2 |
      d''2. b'4~ |
      b'2 g''2 |
      b'2. fis'4 |
      b'2 fis''2 |
      b'2 fis'4 b'4~ |
      b'2 fis''4 b'4~ |
      b'2 fis'4 d'4 |
      d''2. fis''4 |
      b'2. d'4 |
      b'2 g''4 d''4~ |
      d''2 g''2 |
      b'2. e''4 |
      b'2 g'2 |
      e''1 |
      g'2. e''4~ |
      e''2. cis'''4~ |
      cis'''2 cis''2~ |
      cis''1~ |
      cis''1~ |
      cis''1 |
      fis'1 |
      fis''2. b'4~ |
      b'2 d'2 |
      b'2. d''4 |
      g'2 d''4 b'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2^\markup { \tiny \italic "Real answer" } cis''4 d''4 |
      b'2 a'4 cis''4 |
      a'2 fis'2 |
      g'2^\markup { \tiny \italic "Countersubject" } a'4 b'8 a'8 |
      g'2 fis'8 g'8 a'8 g'8 |
      fis'2 g'2 |
      a'2. d''4~ |
      d''4 fis'2 gis'4 |
      a'2.~ a'8 b'8 |
      cis''2 d''4 fis'4 |
      d''2. g'4 |
      e''4 g'4 d'4. cis'8~ |
      cis'8 b2. cis'8 |
      d'4 e'8 d'8 cis'4 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'8 a'8 g'4 fis'4 b'4 |
      e''4 b'2 fis'4 |
      b'8 cis''8 d''2 b'4 |
      fis'4 d'4 cis'4 fis'4 |
      gis'4 b'4 fis'4 gis'4~ |
      gis'8 fis'2~ fis'8 d''4 |
      g'4 d'2 g'4 |
      b'4 e''4 a'2 |
      d'4 fis'4 b'4 d''4 |
      r1 |
      r1 |
      fis'2^\markup { \tiny \italic "Related-key subject" } cis''4 d''4 |
      b'2 a'4 cis''4 |
      a'2 fis'2 |
      a'2 b'2 |
      gis'2 fis'2 |
      g'2 fis'4 g'4 |
      a'2 b'4 fis'4 |
      g'2 a'4 c''4 |
      b'2^\markup { \tiny \italic "Related-key subject" } fis''4 g''4 |
      e''2 d''4 fis''4 |
      d''2 b'2 |
      b'2 fis'4 b'4 |
      e''4 b'2 fis''4 |
      fis'2 b'4 d''4~ |
      d''4 b'2 e'4 |
      b'2. d''4~ |
      d''4 fis'2 b4 |
      r1 |
      fis'1 |
      d''1 |
      b'2 e'4 g'4~ |
      g'2 fis'4 d''4 |
      fis'1~ |
      fis'1 |
      d'2. fis'4~ |
      fis'1 |
      fis'4 d''4 fis''2 |
      d''1 |
      g'4 d'2. |
      b4 d'4 b'4 g'4 |
      b'1~ |
      b'4 g'2 e'4 |
      cis'2 cis''2~ |
      cis''1 |
      ais'2 cis'4 e'4~ |
      e'2. cis'4~ |
      cis'4 fis'2 cis'4~ |
      cis'4 cis''4 fis''4 ais'4~ |
      ais'4 fis'4 fis''2 |
      ais''4 cis''4 ais'2 |
      b'1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      fis''2 d''4 fis'4 |
      d''2 b'4 d'4~ |
      d'2 b2 |
      b4 d'4 a'4 d'4 |
      b'4 e'4 a'2 |
      d'4 fis'4 b'4 e''4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2^\markup { \tiny \italic "Real answer" } cis''4 d''4 |
      b'2 a'4 cis''4 |
      a'2 fis'2 |
      g'2^\markup { \tiny \italic "Countersubject" } a'4 b'8 a'8 |
      g'2 fis'8 g'8 a'8 g'8 |
      fis'2 g'2 |
      fis'2 a'2 |
      gis'4 fis'4 cis'2~ |
      cis'2 fis'4 d'4 |
      d'2. b4~ |
      b2 fis2~ |
      fis4 d'2 b4 |
      b4 g'8 a'8 b'2 |
      ais'4 fis'2. |
      fis'4 d'4 cis'4 fis'4~ |
      fis'2 a'4 e'4~ |
      e'2 b4 d'4 |
      r1 |
      r1 |
      c''4 g'4 b4 e'4~ |
      e'2 g'4 fis'4 |
      d'2 c'4 e'4 |
      b'4 d'4 a'4 d'4 |
      b'4 g'4 d''4 fis'4~ |
      fis'2 b4 e'4 |
      b'4 g'4 d'4 g'4~ |
      g'2 d''4 fis'4~ |
      fis'2. d'4 |
      fis'4 b'2 g'4~ |
      g'4 d'2 fis'4 |
      b'4 fis'2 d''4 |
      r1 |
      fis'4 b'2 fis'4~ |
      fis'4 b'2 g'4~ |
      g'2 e'4 b4 |
      d'4 g'4 d''4 b'4~ |
      b'4 fis'4 d'4 fis'4~ |
      fis'4 b'2 fis'4~ |
      fis'2 d'4 b4 |
      d'4 fis'2 b'4 |
      fis'2 b4 d'4~ |
      d'4 fis'2 b'4~ |
      b'2 d''4 b'4~ |
      b'2 d''4 g'4~ |
      g'4 b'2 g'4~ |
      g'4 e'4 b4 g4~ |
      g4 e'2 g'4~ |
      g'2 e''2~ |
      e''4 e'2. |
      cis''2. cis'4~ |
      cis'2. fis'4~ |
      fis'1~ |
      fis'1~ |
      fis'1~ |
      fis'2. d'4 |
      fis'2. b'4~ |
      b'4 d'2 g'4~ |
      g'4 b'2 g'4 |
      g'4 b4 a4 d'4 |
      g'4 b'4 fis'2~ |
      fis'4 a'4 e'4 g'4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "treble" \key b \minor \time 4/4
      b'2^\markup { \tiny \italic "Subject" } fis''4 g''4 |
      e''2 d''4 fis''4 |
      d''2 b'2 |
      d'2^\markup { \tiny \italic "Countersubject" } e'4 fis'8 e'8 |
      d'2 cis'8 d'8 e'8 d'8 |
      cis'2 d'2 |
      e'8 fis'8 g'4 fis'4 e'4~ |
      e'2 fis'2~ |
      fis'8 e'8 d'4 e'2 |
      fis'2 e'4 d'8 e'8 |
      fis'4. gis'8 a'4 gis'4~ |
      gis'8 fis'2.~ fis'8 |
      b'2 a'4 e'4~ |
      e'8 d'8 cis'4 a2 |
      b8 cis'8 d'2. |
      d'4 e'4 fis'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g'8 a'8 b'4 a'4 g'8 a'8 |
      b'8 a'8 g'4 a'4 fis'8 g'8 |
      a'8 g'8 fis'4 e'8 fis'8 g'4 |
      a'2~ a'8 gis'8 fis'4 |
      b8 cis'8 d'4 a'4 gis'4 |
      cis''8 b'8 a'2 fis'8 e'8 |
      d'4 g'4 d'4 e'8 d'8~ |
      d'8 cis'8 e'4 fis'4. g'8 |
      a'4 b'4. a'8 g'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'8 e'8 fis'4 d'4 fis'4 |
      g'4 d'8 e'8 fis'4 d'4 |
      g'8 a'8 b'2 cis''4 |
      b'4 a'4 g'8 fis'8 e'4 |
      d'8 e'8 fis'4 gis'4 fis'4 |
      b8 cis'8 d'4 fis'4 gis'4 |
      a'8 b'8 cis''4 a'8 gis'8 fis'4 |
      b'8 a'8 g'4 fis'4 d'4 |
      g8 a8 b2 d'4 |
      fis'8 e'8 d'2 b4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'8 a'8 g'4 fis'4 d'4 |
      e'4 b8 cis'8 d'4 cis'4 |
      fis'8 e'8 d'2 b4 |
      fis'8 gis'8 a'2 fis'4 |
      b8 cis'8 d'4 fis'4 e'4 |
      a'8 gis'8 fis'2 a'4 |
      a'8 g'8 fis'4 d'8 e'8 fis'4 |
      g'4 d'2 g'4~ |
      g'8 a'8 b'2 a'4 |
      d'8 e'8 fis'4 b'8 a'8 g'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'8 e'8 d'2 b4 |
      gis'4 cis'2 fis'4 |
      r1 |
      r1 |
      r1 |
      g'4 d'4 a4 d'4 |
      b2 fis'2 |
      a'4 fis'4 b'4 g'4 |
      fis'4 d'4 fis'4 d'4 |
      e'4 g'4 b'4 fis'4~ |
      fis'4 d'2 fis'4 |
      d'4 g'2 e'4 |
      g'4 fis'2 b'4 |
      fis'2. b'4 |
      r1 |
      fis'4 d'2 fis'4~ |
      fis'4 d'2 g'4 |
      b'4 g'2 e'4 |
      b2. d'4~ |
      d'4 fis'2 b'4 |
      fis'4 d'2 fis'4 |
      b'4 fis'2 d'4 |
      b2. d'4 |
      b'4 fis'2 d'4 |
      b4 d'4 fis'4 d'4~ |
      d'4 g'2 b'4 |
      g'4 d'2 g'4~ |
      g'4 e'2 b4 |
      g4 b2 e'4~ |
      e'4 g'2 e'4 |
      cis'4 e'4 g'4 e'4~ |
      e'2. cis'4~ |
      cis'2 e'4 cis''4~ |
      cis''2. fis'4~ |
      fis'1~ |
      fis'1~ |
      fis'1~ |
      fis'4 b'2 fis'4 |
      b4 d'4 fis'4 d'4~ |
      d'4 g'2 d'4~ |
      d'4 g'2 b'4 |
      g'4 b'4 fis'4 d'4 |
      b4 g'4 a'4 fis'4 |
      a'2 g'4 e'4 |
      e'2 cis''4 fis'4 |
      d'4 fis'2 b'4 |
      d''4 b'2 fis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b2^\markup { \tiny \italic "Subject" } fis'4 g'4 |
      e'2 d'4 fis'4 |
      d'2 b2 |
      d'2^\markup { \tiny \italic "Countersubject" } e'4 fis'8 e'8 |
      d'2 cis'8 d'8 e'8 d'8 |
      cis'2 d'2 |
      e'8 fis'8 g'4 fis'4 e'4~ |
      e'2 fis'2~ |
      fis'8 e'8 d'4 e'2 |
      fis'4. gis'8 a'2 |
      d'2 fis'4 e'4~ |
      e'4 fis'2. |
      b'4. cis''8 d''4 b'4 |
      cis''4 b'2 d'4~ |
      d'1 |
      d'8 cis'8 b2.~ |
      b8 ais4. b2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'8 e'8 d'4 fis'2 |
      d'8 cis'8 b4 cis'4 d'4 |
      e'4 b8 cis'8 d'4 cis'4 |
      d'8 e'8 fis'4 e'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'8 cis'8 b4 cis'4 d'8 cis'8 |
      b4 e'4 b4 cis'4 |
      d'8 e'8 fis'4 b'2 |
      fis'4. gis'8 a'2 |
      d'4 b4 cis'2~ |
      cis'4 fis'8 gis'8 a'2 |
      fis'4 cis'4 fis'4. e'8 |
      d'8 cis'8 b4 a4 d'4 |
      g'8 fis'8 e'4 fis'4 d'4~ |
      d'8 cis'8 b4 d'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b8 cis'8 d'4 fis'4 d'8 cis'8 |
      b4. cis'8 d'4 cis'4 |
      d'8 e'8 fis'4 b'2~ |
      b'8 a'8 fis'4 e'4 d'4~ |
      d'4 b4 cis'2 |
      fis'4 a'2. |
      b'2 a'4 g'4~ |
      g'4 e'4 fis'4 cis'4 |
      fis'4 d'4 g'2 |
      r1 |
      r1 |
      d'4 fis'4 gis'4 a'4 |
      d'4 b4 cis'2 |
      e'4 cis'4 fis'2 |
      d'8 e'8 fis'2. |
      cis'2~ cis'8 b8 a4 |
      e'4 g'4 b'4 g'4 |
      e'2 b2 |
      d'4 b4 e'2 |
      b4 d'4 fis'4 b'4 |
      e'4 b4 a4 cis'4 |
      d'4 fis'4 e'2 |
      fis'4 g'4 a'4 b'4 |
      g'4 e'4 fis'4 fis'4 |
      fis'4 b4 d'2 |
      b4 g4 b2 |
      d'4 b4 d'2 |
      fis'4 d'4 cis'4 b4 |
      r1 |
      b4 d'4 fis'2 |
      d'4 b4 d'2 |
      g'4 e'4 g'2 |
      d'4 b4 d'2 |
      fis'4 d'4 fis'2 |
      d'4 b4 d'2 |
      fis'4 d'4 fis'2 |
      d'4 b4 d'2 |
      fis'4 d'4 b2 |
      d'4 b4 d'4 b4~ |
      b4 d'4 g'2 |
      d'2 b2~ |
      b4 e'4 g'2 |
      e'4 b4 e'2 |
      g'4 e'4 g'2 |
      e'4 cis'4 e'4 cis'4~ |
      cis'2 e'2~ |
      e'4 cis'2.~ |
      cis'1~ |
      cis'1~ |
      cis'2 fis'2~ |
      fis'1~ |
      fis'4 d'4 fis'2 |
      d'4 b4 d'4 b4~ |
      b4 d'4 g'2 |
      d'4 b4 d'2 |
      d'4 b4 cis'4 d'4 |
      e'4 b4 a4 cis'4 |
      fis'4 d'4 g'2 |
      g'4 e'4 cis'2 |
      b4 d'4 b4 d'4 |
      fis'4 d'4 fis'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "treble" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b2^\markup { \tiny \italic "Subject" } fis'4 g'4 |
      e'2 d'4 fis'4 |
      d'2 b2 |
      d'2^\markup { \tiny \italic "Countersubject" } e'4 fis'8 e'8 |
      d'2 cis'8 d'8 e'8 d'8 |
      cis'2 d'2 |
      d'2.~ d'8 cis'8 |
      b2 a4 g4~ |
      g2 b4 a4 |
      b8 cis'8 d'4 e'2 |
      fis'2 e'4 d'4~ |
      d'8 e'8 fis'4 cis'2~ |
      cis'8 b8 a2. |
      d'4 b'4 fis'4 b4~ |
      b2. a4 |
      b1 |
      b8 cis'8 d'4 e'4 b4 |
      fis'2 b'8 cis''8 d''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b2 cis'4 d'4 |
      e'2 b4 cis'4~ |
      cis'8 b4 cis'8 d'2 |
      a2 cis'4 a4 |
      b4 d'4 a4 gis4 |
      a2 d'2 |
      d'2 fis'4 d'4 |
      g'2 d'4 cis'4 |
      d'4 a4 b2 |
      r1 |
      r1 |
      a2 cis'4 a4 |
      b4 d'4 a4 gis4 |
      a2 d'2 |
      a4. gis8 fis2 |
      gis2 cis'2 |
      c'4 e'4 fis'4 e'4~ |
      e'2 d'2 |
      g2 c'2 |
      e'4 b4 cis'4 b4 |
      e'4 g'4 d'4 cis'4 |
      a2 e'4 g'4 |
      d''4 g'4 fis'4 b4~ |
      b2. cis'4 |
      fis'2 d'2 |
      b'2 g'4 b4~ |
      b4 d'4 b4 fis4 |
      d4 fis4 a4 b4 |
      r1 |
      b2 d'2 |
      fis'2 b2 |
      g4 b4 e'2 |
      g'2 d'2 |
      b2 d'2 |
      fis'2 d'2 |
      b2 d'2 |
      fis'2 d'2 |
      d'4 b4 d'2 |
      fis'4 d'4 b2 |
      d'2 b4 d'4 |
      g'2 d'4 b4~ |
      b2 e'2 |
      g'2 e'4 g'4 |
      e'4 cis'4 e'4 cis'4 |
      e'2 cis'2 |
      e'2 cis'2 |
      e'2 cis'2~ |
      cis'1~ |
      cis'1~ |
      cis'1 |
      fis'1 |
      fis2 b2 |
      d'2 b2 |
      d'4 b4 d'2 |
      g'2 d'2 |
      b2^\markup { \tiny \italic "Subject" } fis'4 g'4 |
      e'2 d'4 fis'4 |
      d'2 b2 |
      g2 fis2 |
      b1 |
      b1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b2^\markup { \tiny \italic "Subject" } fis'4 g'4 |
      e'2 d'4 fis'4 |
      d'2 b2 |
      d'2^\markup { \tiny \italic "Countersubject" } e'4 fis'8 e'8 |
      d'2 cis'8 d'8 e'8 d'8 |
      cis'2 d'2 |
      b2 a4 g4~ |
      g2 b4 a4 |
      b1 |
      a4 d'4 a'2 |
      gis'4 fis'4 cis'4. d'8 |
      e'4 fis'8 e'8 d'2 |
      fis2. b,4~ |
      b,4 d4 d'2~ |
      d'8 cis'8 b2 fis4~ |
      fis4. e8 d2 |
      g8 a8 b4 ais4 b4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a8 gis8 fis4 d8 e8 fis4 |
      cis'2 fis'2 |
      r1 |
      r1 |
      r1 |
      g4 b4 a4 g4 |
      b2 d'4 a4 |
      d'4 a4 b2 |
      d'4 b4 a4 g4 |
      b4 g4 fis2 |
      a4 b4 fis2 |
      b2 e'2 |
      b4 fis4 b2 |
      d'4 b4 fis'4 d'4 |
      r1 |
      d'4 b4 fis2 |
      b4 d'2. |
      e'4 b4 g4 b4~ |
      b4 d'4 b2 |
      d'4 b4 fis2 |
      b4 d'4 b2 |
      d'4 b4 fis2 |
      b4 d'4 fis'2 |
      fis'4 b4 fis2 |
      b4 fis4 b2~ |
      b4 g2. |
      b4 g4 b2~ |
      b4 g4 e4 g4 |
      b4 e'2. |
      g2 e2 |
      g4 e4 cis'2~ |
      cis'4 e'2. |
      cis'4 e'4 cis''2 |
      cis'1~ |
      cis'1~ |
      cis'1~ |
      cis'2 fis'2~ |
      fis'4 b4 fis2 |
      b4 fis4 b2~ |
      b4 g2. |
      b4 d'4 g'2 |
      g'4 d'4 a4 g4 |
      b4 e'4 fis'4 cis'4 |
      a4 fis4 e2 |
      g4 b4 fis2 |
      d'4 b4 d'2 |
      b4 d'4 b2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b2^\markup { \tiny \italic "Subject" } fis'4 g'4 |
      e'2 d'4 fis'4 |
      d'2 b2 |
      d'2^\markup { \tiny \italic "Countersubject" } e'4 fis'8 e'8 |
      d'2 cis'8 d'8 e'8 d'8 |
      cis'2 d'2 |
      b2 a4 g4~ |
      g2 b4 a4 |
      b4. a8 g2 |
      a1 |
      d4 fis2 e4 |
      fis2 a2~ |
      a8 g8 b4 d2 |
      b2 d4 a,4 |
      d1 |
      d4 b8 a8 g2 |
      fis1 |
      fis4 a4 e4 a4 |
      fis4 b4 e'4 cis'4~ |
      cis'4 e'4 d'4 b4 |
      r1 |
      r1 |
      g'4 e'4 b4 e4~ |
      e4 a4 d'4 b4~ |
      b4 d'4 a4 g4 |
      b2 fis4 b,4~ |
      b,4 e4 a2~ |
      a4 d'4 g4 b4 |
      b4 d'2 g4~ |
      g4 b4 d'4 cis'4 |
      fis4 b2 fis4~ |
      fis4 e4 g4 b4~ |
      b2 fis4 d4~ |
      d2 a4 d'4 |
      r1 |
      d'4 fis'4 d'4 b4~ |
      b4 fis4 b2~ |
      b4 e'4 b4 g4~ |
      g4 b4 fis4 b4~ |
      b4 d'4 b4 fis4~ |
      fis2 b2~ |
      b4 d'4 b4 fis4~ |
      fis2 b4 fis4 |
      fis4 b2 fis4~ |
      fis4 b2 d'4~ |
      d'4 g4 d4 g4~ |
      g4 b4 g4 b4~ |
      b2 g4 e4~ |
      e4 g4 b4 e4~ |
      e2 cis4 e4~ |
      e4 g4 e4 cis'4~ |
      cis'2 e2~ |
      e4 cis'2.~ |
      cis'2 fis2~ |
      fis1~ |
      fis1~ |
      fis1~ |
      fis4 d'4 b2 |
      fis4 b2 d'4~ |
      d'4 g4 b4 g4~ |
      g2 b4 d'4 |
      d'2 fis4 b4~ |
      b4 g4 d'4 a4~ |
      a2 b4 g4 |
      b2 fis'2~ |
      fis'4 d'4 fis'4 d'4~ |
      d'4 fis'4 d'4 b4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 16" shortInstrumentName = "V16" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2^\markup { \tiny \italic "Real answer" } cis'4 d'4 |
      b2 a4 cis'4 |
      a2 fis2 |
      g2^\markup { \tiny \italic "Countersubject" } a4 b8 a8 |
      g2 fis8 g8 a8 g8 |
      fis2 g2 |
      b2 fis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis8 gis8 a4 cis'4 fis'4~ |
      fis'8 e'8 d'4 a4 e'4~ |
      e'8 d'8 cis'4 fis'8 e'8 d'4 |
      d'8 cis'8 b4 a4 g4~ |
      g2 b4 a4~ |
      a8 g8 fis4 b8 cis'8 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis8 gis8 a4 e'4 a'4 |
      d'8 cis'8 b4 cis'2~ |
      cis'8 d'8 e'4 fis'8 e'8 d'4 |
      g4 d8 e8 fis4 b4~ |
      b4 g4 b4 fis4~ |
      fis4 b4. cis'8 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g'4 d'4 cis'4 b4~ |
      b8 a8 g4 d'4 a4 |
      d'4 b2 d'4 |
      d'4 a2 fis4 |
      b4 fis2 cis4~ |
      cis4 fis2 a4 |
      d'4 b4 fis4 b4~ |
      b4 e4 a4 fis4~ |
      fis4 a4 g4 b4 |
      r1 |
      r1 |
      a'4 fis'4 cis'4 fis4~ |
      fis2 cis2 |
      a4 cis'4 b4 fis4 |
      r1 |
      r1 |
      g2 d4 g4 |
      c'4 a4 d4 fis4 |
      b4 g4 e'4 c'4 |
      r1 |
      r1 |
      r1 |
      fis4 b4 d'4 b4~ |
      b2 fis2~ |
      fis4 d'2 b4~ |
      b4 e2 g4~ |
      g4 d'2 b4~ |
      b4 d'4 a4 d4 |
      r1 |
      b4 fis2 d4~ |
      d2 g4 b4~ |
      b4 e2 b4 |
      g4 d2 fis4~ |
      fis4 b2 d'4~ |
      d'4 fis2 d4~ |
      d4 b2. |
      fis4 d2 fis4 |
      b4 d'2 b4 |
      fis2. b,4~ |
      b,4 b2 g4~ |
      g4 b,2 g4~ |
      g2 b2~ |
      b4 e2.~ |
      e4 cis'2. |
      cis2. e4~ |
      e2 cis'2~ |
      cis'4 cis2. |
      cis'1~ |
      cis'4 fis2.~ |
      fis1~ |
      fis1~ |
      fis2 d'4 b4~ |
      b2 fis4 b,4~ |
      b,4 g4 d'4 b4~ |
      b4 g2 d4 |
      d2 fis4 b,4 |
      e4 g4 d4 a4~ |
      a2 e'4 b4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 17" shortInstrumentName = "V17" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2^\markup { \tiny \italic "Real answer" } cis'4 d'4 |
      b2 a4 cis'4 |
      a2 fis2 |
      g2^\markup { \tiny \italic "Countersubject" } a4 b8 a8 |
      g2 fis8 g8 a8 g8 |
      fis2 g2 |
      d2 e4 b,4 |
      cis2 b,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2~ fis'8 e'8 d'4~ |
      d'2 cis'4 b4~ |
      b8 a8 g4 d'4 a4 |
      d'2 r2 |
      r1 |
      r1 |
      r1 |
      b,8 cis8 d4 a4 g4~ |
      g2 d2~ |
      d8 e8 fis4 b4 g4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b8 cis'8 d'4 cis'4 b4~ |
      b4 g4 d'4 a4 |
      d'8 cis'8 b2 d'4 |
      d'8 e'8 fis'4 e'4 d'4~ |
      d'8 e'8 fis'2 cis'4~ |
      cis'8 b8 a4. gis8 fis4 |
      cis4 fis4. e8 d4~ |
      d4 g4 fis8 e8 d4 |
      g,2 b,8 cis8 d4 |
      fis4 b8 a8 g4 d4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a2 gis4 fis4~ |
      fis2 e2~ |
      e2 fis2 |
      fis2 b2 |
      cis'4 gis4 a4 cis8 d8 |
      e2 d4 c4~ |
      c2 d2~ |
      d2 e2 |
      e4 d4 cis4 d4 |
      g2 a4 fis4~ |
      fis4 a4 g2 |
      d2 a4 d'4 |
      g4 b,4 fis2 |
      a,4 d4 fis4 b4~ |
      b2 e4 b,4~ |
      b,2 fis2~ |
      fis4 b4 r2 |
      r1 |
      d1~ |
      d2 b,2 |
      e4 g4 b2~ |
      b2 d2~ |
      d1~ |
      d1~ |
      d4 fis2. |
      b,2 fis2 |
      d4 fis4 d2~ |
      d2 fis,2 |
      d4 b,4 g,4 d4 |
      b1 |
      g1~ |
      g4 b,2. |
      g,1~ |
      g,2 g2 |
      e4 cis4 ais,2~ |
      ais,2. ais4~ |
      ais2. fis4 |
      ais,2. fis,4~ |
      fis,4 ais,2. |
      fis1~ |
      fis2 d4 fis,4 |
      d4 fis2. |
      g2 d2 |
      b,2 g,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 18" shortInstrumentName = "V18" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2^\markup { \tiny \italic "Real answer" } cis'4 d'4 |
      b2 a4 cis'4 |
      a2 fis2 |
      g2^\markup { \tiny \italic "Countersubject" } a4 b8 a8 |
      g2 fis8 g8 a8 g8 |
      fis2 g2 |
      d4. cis8 b,2 |
      ais,2 b,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2 d'8 cis'8 b4 |
      d'2 a4 g4~ |
      g2 b,4 fis4~ |
      fis4 d4 g8 a8 b4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d2 a4 d4~ |
      d2 a4 e4 |
      a,4 cis4 a,4 fis,4 |
      b,4 d4 a,4 d4 |
      g,4 b,4 d4 fis,4 |
      a,2 d4 g4 |
      r1 |
      r1 |
      a,2 e4 a,4 |
      d4 fis4 cis'4 gis4 |
      cis2 fis,4 b,4 |
      r1 |
      r1 |
      g,2 d4 g,4 |
      e4 c4 g4 b,4~ |
      b,2 e,4 g,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,2 b,4 d4 |
      b,2 g2 |
      b,2. e,4 |
      b,2 fis4 d4~ |
      d2. b,4 |
      d2 fis2 |
      b,2. fis4~ |
      fis2 d'4 b4 |
      d2 fis,4 b,4~ |
      b,2 fis,4 d4~ |
      d2 g,2 |
      d4 g2 b,4~ |
      b,2 e,4 b,4 |
      e2 g2 |
      g,2. e4~ |
      e4 cis'2. |
      cis2. cis,4~ |
      cis,2 cis2~ |
      cis1~ |
      cis1~ |
      cis1~ |
      cis2. fis4~ |
      fis2 b,4 d4~ |
      d2 b2 |
      b,2 g,2 |
      d2. g4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 19" shortInstrumentName = "V19" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2^\markup { \tiny \italic "Real answer" } cis'4 d'4 |
      b2 a4 cis'4 |
      a2 fis2 |
      fis2 b,4 d4 |
      g,2^\markup { \tiny \italic "Countersubject" } a,4 b,8 a,8 |
      g,2 fis,8 g,8 a,8 g,8 |
      fis,2 g,2 |
      b,2 fis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis4 a2 d'4 |
      d2 fis4 cis'4 |
      fis2 d2 |
      d2. g,4~ |
      g,2 d4 a4~ |
      a2 d2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2 b,2 |
      fis,2 d2 |
      g,1 |
      d2. b4 |
      fis2 b,2~ |
      b,4 fis,2. |
      d2 fis,2~ |
      fis,4 b,2. |
      d1 |
      fis,2 d2~ |
      d2 b2 |
      d2 g,2~ |
      g,4 e4 b,2 |
      e,2 e2~ |
      e2 e,2 |
      cis1 |
      e,4 cis2.~ |
      cis1~ |
      cis1~ |
      cis1~ |
      cis2 fis,2~ |
      fis,1~ |
      fis,4 fis2. |
      fis,2. d4~ |
      d2 b2 |
      g4 d2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 20" shortInstrumentName = "V20" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,2^\markup { \tiny \italic "Real answer" } cis4 d4 |
      b,2 a,4 cis4 |
      a,2 fis,2 |
      g,2^\markup { \tiny \italic "Countersubject" } a,4 b,8 a,8 |
      g,2 fis,8 g,8 a,8 g,8 |
      fis,2 g,2 |
      g,8 a,8 b,2. |
      fis,4. e,8 d,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,2 d2~ |
      d2 g,2 |
      e2. g,4~ |
      g,4 d2 fis,4~ |
      fis,2 d2 |
      fis,2 d4 b,4~ |
      b,4 fis2 b4 |
      d2 b,2 |
      b,2 fis4 b,4~ |
      b,2 d,2~ |
      d,4 b,2 g4 |
      g,2 b,,2 |
      g,2. e4~ |
      e2 e,2~ |
      e,2 cis2~ |
      cis2. cis,4~ |
      cis,2 cis2~ |
      cis1~ |
      cis1 |
      fis,1~ |
      fis,1~ |
      fis,1~ |
      fis,2 fis2~ |
      fis4 b,2 d,4 |
      d2. g,4~ |
      g,2 b,,4 g,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 21" shortInstrumentName = "V21" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,2^\markup { \tiny \italic "Subject" } fis4 g4 |
      e2 d4 fis4 |
      d2 b,2 |
      g,2 fis,8 e,8 d,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d,4 b,2 fis4~ |
      fis4 b,2. |
      g2. b,4~ |
      b,2. d,4~ |
      d,4 b,2. |
      fis4 b,2. |
      d,2. b,4~ |
      b,2. fis4 |
      fis4 fis,2 d4~ |
      d4 fis,2. |
      b,2. d,4~ |
      d,4 b,2. |
      e,4 b,,2. |
      g,2. b,4 |
      e4 g,2. |
      e2. e,4~ |
      e,2. e4~ |
      e2 e,2 |
      cis4 fis,2. |
      cis,4 fis,2. |
      cis,2. fis,4 |
      cis4 fis,2 cis,4 |
      b,,4 d,2. |
      b,2. fis,4 |
      b,2. g4~ |
      g4 b,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 22" shortInstrumentName = "V22" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,2^\markup { \tiny \italic "Subject" } fis4 g4 |
      e2 d4 fis4 |
      d2 b,2 |
      g,1 |
      fis,2 b,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g,4 d2. |
      g4 b,2 fis4 |
      b,4 fis,8 e,8 d,4 g,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d4 fis,2 b,,4~ |
      b,,2. d,4 |
      b,2. b,,4~ |
      b,,4 b,2. |
      d,2. b,4~ |
      b,4 d,2 b,4~ |
      b,4 d,2.~ |
      d,4 b,2. |
      b,4 d,2 b,4~ |
      b,4 d,2. |
      g,2. b,,4~ |
      b,,4 g,2 d4 |
      g,2. g,,4~ |
      g,,4 e,2. |
      cis2. cis,4~ |
      cis,2 cis2~ |
      cis4 cis,2.~ |
      cis,4 cis2. |
      fis,1~ |
      fis,4 cis,2 fis,4~ |
      fis,4 cis,2 fis,,4~ |
      fis,,4 fis,2. |
      b,,2. fis,4~ |
      fis,4 d2. |
      g,4 d,2.~ |
      d,4 b,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 23" shortInstrumentName = "V23" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,,2^\markup { \tiny \italic "Subject" } fis,4 g,4 |
      e,2 d,4 fis,4 |
      d,2 b,,2 |
      g,8 a,8 b,4 e,2 |
      fis,2 b,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,4 b,,2.~ |
      b,,4 b,2 b,,4~ |
      b,,4 b,2. |
      b,,1 |
      b,2. b,,4~ |
      b,,2 fis,4 d4~ |
      d4 fis,2. |
      d4 fis,2. |
      fis,2 d4 d,4~ |
      d,4 b,2.~ |
      b,4 b,,2. |
      g,2. g,,4~ |
      g,,4 g,2. |
      g,,2. e,4~ |
      e,2. e,,4~ |
      e,,2 e,2~ |
      e,2 e,,2~ |
      e,,4 e,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      d,4 b,2 d,4~ |
      d,1~ |
      d,4 b,2. |
      d,2. g,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 24" shortInstrumentName = "V24" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,4 ais,4 b,2 |
      b,,2^\markup { \tiny \italic "Subject" } fis,4 g,4 |
      e,2 d,4 fis,4 |
      d,2 b,,2 |
      b,,4 e,4 fis,8 e,8 d,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d,2 b,2 |
      b,,2. b,4 |
      b,,2. b,4~ |
      b,2 b,,2~ |
      b,,4 b,2. |
      b,,2. fis,4~ |
      fis,4 b,,2. |
      b,4 b,,2. |
      b,,2 b,2 |
      b,,1 |
      b,1 |
      b,,2. d,4 |
      b,4 b,,4 g,2~ |
      g,2 b,,2 |
      e,,4 e,2. |
      e,,4 e,2.~ |
      e,1~ |
      e,1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d,2 b,2~ |
      b,4 b,,2.~ |
      b,,2 b,2~ |
      b,4 b,,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 25" shortInstrumentName = "V25" } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,,2^\markup { \tiny \italic "Subject" } fis,4 g,4 |
      e,2 d,4 fis,4 |
      d,2 b,,2 |
      g,,4. fis,,8 e,,2 |
      fis,,4 ais,,4 b,,4. cis,8 |
      d,2^\markup { \tiny \italic "Countersubject" } e,4 fis,8 e,8 |
      d,2 cis,8 d,8 e,8 d,8 |
      cis,2 d,2 |
      d,1 |
      cis,4. b,,8 a,,2 |
      c,2^\markup { \tiny \italic "Countersubject" } d,4 e,8 d,8 |
      c,2 b,,8 c,8 d,8 c,8 |
      b,,2 c,2 |
      g,,2^\markup { \tiny \italic "Countersubject" } a,,4 b,,8 a,,8 |
      g,,2 fis,,8 g,,8 a,,8 g,,8 |
      fis,,2 g,,2 |
      b,,2^\markup { \tiny \italic "Stretto subject" } fis,4 g,4 |
      e,2 d,4 fis,4 |
      d,2 b,,2 |
      d,4 e,2 g,,4 |
      g,4 b,,2. |
      d,,2 fis,,4 g,,4 |
      r1 |
      b,,1~ |
      b,,2 g,,2~ |
      g,,1 |
      b,,1~ |
      b,,1~ |
      b,,1~ |
      b,,1~ |
      b,,1 |
      b,,1~ |
      b,,1 |
      g,,1~ |
      g,,1 |
      e,,1~ |
      e,,1~ |
      e,,1~ |
      e,,1 |
      cis,,1~ |
      cis,,1 |
      fis,,1~ |
      fis,,1~ |
      fis,,1~ |
      fis,,1 |
      b,,1~ |
      b,,1 |
      g,,1~ |
      g,,1 |
      g,,2^\markup { \tiny \italic "Countersubject" } a,,4 b,,8 a,,8 |
      g,,2 fis,,8 g,,8 a,,8 g,,8 |
      fis,,2 g,,2 |
      e,,2 fis,,4 ais,,4 |
      b,,1 |
      b,,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
