\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "V. Prelude in D major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key d \major \time 6/8
      \tempo "Allegro giocoso" 4 = 102
      \mark \markup \box \small "Opening cell" d''4\p a''8 fis''8 d'''8 a''8 |
      a''4 e'''8 cis'''8 a'''8 e'''8 |
      d'''4 a'''8 fis'''8 d''''8 a'''8 |
      d'''4 b''8 cis'''8 d'''8 b''8 |
      e''4 b''8 g''8 e'''8 b''8 |
      a''4 e'''8 cis'''8 a'''8 e'''8 |
      d'''4 a'''8 fis'''8 d''''8 a'''8 |
      e'''4 cis'''8 d'''8 e'''8 cis'''8 |
      \mark \markup \box \small "Contrasting span" d'''4\mp b'''8 fis'''8 d'''8 b''8 |
      ais''4 fis'''8 cis'''8 ais''8 fis''8 |
      d''4 b''8 fis''8 d''8 b'8 |
      fis'4 cis''8 a'8 fis''8 cis''8 |
      b'4 g''8 d''8 b'8 g'8 |
      g'4 e''8 b'8 g'8 e'8 |
      gis'4 e''8 b'8 gis'8 e'8 |
      a'4 e''8 cis''8 a''8 e''8 |
      \mark \markup \box \small "Development" fis''4\mf a''8 g''8 fis''8 a''8 |
      b''4 d'''8 g'''8 b''8 d'''8 |
      fis''4 a''8 g''8 fis''8 a''8 |
      e''4 a'8 cis''8 e''8 a''8 |
      d''4 fis''8 e''8 d''8 fis''8 |
      a''4 cis'''8 fis'''8 a''8 cis'''8 |
      g''4 b''8 a''8 g''8 b''8 |
      e''4 a'8 cis''8 e''8 a''8 |
      \mark \markup \box \small "Return" d''4\mp a''8 fis''8 d'''8 a''8 |
      g''4 d'''8 b''8 g'''8 d'''8 |
      g''4 d'''8 bes''8 g'''8 d'''8 |
      a''4 fis''8 g''8 a''8 fis''8 |
      \mark \markup \box \small "Cadence" e''4\p b''8 g''8 e'''8 b''8 |
      d''4 a''8 fis''8 d'''8 a''8 |
      a''4 e'''8 cis'''8 a'''8 cis'''8 |
      d'''2. \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key d \major \time 6/8
      fis'4.\p a'4. |
      e'4. e'4. |
      fis'4. fis'4. |
      d'4. b4. |
      g4. b4. |
      cis'4. e'4. |
      fis'4. fis'4. |
      cis'4. e'4. |
      d'4.\mp d'4. |
      ais4. cis'4. |
      d'4. d'4. |
      a4. cis'4. |
      b4. b4. |
      g4. b4. |
      gis4. b4. |
      cis'4. e'4. |
      fis'4.\mf a'4. |
      b'4. b'4. |
      a'4. fis'4. |
      cis'4. e'4. |
      d'4. fis'4. |
      cis'4. cis'4. |
      b4. b4. |
      cis'4. e'4. |
      fis'4.\mp a'4. |
      b'4. d''4. |
      bes'4. bes'4. |
      fis'4. a'4. |
      g'4.\p b'4. |
      a'4. a'4. |
      e'4. g'4. |
      fis'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key d \major \time 6/8
      d,4.\p d,4. |
      a,,4. a,,4 g,,8 |
      fis,,4. fis,,4. |
      g,,4. g,,4. |
      g,,4. g,,4. |
      a,,4. a,,4. |
      d,4. d,4. |
      a,,4. a,,4. |
      b,,4.\mp b,,4. |
      fis,4. fis,4. |
      b,,4. b,,4. |
      fis,4. fis,4. |
      g,4. g,4. |
      g,4. g,4 fis,8 |
      e,4. e,4. |
      a,4. a,4. |
      d,4.\mf d4. |
      g,4. g4. |
      fis,4. fis4. |
      a,4. a4. |
      b,4. b4. |
      fis,4. fis4. |
      g,4. g4. |
      a,4. a4. |
      d,4.\mp d,4. |
      g,4. g,4. |
      g,4. g,4. |
      fis,4. fis,4. |
      g,4.\p g,4. |
      a,4. a,4. |
      a,4. a,4. |
      d,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
