\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XII. Fugue in F minor — The long shadow"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a3")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key f \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 84
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'''4^\markup { \tiny \italic "Subject" } c''''4 aes'''2 |
      g'''4 f'''8 ees'''8 des'''2 |
      ees'''2 f'''2 |
      aes'''4^\markup { \tiny \italic "Countersubject" } bes'''8 aes'''8 g'''4. f'''16 g'''16 |
      bes'''4 aes'''8 g'''8 f'''2 |
      g'''2 aes'''2 |
      c''''4 bes'''4 aes'''2 |
      des''''4 c''''8 des''''8 ees''''8 des''''8 c''''4~ |
      c''''8 bes'''8 des'''4 des''''8 ees''''8 f''''4 |
      c''''2 f'''2 |
      \mark \markup \box \small "Sequential episode" f'''2 c''''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'''4 bes''4 ees'''2 |
      bes''4 ees'''4 aes''4 c'''4 |
      g'''2 ees'''2 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" aes'''4 g'''2. |
      f'''4. g'''8 aes'''2 |
      ees''''4. d''''8 c''''2 |
      \mark \markup \box \small "Linking episode" aes'''1 |
      g'''2 c''''2 |
      \mark \markup \box \small "Development" bes'''4^\markup { \tiny \italic "Related-key subject" } f''''4 des''''2 |
      c''''4 bes'''8 aes'''8 ges'''2 |
      aes'''2 bes'''2 |
      bes'''4 c''''2. |
      bes'''4. c''''8 des''''2 |
      c''''2 bes'''2 |
      \mark \markup \box \small "Stretto" aes'''2~ aes'''8 g'''8 f'''4 |
      g'''4 aes'''2 des''''4 |
      c''''4 g'''4 f'''4^\markup { \tiny \italic "Stretto subject" } c''''4 |
      aes'''2 g'''4 f'''8 ees'''8 |
      des'''2 ees'''2 |
      f'''2 f'''4 c'''4 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" c''''2~ c''''8 bes'''8 aes'''4~ |
      aes'''2. c''''4 |
      des''''4 aes''''4 des''''2~ |
      des''''2 aes''''2 |
      des''''2. f'''4~ |
      f'''2 f''''4 des''''4 |
      c''''1~ |
      c''''1 |
      \mark \markup \box \small "Gathered development" f'''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } c''''2 |
      aes'''2 c''''4 f''''4~ |
      f''''1~ |
      f''''2. f'''4~ |
      f'''4 des''''4 des'''2 |
      des''''2 des'''2 |
      des''''4 bes''''4 g''''2~ |
      g''''1~ |
      g''''4 e''''2. |
      g'''4 e'''2.~ |
      e'''4 e''''4 g''''4 c''''4 |
      e''''4 e'''4 e''''2~ |
      e''''2. c''''4 |
      aes'''4 c''''4 aes''''2 |
      aes'''2 c'''4 c''''4 |
      f'''4 f''''4 f'''4 aes'''4~ |
      aes'''4 f'''2 des''''4 |
      \mark \markup \box \small "Final return" des''''4 c''''2. |
      bes'''2 g'''2 |
      aes'''2 bes'''2 |
      \mark \markup \box \small "Final cadence" bes'''2 c''''2 |
      aes'''1 |
      aes'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'''4^\markup { \tiny \italic "Subject" } c''''4 aes'''2 |
      g'''4 f'''8 ees'''8 des'''2 |
      ees'''2 f'''2 |
      aes'''4^\markup { \tiny \italic "Countersubject" } bes'''8 aes'''8 g'''4. f'''16 g'''16 |
      bes'''4 aes'''8 g'''8 f'''2 |
      g'''2 aes'''2 |
      f'''8 ees'''8 des'''4 f'''2 |
      e'''2 f'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'''4 aes'''4 ees'''2~ |
      ees'''4 aes''4 des'''8 c'''8 bes''4 |
      ees''4 c'''4 f''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'''4 ees'''4. des'''8 c'''4 |
      g'''4 bes''4 f'''2 |
      c''''4 g'''4 bes''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'''2 f'''2 |
      aes'''4 c'''4 aes'''2~ |
      aes'''4 des'''2. |
      aes'''4. g'''8 f'''2 |
      des'''2.~ des'''8 ees'''8 |
      f'''2 bes'''2 |
      f'''2.~ f'''8 g'''8 |
      aes'''4. bes'''8 c''''2 |
      c'''2 f'''2~ |
      f'''4 c'''2. |
      des'''4 aes''4 des'''2 |
      f'''4 des'''4 aes''2 |
      bes''4 des'''2.~ |
      des'''4 bes''2 f''4 |
      g''4 bes''4 g'''2 |
      bes''4 g'''2. |
      bes''4 g'''2.~ |
      g'''4 bes''2. |
      c'''1~ |
      c'''2 g'''4 c'''4~ |
      c'''2 g'''2 |
      f'''4 aes'''2. |
      c'''4 f''4 c'''2 |
      des'''4 f'''2. |
      aes''2 des'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'''4^\markup { \tiny \italic "Subject" } c''''4 aes'''2 |
      g'''4 f'''8 ees'''8 des'''2 |
      ees'''2 f'''2 |
      aes''4^\markup { \tiny \italic "Countersubject" } bes''8 aes''8 g''4. f''16 g''16 |
      bes''4 aes''8 g''8 f''2 |
      g''2 aes''2 |
      f''1 |
      e''2 f''2 |
      ees''4 bes''4 ees'''4 bes''4~ |
      bes''4 f'''4 c'''4 f'''4 |
      ees'''8 f'''8 g'''4 c'''4 aes''4 |
      r1 |
      r1 |
      bes''4 f''4 des'''4 aes''4~ |
      aes''4 ees'''2. |
      aes''8 bes''8 c'''4 ees''4 bes''4 |
      bes''4 g'''4 c'''4 ees''4~ |
      ees''4 bes''2 des'''4 |
      aes'''4 c'''4 f''4 bes''4 |
      des'''4 ees'''4 aes'''4 c'''4 |
      ees'''4 aes''2. |
      ees'''2 aes''2~ |
      aes''4 ees'''2 aes''4 |
      des'''4 f''4 ees''4 bes''4~ |
      bes''4 f'''4 c'''2 |
      r1 |
      c'''4 f'''4 c'''2~ |
      c'''4 f'''2~ f'''8 ees'''8 |
      des'''2. aes''4~ |
      aes''2 des'''2~ |
      des'''4 bes''4 f''4 des'''4~ |
      des'''4 f'''2. |
      c'''4 f'''4 c'''2~ |
      c'''4 f'''4 c'''4 f'''4 |
      f'''4 c'''4 aes''2~ |
      aes''4 c'''2 aes'''4~ |
      aes'''4 f'''2 des'''4~ |
      des'''4 aes''4 des'''2~ |
      des'''2 bes''2~ |
      bes''4 des'''4 bes''2~ |
      bes''4 des'''4 bes'''4 bes''4~ |
      bes''2 g'''2~ |
      g'''4 bes''2 bes'4~ |
      bes'4 g''2.~ |
      g''4 g'''2 g''4~ |
      g''2 g'''2~ |
      g'''4 c'''2.~ |
      c'''2. aes''4~ |
      aes''4 c'''4 f''2~ |
      f''4 des'''4 aes''4 des'''4~ |
      des'''2 aes''4 des'''4 |
      aes''4 ees''4 aes''4 ees'''4~ |
      ees'''4 bes'''4 des'''2 |
      aes''4 ees'''4 bes''2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      c'''4^\markup { \tiny \italic "Real answer" } g'''4 ees'''2 |
      d'''4 c'''8 bes''8 aes''2 |
      bes''2 c'''2 |
      des'''4^\markup { \tiny \italic "Countersubject" } ees'''8 des'''8 c'''4. bes''16 c'''16 |
      ees'''4 des'''8 c'''8 bes''2 |
      c'''2 des'''2 |
      c'''4 bes''2.~ |
      bes''4 c'''2.~ |
      c'''8 bes''4. aes''4. g''8 |
      f''2 f'''4 aes''4~ |
      aes''2 c''8 des''8 ees''4~ |
      ees''4 aes'4 bes'2 |
      g''2 f''2 |
      f''2 e''4 f''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''4 g''4 aes''8 bes''8 c'''4~ |
      c'''4 aes''4 des'''8 c'''8 bes''4 |
      ees'''8 des'''8 c'''4 aes''4 f''4 |
      c'''4 g''2 bes''4~ |
      bes''4 c'''4. bes''8 aes''4 |
      g''8 aes''8 bes''4 ees'''8 d'''8 c'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes''4 c'''4. des'''8 ees'''4 |
      c'''4 f''2 bes''4 |
      ees'''8 des'''8 c'''4 f'''4 des'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'''4 g''4. aes''8 bes''4~ |
      bes''4 f''2. |
      bes''4 ees'''2 c'''4 |
      r1 |
      r1 |
      ges''4 f''4. ges''8 aes''4~ |
      aes''4 bes''2 ees''4 |
      c''4 f''4 bes''4 ges''4 |
      bes'4 ees''2~ ees''8 f''8 |
      g''8 aes''8 bes''2 f''4 |
      aes''4 ees''4 bes''4 des'''4 |
      des'''4 aes''2 f'''4 |
      bes''4 f''2. |
      ees''8 f''8 g''4 c''4 f''4~ |
      f''4 aes''4 ees''4 f''4~ |
      f''4 bes''2. |
      des''4 aes''8 bes''8 c'''4 g''4 |
      r1 |
      aes''8 bes''8 c'''4 aes''2~ |
      aes''4 f''4 aes''2 |
      des'''4 aes''2. |
      f''8 g''8 aes''2 f''4 |
      bes''8 c'''8 des'''4 bes''4 f''4~ |
      f''4 bes''2 f''4~ |
      f''4 c''2 f''4~ |
      f''4 aes''2. |
      aes''4 f''2 aes''4~ |
      aes''4 f''2 aes''4~ |
      aes''4 des'''2 aes''4~ |
      aes''4 f''4 aes''4 des''4~ |
      des''4 f''2 bes''4~ |
      bes''4 f''2 bes'4~ |
      bes'4 g''2 bes''4~ |
      bes''4 g''2.~ |
      g''4 bes''2.~ |
      bes''4 g''2.~ |
      g''4 c''4 g''4 c'''4~ |
      c'''4 g''2.~ |
      g''4 c'''2.~ |
      c'''4 f''4 aes''4 c'''4~ |
      c'''4 aes''4 c'''4 f''4~ |
      f''4 aes''2 f''4 |
      aes''4 des'''2 f'''4 |
      f'''4 c'''2 ees'''4~ |
      ees'''4 bes''2 des''4 |
      aes''4 c'''4 bes''4 des'''4 |
      des'''4 bes''4 g'''4 c'''4~ |
      c'''4 f''2 aes''4 |
      c'''4 aes''2 f''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c''4^\markup { \tiny \italic "Real answer" } g''4 ees''2 |
      d''4 c''8 bes'8 aes'2 |
      bes'2 c''2 |
      des''4^\markup { \tiny \italic "Countersubject" } ees''8 des''8 c''4. bes'16 c''16 |
      ees''4 des''8 c''8 bes'2 |
      c''2 des''2 |
      ees''2~ ees''8 f''8 g''4~ |
      g''8 f''8 ees''8 d''8 c''2 |
      d''2 c''4 ees''4 |
      des''1 |
      c''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'4 ees''4 aes''4 ees''4~ |
      ees''4 aes''4 des''8 ees''8 f''4 |
      c''8 des''8 ees''4 bes''4 des'''4 |
      aes''4 ees''4. d''8 c''4 |
      f''8 g''8 aes''4 c''2 |
      g'8 aes'8 bes'4 ees''4 aes''4 |
      r1 |
      r1 |
      c''4^\markup { \tiny \italic "Related-key subject" } g''4 ees''2 |
      d''4 c''8 bes'8 aes'2 |
      bes'2 c''2 |
      c''1 |
      b'2 c''2 |
      des''4 c''4 des''4 f''4 |
      ees''2~ ees''8 des''8 c''4~ |
      c''2 ees''2 |
      f''4^\markup { \tiny \italic "Related-key subject" } c'''4 aes''2 |
      g''4 f''8 ees''8 des''2 |
      ees''2 f''2 |
      des''4 c''4 f''2 |
      ees''4 aes''8 g''8 f''4 aes''4 |
      ees''4 bes'4 f''4 aes''4 |
      f''4 ees''4 c''2 |
      des''8 c''8 bes'4 ees''4 g''4 |
      f''8 g''8 aes''2 g''4 |
      r1 |
      c''8 bes'8 aes'4 c''4 f''4~ |
      f''4 aes''4 f''4 aes''4 |
      f''8 ees''8 des''4 f''4 des''4~ |
      des''4 f''4 des''4 f''4~ |
      f''4 des''4 f''2~ |
      f''4 des''8 ees''8 f''2~ |
      f''4 aes''4 f''4 aes''4~ |
      aes''4 f''4 aes''4 f''4 |
      aes'4 c''2 aes''4 |
      c''4 f'4 aes'4 c''4 |
      aes''2. aes'4~ |
      aes'2 aes''4 f''4~ |
      f''2 f'4 f''4 |
      f'2. f''4 |
      des'''2 des''2 |
      des'''2 bes''4 g''4 |
      e''4 g''4 bes'2~ |
      bes'1 |
      g'2. g''4 |
      g'1~ |
      g'2. e''4 |
      f''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } c'''2 |
      c''4 c'''4 aes''2~ |
      aes''2 f''4 f'4~ |
      f'4 aes'2 f'4 |
      aes'4 c''4 ees''4 aes''4 |
      ees''4 f''4 bes''4 g''4 |
      ees''4 c''4 f''4 bes''4 |
      bes''4 f''4 c'''2~ |
      c'''4 aes''4 f''2~ |
      f''4 aes''4 c'''4 aes''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c''4^\markup { \tiny \italic "Real answer" } g''4 ees''2 |
      d''4 c''8 bes'8 aes'2 |
      bes'2 c''2 |
      des''4^\markup { \tiny \italic "Countersubject" } ees''8 des''8 c''4. bes'16 c''16 |
      ees''4 des''8 c''8 bes'2 |
      c''2 des''2 |
      ees''2 bes'4 c''4 |
      bes'4 c''2 f''4 |
      d''2 c''2 |
      aes'4. g'8 f'4 bes'4 |
      g'2 f'8 g'8 aes'4 |
      ees'8 f'8 g'4 bes'4 ees''4 |
      bes'4 c''4 f''4 c''4 |
      g'2 c''4 ees''4 |
      c''4. bes'8 aes'4 f'4 |
      d''2 ees''8 d''8 c''4 |
      r1 |
      r1 |
      r1 |
      bes'4 g'4 c''4 aes'4 |
      bes'8 c''8 des''4 f''4 des''4 |
      aes'8 bes'8 c''4 f''4 des''4 |
      aes'2 c''4 aes'4 |
      bes'4 aes'4 des''4 aes'4 |
      g'2 c''4 aes'4 |
      c''4. des''8 ees''4 c''4 |
      bes'8 c''8 des''4 bes'4 g'4 |
      bes'4 c''4 f''4 g''4 |
      r1 |
      aes'2 f'4 aes'4 |
      c''2 f''4 c''4 |
      aes'4. g'8 f'4 aes'4 |
      des''4. ees''8 f''4 des''4 |
      bes'4. c''8 des''4 bes'4 |
      des''8 c''8 bes'4 des''4 bes'4 |
      aes'4. bes'8 c''4 aes'4 |
      c''4. bes'8 aes'4 c''4 |
      aes'2 c''4 aes'4 |
      c''2. aes'4 |
      f'2 aes'4 f'4 |
      aes'2 f'4 des'4 |
      f'2 bes'4 des''4 |
      bes'2 des''4 bes'4 |
      des''4 bes'4 des''4 bes'4 |
      des''4 bes'4 des''4 bes'4~ |
      bes'2 g'4 bes'4~ |
      bes'2 g'2~ |
      g'4 c''2 g'4 |
      c''2. g'4 |
      c''2 g'4 c''4~ |
      c''2 aes'4 f'4 |
      aes'4 f'4 aes'4 f'4 |
      aes'4 des''4 f''4 des''4 |
      aes'2 f'4 aes'4 |
      aes'4 g'4 c''4 aes'4 |
      bes'2 des''4 bes'4 |
      aes'2 des''4 bes'4 |
      bes'2 g'2 |
      aes'2 c''4 aes'4 |
      f'2 aes'4 c''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key f \minor \time 4/4
      f'4^\markup { \tiny \italic "Subject" } c''4 aes'2 |
      g'4 f'8 ees'8 des'2 |
      ees'2 f'2 |
      aes'4^\markup { \tiny \italic "Countersubject" } bes'8 aes'8 g'4. f'16 g'16 |
      bes'4 aes'8 g'8 f'2 |
      g'2 aes'2 |
      f'4 ees'4 f'2 |
      g'8 aes'8 bes'2. |
      aes'4. g'8 f'2 |
      ees'8 f'8 g'4 bes'2 |
      f''4 aes'2. |
      g'4 d'4 ees'2 |
      aes'4 bes'8 c''8 des''2 |
      aes'2. c'4 |
      g'4 aes'4 des'4 des''4~ |
      des''8 c''4 bes'8 aes'2 |
      aes'4 bes'4 c''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      aes'4 g'4 f'2~ |
      f'8 ees'8 f'4 bes'2 |
      g'2 f'2 |
      ees'4. f'8 g'4 ees'4 |
      f'8 g'8 aes'4 c''2~ |
      c''8 bes'4. aes'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'8 g'8 aes'2. |
      ees'4 f'4 bes'2 |
      g'2 bes'2 |
      aes'4 g'4 bes'4 g'4 |
      d'4 ees'4 f'8 g'8 aes'4 |
      g'2 ees'2 |
      r1 |
      r1 |
      ees'4 d'4 ees'2 |
      f'2 c''2 |
      bes'8 aes'8 g'4 ees'2 |
      ees'2 f'2 |
      d'2 g'2 |
      bes4 c'4 f'4 des'4 |
      ees'4. f'8 ges'2 |
      f'8 ges'8 aes'4 ges'2 |
      f'4 g'4 aes'2 |
      ees'4 f'4 bes'2 |
      ees'8 f'8 g'4 f'2 |
      des''4 aes''8 g''8 f''4 aes'4 |
      ees''4 des''8 ees''8 f''4 f'4 |
      c'8 des'8 ees'4 aes'2 |
      c'8 des'8 ees'2 aes'4 |
      des'8 ees'8 f'4 bes4 bes'4 |
      des''8 ees''8 f''4 aes'4 c'4 |
      r1 |
      aes''2. c''4~ |
      c''2. aes'4~ |
      aes'4 des''4 aes''4 aes'4 |
      aes''2 des''2 |
      f'2. des'4~ |
      des'2. f'4 |
      aes'1~ |
      aes'1 |
      aes'2 f'2 |
      aes'2 f'2 |
      aes'2 f'2 |
      des'2 f'2 |
      des'2 f'2 |
      des'4 f'4 bes'4 des''4 |
      bes'4 g'4 bes'2 |
      g'2 bes'2~ |
      bes'4 g'4 bes'2 |
      g'2 bes'4 g'4~ |
      g'2 c''2 |
      g'2 c''2 |
      g'2 c''2~ |
      c''4 aes'4 c''2 |
      aes'2 f'4 aes'4 |
      f'2 aes'2 |
      f'2 aes'2 |
      f'4^\markup { \tiny \italic "Subject" } c''4 aes'2 |
      g'4 f'8 ees'8 des'2 |
      ees'2 f'2 |
      f'2 e'2 |
      f'2 aes'2 |
      aes'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4^\markup { \tiny \italic "Subject" } c''4 aes'2 |
      g'4 f'8 ees'8 des'2 |
      ees'2 f'2 |
      aes'4^\markup { \tiny \italic "Countersubject" } bes'8 aes'8 g'4. f'16 g'16 |
      bes'4 aes'8 g'8 f'2 |
      g'2 aes'2 |
      f'4 ees'4 f'2 |
      c'4 des'2. |
      c'8 des'8 ees'4 des'2 |
      c'8 d'8 ees'4 bes2 |
      d'4 ees'4 f'2 |
      d'2 ees'2 |
      f'8 g'8 aes'4 des''8 c''8 bes'4 |
      g'2 f'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'4 c'8 des'8 ees'4 aes'4 |
      c''8 bes'8 aes'4 bes'4 f'4 |
      ees'2 des'4 f'4 |
      ees'8 f'8 g'2 ees'4 |
      f'4 ees'8 d'8 c'2 |
      bes8 c'8 d'4 ees'4 c'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'2 f'4 c'4 |
      g'4 d'4 c'4 ees'4 |
      des'8 ees'8 f'4 aes'4 f'4 |
      c'4 ees'4 bes4 ees'4 |
      aes'8 ges'8 f'4 ees'4 ges'4 |
      bes'4 ees'4 aes'4 ees'4 |
      bes2 f4 bes4 |
      ees'2 des'4 f'4 |
      f'4 ees'4 f'4 aes'4 |
      ees'4 f'8 g'8 aes'4 f'4 |
      g'2 aes'4 f'4 |
      c'2 g'4 aes'4 |
      f'2 g'4 ees'4 |
      des'4 c'4 aes4 c'4 |
      r1 |
      f'2 aes'4 f'4 |
      c'8 bes8 aes4 c'4 f'4 |
      aes'8 g'8 f'4 aes'4 f'4 |
      des'2 aes4 des'4 |
      f'2 des'4 f'4 |
      des'4. c'8 bes4 des'4 |
      f'4. g'8 aes'4 f'4 |
      c'2 f'4 aes'4 |
      f'2 aes'4 f'4 |
      c'2 f'2~ |
      f'4 des'4 f'4 aes'4 |
      f'2 des'4 f'4~ |
      f'2 des'4 bes4 |
      des'2 f'4 des'4~ |
      des'2 bes4 des'4 |
      bes2 g2 |
      bes2. g4 |
      bes2. g'4~ |
      g'2 c'4 g'4 |
      c'2 g4 c'4 |
      g'2. c'4~ |
      c'2 f'4 aes'4 |
      f'2 c'4 aes4~ |
      aes2 des'4 f'4 |
      des'2 f'4 des'4 |
      f'4 g'4 aes'4 ees'4 |
      bes2. des'4 |
      c'4 ees'4 des'4 f'4 |
      f'2 g'2 |
      f'2 c'4 f'4 |
      aes'2 f'4 aes'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "bass" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4^\markup { \tiny \italic "Subject" } c'4 aes2 |
      g4 f8 ees8 des2 |
      ees2 f2 |
      aes4^\markup { \tiny \italic "Countersubject" } bes8 aes8 g4. f16 g16 |
      bes4 aes8 g8 f2 |
      g2 aes2 |
      bes4 aes4 c'2~ |
      c'4 des'2. |
      c'2 bes2 |
      c'8 d'8 ees'4 g'2 |
      f'4 c'2. |
      d'8 c'8 bes4 aes2 |
      aes2 bes2 |
      c'1 |
      c'4 bes2. |
      f8 g8 aes2. |
      g4 bes4 aes2 |
      c4 aes8 bes8 c'2 |
      g2.~ g8 aes8 |
      bes4 aes2. |
      ees8 f8 ges4 bes4 c'4~ |
      c'2 bes2 |
      des'4 c'8 des'8 ees'2~ |
      ees'4 bes2. |
      aes4 g4 bes2 |
      f8 g8 aes2 c'4 |
      bes4 des'4 aes2 |
      c'4 bes4 aes4 c'4 |
      f'4 c'4. bes8 aes4 |
      bes2. ees'4 |
      bes4 f2 c'4 |
      r1 |
      f4 aes2 c'4 |
      aes8 bes8 c'4 aes4 f4~ |
      f4 aes2 des'4 |
      aes4 f2 aes4 |
      f4 bes2 des'4 |
      bes4 f2 bes4 |
      c'4 aes2 c'4 |
      aes8 bes8 c'2 aes4 |
      c'4 aes'4 aes4 c'4~ |
      c'4 c4 aes2 |
      des'4 des4 des'2 |
      des4 des'2 aes'4 |
      des'4 bes4 des'2 |
      bes'2 bes2 |
      g4 g'2. |
      bes'2 des'2 |
      bes2 g'2 |
      e'4 g2. |
      c2 e4 e'4 |
      g4 c2.~ |
      c2. g4 |
      c4 aes4 f4 f'4~ |
      f'1~ |
      f'4 aes2 des4 |
      des'4 aes'4 des'4 aes4 |
      aes4 ees'2 c'4 |
      g4 bes2. |
      ees'4 aes'4 f'4 des'4 |
      des'4 f'4 c'2 |
      f4 aes2 c'4 |
      aes4 c'2 f'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "bass" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'4^\markup { \tiny \italic "Real answer" } g'4 ees'2 |
      d'4 c'8 bes8 aes2 |
      bes2 c'2 |
      aes4 des'4 f4. ees8 |
      des4^\markup { \tiny \italic "Countersubject" } ees8 des8 c4. bes,16 c16 |
      ees4 des8 c8 bes,2 |
      c2 des2 |
      f2 g4 aes4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      aes'4 ees'4 aes'2 |
      c'4 f'2. |
      ees'8 f'8 g'4 aes'4 des'4 |
      aes4 g4 bes2~ |
      bes4 ees4 aes4 f4 |
      bes8 aes8 g4 c'4 aes4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des'4 aes4 ees'4 c'4~ |
      c'4 f'2. |
      g'8 f'8 ees'4 bes2 |
      ees'4 bes2 ees'4 |
      bes4 ees4 aes4 f4 |
      bes4 g4 c'4 aes4 |
      r1 |
      r1 |
      c4 d4 g2 |
      d4 f4. g8 aes4 |
      ees2. aes4 |
      r1 |
      r1 |
      des4 aes,4 des4 aes4~ |
      aes4 ees2 c'4~ |
      c'4 aes4 ees4 bes,4 |
      f4 c2 ees4 |
      bes4 f2. |
      c8 des8 ees4 bes,4 f4 |
      f4 c2 f4 |
      bes4 des2 f4 |
      c'4 ees8 des8 c4 aes4~ |
      aes4 c'2 f'4~ |
      f'4 bes2. |
      f4 c'2. |
      r1 |
      aes4 f2 c4~ |
      c4 aes2. |
      des4 f2. |
      aes2. des4~ |
      des4 f2 bes4~ |
      bes4 des'2. |
      aes4 f2 c'4~ |
      c'4 aes2. |
      aes4 c2 f4~ |
      f4 aes2 f4~ |
      f2 des4 f4~ |
      f4 aes2 des'4 |
      f4 des2 f4~ |
      f4 bes4 f4 bes4~ |
      bes2. g4~ |
      g4 bes2. |
      bes,2. g4~ |
      g4 bes4 g'2~ |
      g'4 g2.~ |
      g4 c'2.~ |
      c'4 g4 c2~ |
      c4 f2 c4 |
      f4 c2 f4~ |
      f4 des2 aes,4 |
      des4 f2. |
      f4 ees2. |
      bes4 f4 g4 bes4 |
      ees2 bes4 f4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c4^\markup { \tiny \italic "Real answer" } g4 ees2 |
      d4 c8 bes,8 aes,2 |
      bes,2 c2 |
      f2 bes,2 |
      c4. bes,8 aes,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'4 g2 c'4 |
      f4 c'2 f4 |
      bes,4 g4 c4 ees4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      des4 aes2~ aes8 bes8 |
      c'4 ees2. |
      c'4 f4 bes,4 ees4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 c2. |
      f4 c2. |
      f2 des2 |
      f4 des2 aes4 |
      bes4 f2 bes,4~ |
      bes,4 f2. |
      aes,4 c2. |
      f4 c2. |
      c4 f2 c4~ |
      c4 aes,2 f4~ |
      f4 aes2 des4~ |
      des4 f2.~ |
      f4 bes4 f4 des4 |
      f4 des2 bes4~ |
      bes4 bes,2. |
      g2. bes4~ |
      bes4 bes,2. |
      g1 |
      g,1~ |
      g,4 g2. |
      c2. c'4 |
      c2. f4 |
      c2. aes4~ |
      aes4 f4 des2 |
      f4 des2. |
      aes4 c2. |
      g4 bes,2 g4 |
      c'4 aes4 des2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c4^\markup { \tiny \italic "Real answer" } g4 ees2 |
      d4 c8 bes,8 aes,2 |
      bes,2 c2 |
      des1 |
      c4. bes,8 aes,2 |
      ees4 bes,2. |
      f4 c2. |
      ees4 bes,4 ees2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,4 c2. |
      f,2 c2 |
      f,4 des2. |
      f,2 aes,2 |
      des4 f,4 bes,2 |
      f,4 bes,,4 f,2~ |
      f,4 c4 aes,2 |
      f,2 c2 |
      c4 aes,2. |
      f,4 c4 aes,2~ |
      aes,4 des,4 aes,4 des4 |
      aes,2 f2~ |
      f4 bes,2. |
      f,2 des,2 |
      bes,1 |
      des,2 bes,2 |
      g1 |
      g,1 |
      g2 g,2~ |
      g,2 c,2~ |
      c,4 c2.~ |
      c2 f,2~ |
      f,4 aes,2.~ |
      aes,4 des,4 aes,2~ |
      aes,4 f4 des2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key f \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f,8 ees,8 des,2. |
      f,4^\markup { \tiny \italic "Subject" } c4 aes,2 |
      g,4 f,8 ees,8 des,2 |
      ees,2 f,2 |
      des,2 c,4 f,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      aes,4^\markup { \tiny \italic "Countersubject" } bes,8 aes,8 g,4. f,16 g,16 |
      bes,4 aes,8 g,8 f,2 |
      g,2 aes,2 |
      aes,4. g,8 f,2 |
      g,4. f,8 ees,2 |
      ges,4^\markup { \tiny \italic "Countersubject" } aes,8 ges,8 f,4. ees,16 f,16 |
      aes,4 ges,8 f,8 ees,2 |
      f,2 ges,2 |
      des,4^\markup { \tiny \italic "Countersubject" } ees,8 des,8 c,4. bes,,16 c,16 |
      ees,4 des,8 c,8 bes,,2 |
      c,2 des,2 |
      f,4^\markup { \tiny \italic "Stretto subject" } c4 aes,2 |
      g,4 f,8 ees,8 des,2 |
      ees,2 f,2 |
      f,4 c2 f,4 |
      bes,,2 g,,4 g,4 |
      bes,,4 aes,,4 aes,4 e,4 |
      r1 |
      f,1~ |
      f,1~ |
      f,1~ |
      f,1 |
      bes,,1~ |
      bes,,1 |
      f,1~ |
      f,1 |
      f,1~ |
      f,1 |
      des,1~ |
      des,1 |
      bes,,1~ |
      bes,,1~ |
      bes,,1~ |
      bes,,1 |
      g,,1~ |
      g,,1 |
      c,1~ |
      c,1~ |
      c,1 |
      f,1~ |
      f,1 |
      des,1~ |
      des,1 |
      des,4^\markup { \tiny \italic "Countersubject" } ees,8 des,8 c,4. bes,,16 c,16 |
      ees,4 des,8 c,8 bes,,2 |
      c,2 des,2 |
      des,2 c,2 |
      f,1 |
      f,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
