\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XI. Prelude in F major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key f \major \time 6/8
      \tempo "Andantino pastorale" 4 = 94
      \mark \markup \box \small "Opening cell" a'8.\p bes'16 a'8 c''4 a'8 |
      bes'8. c''16 bes'8 c''4 bes'8 |
      a'8. bes'16 a'8 c''4 a'8 |
      bes'8. a'16 bes'8 a'4 bes'8 |
      f'8. g'16 f'8 g'4 f'8 |
      g'8. a'16 bes'8 c''4 bes'8 |
      g'8. a'16 g'8 a'4 g'8 |
      f'8. g'16 f'8 g'4 f'8 |
      \mark \markup \box \small "Contrasting span" a'8.\mp bes'16 a'8 bes'4 a'8 |
      c''8. bes'16 c''8 d''4 c''8 |
      bes'8. a'16 bes'8 c''4 bes'8 |
      f'8. g'16 a'8 bes'4 a'8 |
      g'8. f'16 g'8 a'4 bes'8 |
      g'8. a'16 g'8 a'4 g'8 |
      a'8. bes'16 a'8 bes'4 a'8 |
      g'8. f'16 g'8 a'4 g'8 |
      \mark \markup \box \small "Development" bes'8.\mf a'16 bes'8 c''4 bes'8 |
      c''8. bes'16 c''8 d''4 c''8 |
      bes'8. a'16 bes'8 c''4 bes'8 |
      g'8. a'16 g'8 a'4 g'8 |
      f'8. g'16 f'8 g'4 f'8 |
      a'8. bes'16 a'8 bes'4 a'8 |
      f'8. a'16 g'8 a'4 f'8 |
      f'8. g'16 f'8 g'4 f'8 |
      a'8. bes'16 a'8 c''4 a'8 |
      bes'8. c''16 bes'8 c''4 d''8 |
      bes'8. a'16 bes'8 c''4 bes'8 |
      b'8. a'16 g'8 a'4 g'8 |
      e'8. g'16 f'8 g'4 e'8 |
      g'8. a'16 g'8 a'4 g'8 |
      a'8. bes'16 a'8 bes'4 a'8 |
      f'8. g'16 f'8 g'4 f'8 |
      \mark \markup \box \small "Return" bes'8.\mp a'16 bes'8 c''4 bes'8 |
      c''8. bes'16 c''8 d''4 c''8 |
      bes'8. a'16 bes'8 c''4 bes'8 |
      g'8. a'16 g'8 a'4 g'8 |
      \mark \markup \box \small "Cadence" f'8.\p g'16 f'8 g'4 a'8 |
      bes'8. a'16 bes'8 c''4 bes'8 |
      g'8. a'16 g'8 g'4 e'8 |
      f'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key f \major \time 6/8
      a4.\p c'4. |
      d'4. d'4. |
      c'4. c'4. |
      d'4. d'4. |
      c'4. c'4. |
      bes4. d'4. |
      e'4. c'4. |
      c'4. c'4. |
      d'4.\mp f'4. |
      e'4. e'4. |
      d'4. d'4. |
      c'4. c'4. |
      bes4. d'4. |
      e'4. e'4. |
      f'4. f'4. |
      e'4. e'4. |
      d'4.\mf d'4. |
      a4. c'4. |
      bes4. d'4. |
      e'4. c'4. |
      d'4. d'4. |
      cis'4. e'4. |
      d'4. f'4. |
      d'4. d'4. |
      c'4. c'4. |
      d'4. f'4. |
      d'4. d'4. |
      b4. d'4. |
      c'4. e'4. |
      e'4. c'4. |
      a4. c'4. |
      d'4. d'4. |
      des'4.\mp des'4. |
      a4. c'4. |
      bes4. d'4. |
      e'4. c'4. |
      a4.\p c'4. |
      d'4. f'4. |
      c'4. bes4. |
      a2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key f \major \time 6/8
      f,4.\p f,4. |
      bes,4. bes,4. |
      f,4. f,4. |
      bes,4. bes,4. |
      a,4. a,4. |
      bes,4. bes,4. |
      c4. c4. |
      f,4. f,4. |
      d,4.\mp d,4. |
      a,,4. a,,4. |
      bes,,4. bes,,4. |
      a,,4. a,,4. |
      bes,,4. bes,,4. |
      c,4. c,4. |
      f,4. f,4. |
      c,4. c,4. |
      bes,,4.\mf bes,,4. |
      a,,4. a,,4. |
      bes,,4. bes,,4. |
      c,4. c,4. |
      d,4. d4. |
      a,,4. a,4. |
      d,4. d4. |
      bes,,4. bes,4. |
      a,,4. a,4. |
      bes,,4. bes,4. |
      bes,,4. bes,4. |
      g,,4. g,4. |
      c,4. c4. |
      c,4. c4. |
      f,4. f,4. |
      bes,4. bes,4. |
      bes,4.\mp bes,4. |
      a,4. a,4. |
      bes,4. bes,4. |
      c4. c4. |
      f,4.\p f,4. |
      bes,4. bes,4. |
      c4. c4. |
      f,,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
