\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "I. Prelude in C major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key c \major \time 4/4
      \tempo "Andante, limpido" 4 = 84
      \mark \markup \box \small "Opening cell" c''8\p e''8 g''8 c'''8 g''8 e''8 g''8 e''8 |
      c''8 e''8 g''8 c'''8 g''8 e''8 g''8 e''8 |
      d''8 f''8 a''8 d'''8 a''8 f''8 a''8 f''8 |
      d''8 b'8 g'8 b'8 d''8 g''8 d''8 b'8 |
      c''8 e''8 g''8 c'''8 g''8 e''8 g''8 e''8 |
      f''8 a''8 c'''8 f'''8 c'''8 a''8 c'''8 a''8 |
      c'''8 e'''8 g'''8 c''''8 g'''8 e'''8 g'''8 e'''8 |
      d'''8 b''8 g''8 b''8 d'''8 g'''8 d'''8 b''8 |
      \mark \markup \box \small "Contrasting span" c'''8\mp a'''8 e'''8 c'''8 e'''8 c'''8 a''8 c'''8 |
      b''8 e'''8 b''8 gis''8 b''8 gis''8 e''8 gis''8 |
      e''8 a''8 e''8 c''8 e''8 c''8 a'8 c''8 |
      f''8 a''8 c'''8 f'''8 c'''8 a''8 c'''8 a''8 |
      a''8 d'''8 a''8 f''8 a''8 f''8 d''8 f''8 |
      a''8 d'''8 a''8 fis''8 a''8 fis''8 d''8 fis''8 |
      d''8 g''8 d''8 b'8 d''8 b'8 g'8 b'8 |
      g'8 b'8 d''8 g''8 d''8 b'8 d''8 b'8 |
      \mark \markup \box \small "Development" c''8\mf g''8 e''8 g''8 c'''8 g''8 e''8 c''8 |
      e''8 g''8 e''8 g''8 c'''8 g''8 e''8 c''8 |
      a'8 c''8 a'8 c''8 f''8 c''8 a'8 f'8 |
      f'8 d'8 f'8 a'8 f'8 a'8 d''8 a'8 |
      g'8 b'8 g'8 b'8 e''8 b'8 g'8 e'8 |
      c''8 e''8 c''8 e''8 a''8 e''8 c''8 a'8 |
      f''8 a''8 f''8 a''8 d'''8 a''8 f''8 d''8 |
      b'8 g'8 b'8 d''8 b'8 d''8 g''8 d''8 |
      \mark \markup \box \small "Return" c''8\mp e''8 g''8 c'''8 g''8 e''8 g''8 e''8 |
      f''8 a''8 c'''8 f'''8 c'''8 a''8 c'''8 a''8 |
      f''8 aes''8 c'''8 f'''8 c'''8 aes''8 c'''8 aes''8 |
      g''8 e''8 c''8 e''8 g''8 c'''8 g''8 e''8 |
      \mark \markup \box \small "Cadence" d''8\p f''8 a''8 d'''8 a''8 f''8 a''8 f''8 |
      c''8 e''8 g''8 c'''8 g''8 e''8 g''8 e''8 |
      g'8 b'8 d''8 g''8 d''8 b'8 d''8 b'8 |
      c''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key c \major \time 4/4
      e'2\p g'4 e'4 |
      e'2 g'4 g'4~^\markup { \tiny \italic "Prepared suspension" } |
      g'8 f'4.^\markup { \tiny \italic "Resolution" } f'4 d'4 |
      b2 d'4 d'4 |
      e'2 g'4 e'4 |
      c'2 a4 c'4 |
      e'2 g'4 c'4~^\markup { \tiny \italic "Prepared suspension" } |
      c'8 b4.^\markup { \tiny \italic "Resolution" } d'4 d'4~^\markup { \tiny \italic "Prepared suspension" } |
      d'8 c'4.^\markup { \tiny \italic "Resolution" } e'4 e'4 |
      gis'2 b'4 gis'4 |
      e'2 e'4 c'4 |
      a2 c'4 c'4 |
      d'2 f'4 f'4 |
      fis'2 a'4 a'4 |
      b'2 g'4 d'4 |
      d'2 g'4 d''4~^\markup { \tiny \italic "Prepared suspension" } |
      d''8 c''4.^\markup { \tiny \italic "Resolution" } e''4 c''4 |
      c''2 e''4 c''4 |
      f'2 a'4 f'4 |
      d'2 d'4 d'4 |
      e'2 g'4 e'4 |
      e'2 c'4 a4 |
      a2 f4 f4 |
      g2 g4 g4 |
      e2\mp g4 g4 |
      a2 c'4 a4 |
      aes2 c'4 c'4 |
      e'2 g'4 e'4 |
      f'2\p a'4 f'4 |
      e'2 g'4 e'4 |
      d'2 d'4 f'4 |
      e'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key c \major \time 4/4
      c,1\p |
      e,1 |
      f,1 |
      g,1 |
      c,1 |
      f,1 |
      e,2.~ e,8 f,8 |
      g,1 |
      a,1\mp |
      e,1 |
      a,2.~ a,8 g,8 |
      f,1 |
      f,1 |
      d,1 |
      g,1 |
      g,1 |
      c,1\mf |
      e,1 |
      f,1 |
      f,1 |
      e,1 |
      a,2.~ a,8 g,8 |
      f,1 |
      g,1 |
      c,1\mp |
      f,1 |
      f,1 |
      e,1 |
      f,1\p |
      g,1 |
      g,1 |
      c,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
