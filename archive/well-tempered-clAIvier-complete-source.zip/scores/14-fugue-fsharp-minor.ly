\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XIV. Fugue in F# minor — An interrupted line"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a3")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key fis \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 90
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''2^\markup { \tiny \italic "Subject" } cis''''4 b'''4 |
      a'''2 d''''4 cis''''4 |
      gis'''2 fis'''2 |
      a'''4.^\markup { \tiny \italic "Countersubject" } gis'''16 a'''16 b'''4 a'''4 |
      cis''''2~ cis''''8 b'''16 cis''''16 bis'''4 |
      b'''4. a'''16 b'''16 a'''2 |
      fis'''2 gis'''2~ |
      gis'''8 fis'''2~ fis'''8 gis'''4~ |
      gis'''2 a'''2 |
      \mark \markup \box \small "Sequential episode" a'''4. gis'''8 fis'''2~ |
      fis'''8 eis'''4. fis'''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2 fis'''4. e'''8 |
      d'''4 fis'''4 e'''4 b'''4 |
      fis'''2. cis'''8 d'''8 |
      e'''2 b''2 |
      a''8 b''8 cis'''4 e'''4 cis'''4 |
      e'''2 cis'''4 gis'''4 |
      b''2 e'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" cis''''2 a''''4 e''''4 |
      b'''8 cis''''8 d''''4 fis'''4 g'''4 |
      d''''4 g''''4 b'''4 fis'''4~ |
      fis'''2 g'''2 |
      \mark \markup \box \small "Linking episode" g'''2 b'''2 |
      ais'''2 b'''2 |
      \mark \markup \box \small "Development" cis''''2^\markup { \tiny \italic "Related-key subject" } gis''''4 fis''''4 |
      e''''2 a''''4 gis''''4 |
      dis''''2 cis''''2 |
      \mark \markup \box \small "Stretto" cis''''4 a''''2 d''''4 |
      cis''''2 fis'''4 e'''4 |
      b'''4 e'''4 fis'''2^\markup { \tiny \italic "Stretto subject" } |
      cis''''4 b'''4 a'''2 |
      d''''4 cis''''4 gis'''2 |
      fis'''2 fis'''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" a'''2.~ a'''8 b'''8 |
      cis''''1 |
      d''''1~ |
      d''''4 a'''2. |
      d''''1~ |
      d''''1 |
      a'''4 cis''''2.~ |
      cis''''2 a'''2 |
      \mark \markup \box \small "Gathered development" fis'''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      cis''''2 a'''2~ |
      a'''4 fis'''4 fis''''2~ |
      fis''''2. d''''4~ |
      d''''1 |
      fis'''2 d'''2~ |
      d'''2. d''''4~ |
      d''''2 b'''4 gis'''4 |
      eis'''4 eis''''2. |
      gis'''2 eis'''2~ |
      eis'''4 cis''''4 gis'''4 cis'''4 |
      eis'''2 gis'''4 cis''''4 |
      eis''''2 cis''''4 gis'''4 |
      a'''4 cis'''2 a'''4~ |
      a'''2. fis'''4~ |
      fis'''1~ |
      fis'''1 |
      \mark \markup \box \small "Final return" b'''2 cis''''4 d''''4 |
      a'''2 fis'''4 gis'''4~ |
      gis'''2 a'''2 |
      \mark \markup \box \small "Final cadence" b'''2^\markup { \tiny \italic "Final cadence" } cis''''2 |
      a'''1 |
      a'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'''4 e'''4 fis'''2 |
      fis'''2^\markup { \tiny \italic "Subject" } cis''''4 b'''4 |
      a'''2 d''''4 cis''''4 |
      gis'''2 fis'''2 |
      a'''4.^\markup { \tiny \italic "Countersubject" } gis'''16 a'''16 b'''4 a'''4 |
      cis''''2~ cis''''8 b'''16 cis''''16 bis'''4 |
      b'''4. a'''16 b'''16 a'''2 |
      a'''1~ |
      a'''8 gis'''8 fis'''4 cis'''4 gis''4 |
      a''2 b''4 gis'''4~ |
      gis'''2 a'''4. gis'''8 |
      fis'''2 cis'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'''4 fis''4 cis'''2~ |
      cis'''4 a'''2. |
      d'''2 a'''2 |
      d''''4 fis'''2.~ |
      fis'''4 b''2. |
      fis'''4 b'''2. |
      fis'''2. cis'''4~ |
      cis'''4 a'''2. |
      cis'''4 fis''4 cis'''2~ |
      cis'''4 a'''2. |
      d'''4 a''2. |
      d'''4 fis'''2. |
      b''4 d'''2.~ |
      d'''4 fis''2. |
      b''2. gis'''4~ |
      gis'''2. gis''4~ |
      gis''2 gis'''2~ |
      gis'''4 gis''2.~ |
      gis''1~ |
      gis''1~ |
      gis''2. gis'''4 |
      cis'''1 |
      fis''4 cis'''2. |
      fis'''2 a''2 |
      d'''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''2^\markup { \tiny \italic "Subject" } cis''''4 b'''4 |
      a'''2 d''''4 cis''''4 |
      gis'''2 fis'''2 |
      a''4.^\markup { \tiny \italic "Countersubject" } gis''16 a''16 b''4 a''4 |
      cis'''2~ cis'''8 b''16 cis'''16 bis''4 |
      b''4. a''16 b''16 a''2 |
      fis'''8 gis'''8 a'''4 gis'''2 |
      fis'''4 cis'''4 b''4 cis'''4 |
      gis'''2 a'''2 |
      d''''2. fis'''4 |
      cis'''4. b''8 a''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''2 cis'''2~ |
      cis'''4 fis''4 cis'''4 fis'''4~ |
      fis'''2 d'''2~ |
      d'''4 a'''2 d'''4~ |
      d'''2 fis''4 d'''4~ |
      d'''2 b''4 fis'''4~ |
      fis'''2 cis'''2~ |
      cis'''4 fis''4 cis'''4 fis'''4 |
      fis'''2 cis'''4 fis''4~ |
      fis''4 a''2 fis'''4~ |
      fis'''2 a''2~ |
      a''4 d'''4 a''4 fis'''4~ |
      fis'''2 b''2~ |
      b''4 fis''2 d'''4~ |
      d'''2 d''4 b''4~ |
      b''2 gis'''2 |
      gis''2. gis'''4~ |
      gis'''2 gis''2~ |
      gis''1~ |
      gis''4 cis''4 cis'''2~ |
      cis'''4 cis''''4 cis'''2~ |
      cis'''2 fis''4 cis'''4~ |
      cis'''2 a''2~ |
      a''4 fis'''4 d'''2~ |
      d'''4 fis'''4 d'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      cis'''2^\markup { \tiny \italic "Real answer" } gis'''4 fis'''4 |
      e'''2 a'''4 gis'''4 |
      dis'''2 cis'''2 |
      d'''4.^\markup { \tiny \italic "Countersubject" } cis'''16 d'''16 e'''4 d'''4 |
      fis'''2~ fis'''8 e'''16 fis'''16 eis'''4 |
      e'''4. d'''16 e'''16 d'''2 |
      a''2 gis''4 cis'''4~ |
      cis'''2 fis''4 dis''8 e''8 |
      fis''4. gis''8 a''8 b''8 cis'''4 |
      fis'''2 e'''4 b''4 |
      cis'''2 b''4 gis''8 a''8 |
      b''2 d'''8 e'''8 fis'''4 |
      d'''2~ d'''8 cis'''8 b''4 |
      gis''2 fis''8 gis''8 a''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''4 gis''4 cis'''8 b''8 a''4~ |
      a''4 fis''4 gis''4 fis''4~ |
      fis''8 gis''8 a''4 b''8 a''8 gis''4~ |
      gis''4 b''4. cis'''8 d'''4 |
      cis'''8 b''8 a''4 gis''4 a''4 |
      e''8 dis''8 cis''4 fis''4 dis'''4~ |
      dis'''8 e'''8 fis'''8 gis'''8 a'''4 e'''4 |
      a'''8 gis'''8 fis'''2 cis'''4 |
      fis''8 gis''8 a''4 e''8 fis''8 gis''4 |
      fis''8 gis''8 a''4 fis''4 cis'''8 d'''8 |
      e'''4 b''4 fis''8 gis''8 a''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''8 b''8 cis'''4 a''4 e'''4~ |
      e'''4 g''4 fis''4 b''4~ |
      b''4 g''4 d'''4 fis''4~ |
      fis''2 b''8 a''8 g''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''8 b''8 cis'''2 fis''4~ |
      fis''4 cis''4 fis''4 cis'''4 |
      gis'''8 fis'''8 e'''4 a''2~ |
      a''4 d'''2~ d'''8 e'''8 |
      fis'''2 b''4 d''4~ |
      d''4 a''2 d'''4 |
      r1 |
      fis'''4 cis'''2 fis'''4~ |
      fis'''4 cis'''4 a''2 |
      d'''8 e'''8 fis'''2 d'''4 |
      a''2. d'''4 |
      fis'''2 d'''2~ |
      d'''4 b''2 fis''4~ |
      fis''4 cis'''2. |
      a''2. cis'''4 |
      cis'''4 fis'''2 cis'''4~ |
      cis'''4 fis''4 a''2~ |
      a''4 d'''2 a''4~ |
      a''2 fis''2~ |
      fis''4 d'''2 fis'''4 |
      b''4 d'''4 b''2~ |
      b''4 d'''2. |
      d''2. b''4~ |
      b''2. b'4~ |
      b'4 gis''2.~ |
      gis''4 gis'''2 gis''4~ |
      gis''2. gis'''4~ |
      gis'''4 cis'''2. |
      cis''2. fis''4~ |
      fis''4 a''2.~ |
      a''4 d'''4 a''2~ |
      a''4 d'''2 a''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'''2^\markup { \tiny \italic "Real answer" } gis'''4 fis'''4 |
      e'''2 a'''4 gis'''4 |
      dis'''2 cis'''2 |
      b''2 a''2 |
      d''4.^\markup { \tiny \italic "Countersubject" } cis''16 d''16 e''4 d''4 |
      fis''2~ fis''8 e''16 fis''16 eis''4 |
      e''4. d''16 e''16 d''2 |
      e''2. a''4~ |
      a''8 gis''4. fis''4 gis''4~ |
      gis''8 fis''4. e''2 |
      fis''2~ fis''8 gis''8 a''4~ |
      a''2. gis''4 |
      cis''4 fis''4 b''4 cis'''4~ |
      cis'''8 b''8 e''4 fis''2 |
      fis''2 eis''4 fis''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''4 a''8 b''8 cis'''4 fis''4~ |
      fis''4 d''4 fis'4 cis''4 |
      gis''8 fis''8 e''4 a''4 d'''4 |
      a''2 gis''4 dis''4 |
      gis'2 fis'4 dis''4~ |
      dis''8 cis''8 b'4 e''4 a''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''8 gis''8 fis''4 a''4 d'''4 |
      a''4. gis''8 fis''4 a''4 |
      b''2 fis''4 a''4 |
      fis''8 e''8 d''4 fis''4 d''4~ |
      d''4 fis''4 e''8 fis''8 gis''4 |
      b''4 a''4 fis''2 |
      r1 |
      a''8 gis''8 fis''4 a''4 cis'''4~ |
      cis'''4 a''4 fis''2~ |
      fis''4 a''2 fis''4~ |
      fis''4 a''4 fis''4 d''4~ |
      d''4 fis''4 b''4 fis''4~ |
      fis''4 d''4 fis''2 |
      a''4 fis''4 a''4 cis'''4~ |
      cis'''4 a''4 fis''2 |
      a''2. cis'''4~ |
      cis'''4 a''4 fis''2~ |
      fis''2 d''4 fis''4~ |
      fis''4 a''2 d''4~ |
      d''4 fis''4 b''4 fis''4~ |
      fis''4 b''4 fis''4 b''4~ |
      b''2 gis''2~ |
      gis''4 gis'2 b'4~ |
      b'2 gis''2~ |
      gis''4 b'4 gis''2~ |
      gis''2 cis''2~ |
      cis''4 gis''4 cis''4 gis''4~ |
      gis''2 cis''2~ |
      cis''4 a''4 fis''4 cis''4~ |
      cis''4 fis''4 cis'''4 fis''4~ |
      fis''4 a''4 fis''4 a''4~ |
      a''4 d''4 fis''4 d''4 |
      b'4 fis''4 e''4 fis''4~ |
      fis''4 cis''4 fis''4 cis'''4 |
      e''4 b'4 fis''2 |
      fis''4 b'4 gis''4 cis'''4~ |
      cis'''4 a''4 fis''2~ |
      fis''4 cis''4 fis''4 a''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis''2^\markup { \tiny \italic "Real answer" } gis''4 fis''4 |
      e''2 a''4 gis''4 |
      dis''2 cis''2 |
      d''4.^\markup { \tiny \italic "Countersubject" } cis''16 d''16 e''4 d''4 |
      fis''2~ fis''8 e''16 fis''16 eis''4 |
      e''4. d''16 e''16 d''2 |
      e''2 dis''2 |
      cis''2. dis''4~ |
      dis''8 e''8 fis''4 e''2 |
      fis''2 e''4 b'4 |
      fis'8 gis'8 a'4 fis''4 cis''4 |
      b'4 e'4 fis'8 gis'8 a'4 |
      fis'2 b'8 cis''8 d''4 |
      cis''4 eis''4 fis''2 |
      a'1 |
      b'2^\markup { \tiny \italic "Related-key subject" } fis''4 e''4 |
      d''2 g''4 fis''4 |
      cis''2 b'2 |
      d''2 e''2 |
      cis''2 d''2 |
      cis''2 dis''4 cis''8 dis''8 |
      e''2. dis''4~ |
      dis''2 fis'8 gis'8 a'4 |
      cis''4. d''8 e''4 d''4 |
      a''4 e''4 fis''4 cis''4 |
      b'2 a'4 cis''4 |
      fis''2 d''4 fis''4 |
      d''4 a'4 b'8 cis''8 d''4 |
      b'8 cis''8 d''4 fis''4 a''4 |
      r1 |
      cis''2 fis''4 cis''4 |
      fis''4. gis''8 a''4 fis''4 |
      d''2~ d''8 e''8 fis''4 |
      d''4. e''8 fis''4 a''4 |
      d''2 fis''4 d''4 |
      fis''2 d''4 b'4 |
      a'2 cis''4 a'4 |
      cis''2 fis''4 cis''4 |
      a''4 cis'''4 a''4 cis''4 |
      a'4 fis'4 cis''2 |
      a''2 a'4 d''4 |
      a'2 a''4 a'4 |
      fis''1 |
      d''4 d'''4 fis''2 |
      b'2 d''4 b'4 |
      gis'2. gis''4~ |
      gis''2. b''4~ |
      b''1 |
      gis''1~ |
      gis''2 eis''2 |
      gis'2 gis''4 eis''4 |
      fis''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      cis'''2 cis''4 cis'''4 |
      fis''4 a'2 d''4 |
      a'2. a''4 |
      d''4 b'4 e''4 b'4 |
      cis''2 a'4 gis'4 |
      e'2 a'4 d''4 |
      fis''2 cis''2 |
      fis''2 a''4 fis''4 |
      cis''4 a'4 cis''4 a'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key fis \minor \time 4/4
      fis''2^\markup { \tiny \italic "Subject" } cis'''4 b''4 |
      a''2 d'''4 cis'''4 |
      gis''2 fis''2 |
      a'4.^\markup { \tiny \italic "Countersubject" } gis'16 a'16 b'4 a'4 |
      cis''2~ cis''8 b'16 cis''16 bis'4 |
      b'4. a'16 b'16 a'2 |
      b'2 a'4 b'8 cis''8 |
      d''4. cis''8 b'4 cis''4~ |
      cis''2 d''2~ |
      d''8 cis''4. b'4 cis''4~ |
      cis''2. dis''4~ |
      dis''2 e''2 |
      a'2 gis'2 |
      a'8 b'8 cis''4 fis''4 cis''4 |
      gis''8 fis''8 e''4 a'2 |
      d'2 d''2 |
      cis''4 gis'4 cis'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'2 cis''2 |
      a'4 b'4 e''4 fis''4 |
      d''4 cis''4 b'4 gis''4 |
      e''2 fis''2 |
      e''8 dis''8 cis''4 b'4 fis'4 |
      gis'2 cis''4 dis''4 |
      b'8 cis''8 dis''4 e''4. dis''8 |
      cis''2 a'4 cis''4 |
      d''2 cis''4 d''4~ |
      d''8 cis''4. b'4 gis'4 |
      b'2 d''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''2 e''4 fis''4 |
      d''2 fis''4 cis''4 |
      b'2 a'4. b'8 |
      cis''2 b'4 fis'4 |
      gis'4 cis''4 fis''4 gis''4 |
      fis''2 cis''4. b'8 |
      a'8 gis'8 fis'4 gis'4 b'4 |
      cis''2 fis'4 cis''8 d''8 |
      e''2 a'2 |
      r1 |
      r1 |
      e''4. d''8 cis''2 |
      b'2 cis''8 d''8 e''4 |
      b'4 d''8 cis''8 b'4 cis''4 |
      a'2 b'2 |
      b'8 a'8 g'4 e'2 |
      fis'2 d''2 |
      fis''4 e''4 b'4 cis''4~ |
      cis''4 e''8 dis''8 cis''4 dis''4 |
      b'8 cis''8 dis''4 fis''2 |
      cis''2 a'4 b'4 |
      cis''2 d''4 e''4~ |
      e''2 cis''2 |
      a'4 b'4 d''2 |
      a'8 b'8 cis''4 b'2 |
      fis'8 gis'8 a'4 d''2 |
      r1 |
      cis''4. b'8 a'2 |
      fis'8 gis'8 a'4 cis''2 |
      a'4. gis'8 fis'2 |
      a'2 d''2 |
      b'4 d''4 b'4 d''4 |
      b'2 d''2 |
      cis''2 a'2 |
      fis'2 a'2 |
      a'4 fis'4 a'4 fis'4 |
      a'2 cis''4 a'4 |
      fis'2 a'4 fis'4 |
      a'2 d''2 |
      fis''2 d''2 |
      b'2 d''4 b'4 |
      d''2 b'2 |
      d''4 b'4 d''4 b'4~ |
      b'2 gis'2 |
      b'2 gis'2~ |
      gis'4 cis''2 gis'4~ |
      gis'4 cis''2. |
      gis'2 cis''2~ |
      cis''4 fis'4 a'4 cis''4 |
      a'2 fis'2 |
      a'2 d''4 fis''4 |
      d''2 a'2 |
      b'2 gis'4 b'4 |
      fis'2 a'4 cis''4 |
      b'2 d''2 |
      d''4 b'4 gis'2 |
      fis'4 a'4 cis''2 |
      a'4 cis''4 a'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2^\markup { \tiny \italic "Subject" } cis''4 b'4 |
      a'2 d''4 cis''4 |
      gis'2 fis'2 |
      a'4.^\markup { \tiny \italic "Countersubject" } gis'16 a'16 b'4 a'4 |
      cis''2~ cis''8 b'16 cis''16 bis'4 |
      b'4. a'16 b'16 a'2 |
      b'8 a'8 gis'4 fis'2~ |
      fis'4 b'4 e'4 b8 cis'8 |
      d'8 e'8 fis'4 b'4 cis''4~ |
      cis''4 gis'4 b2 |
      cis'4 e'4 b'4 cis''4~ |
      cis''4 e''4 fis''4 dis''4~ |
      dis''8 cis''8 b'4 cis''2 |
      cis''2 a''4 fis''4~ |
      fis''2 e''4 b'4 |
      fis''2. cis''4 |
      e'2 a'2 |
      a'4 b'4 gis'4 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2 gis'4 b'4 |
      fis'8 gis'8 a'4 b'4 gis'4~ |
      gis'2 a'8 gis'8 fis'4 |
      a'4 e'8 fis'8 gis'4 a'4 |
      gis'2 cis''4 gis'4 |
      b'2 cis''8 b'8 a'4 |
      a'4. b'8 cis''4 d''4 |
      a'4. gis'8 fis'4 gis'4 |
      b'2 fis''8 e''8 d''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'2 g'4 b'4 |
      fis'2 b'4 fis'8 g'8 |
      a'8 b'8 cis''4 b'4 fis'4 |
      cis'4. dis'8 e'4 gis'4 |
      b'2 cis''4 a'4 |
      a''4 cis''4 cis'4 fis'4~ |
      fis'4 a'2. |
      e'2 a'4 a''4~ |
      a''4 d''2.~ |
      d''4 a''4 e''4 b'4 |
      d'1 |
      r1 |
      cis''1 |
      a'1~ |
      a'1~ |
      a'4 d''2. |
      fis'2. fis''4~ |
      fis''1 |
      cis''4 a'2. |
      a2 cis'2 |
      fis'4 a'4 fis'4 a'4 |
      fis'2 cis'4 fis'4 |
      a'2 fis'4 a'4 |
      fis'2 a'4 fis'4~ |
      fis'4 b'4 d''4 b'4 |
      fis'2 b'4 d''4 |
      b'4 gis'4 b'4 d''4 |
      b'2 gis'2 |
      b'4 gis'4 b'2 |
      gis'2 b'4 gis'4~ |
      gis'2 cis''2 |
      gis'2 cis''4 gis'4 |
      cis''2 gis'4 cis''4~ |
      cis''2 a'4 fis'4 |
      a'2 cis''4 a'4 |
      fis'2 a'4 fis'4 |
      a'2 fis'4 a'4 |
      fis'2^\markup { \tiny \italic "Subject" } cis''4 b'4 |
      a'2 d''4 cis''4 |
      gis'2 fis'2 |
      fis'2^\markup { \tiny \italic "Final cadence" } eis'4 gis'4 |
      a'1 |
      a'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2^\markup { \tiny \italic "Subject" } cis''4 b'4 |
      a'2 d''4 cis''4 |
      gis'2 fis'2 |
      a4.^\markup { \tiny \italic "Countersubject" } gis16 a16 b4 a4 |
      cis'2~ cis'8 b16 cis'16 bis4 |
      b4. a16 b16 a2 |
      b8 cis'8 d'4 cis'4 d'4~ |
      d'2 b4 cis'8 d'8 |
      e'2 fis'2 |
      e'8 dis'8 cis'4 dis'2 |
      e'2 fis'4 dis'4 |
      fis'8 e'8 dis'4 e'2 |
      a2 e4 gis4 |
      a2 b4 gis4~ |
      gis4 b4 d'2 |
      fis8 gis8 a4 b2 |
      gis'4 cis'4. b8 a8 b8 |
      cis'8 d'8 e'4 fis'4 e'4 |
      g'8 a'8 b'4 a'4 e'4 |
      fis'8 e'8 d'2 fis'4 |
      a'8 g'8 fis'4 d'8 cis'8 b4 |
      b8 cis'8 d'4 b2 |
      fis'2~ fis'8 e'8 d'4 |
      a4 e'4 gis'4 cis''4 |
      e'8 dis'8 cis'2 gis'4~ |
      gis'4 fis'8 gis'8 a'4 fis'4 |
      fis'4 cis'2 d'4 |
      fis'4 e'4 d'4 a4 |
      gis8 a8 b4 cis'4 fis'4 |
      a'8 gis'8 fis'2 a'4 |
      fis'4 cis'4 e'4 d'4 |
      fis'4 d'2 fis'4 |
      r1 |
      fis'4 a'2 fis'4 |
      a'8 gis'8 fis'2 a'4 |
      fis'4 d'4 fis'4 a'4 |
      fis'8 e'8 d'2 fis'4 |
      d'4 b4 d'4 fis'4 |
      d'4 fis'2 d'4 |
      fis'4 a'2 fis'4 |
      a'4 fis'2 a'4 |
      a'4 cis'2 fis'4 |
      cis'4 fis'2 a'4~ |
      a'4 d'4 fis'4 d'4 |
      fis'4 d'2 fis'4~ |
      fis'4 d'4 fis'4 d'4~ |
      d'4 fis'2 d'4~ |
      d'4 b4 gis'4 b'4~ |
      b'4 gis'2. |
      b2. gis4~ |
      gis4 b2 gis'4~ |
      gis'4 cis'2 gis'4 |
      cis''4 gis'2 cis'4~ |
      cis'4 gis'2 cis'4~ |
      cis'4 fis'2 a'4 |
      fis'4 cis'4 fis'4 a'4~ |
      a'4 fis'2 d'4 |
      fis'4 d'2 fis'4 |
      d'4 fis'4 gis'4 fis'4 |
      a'4 fis'2 cis'4 |
      e'2 fis'4 a'4 |
      d'4 fis'4 gis'2 |
      cis'4 fis'2 a'4 |
      fis'4 a'2 fis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "treble" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'2^\markup { \tiny \italic "Real answer" } gis'4 fis'4 |
      e'2 a'4 gis'4 |
      dis'2 cis'2 |
      d'4.^\markup { \tiny \italic "Countersubject" } cis'16 d'16 e'4 d'4 |
      fis'2~ fis'8 e'16 fis'16 eis'4 |
      e'4. d'16 e'16 d'2 |
      d'2 fis2 |
      cis1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 e'4 gis'4 cis''4 |
      gis'4 cis''2 gis'4 |
      b'4 fis'4 cis'4 e'4 |
      a4 cis'2 a4 |
      d'4 a2 d'4 |
      a8 gis8 fis2 gis4~ |
      gis4 b4 fis'8 e'8 d'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'8 e'8 fis'4 cis'4 fis'4 |
      a'8 gis'8 fis'4 b4 gis'4~ |
      gis'4 b'4 fis'4 a'4 |
      cis'8 dis'8 e'4 b4 dis'4 |
      gis'8 fis'8 e'4 cis'4 gis'4 |
      b4 fis4 a4 cis'4 |
      fis'2 cis'4 gis4 |
      cis'4 fis4 b4 gis'4~ |
      gis'4 e'4 a'8 gis'8 fis'4 |
      r1 |
      r1 |
      cis'4 a2 cis'4 |
      e'4 d'4 cis'4 b4 |
      fis4 g8 a8 b4 fis'4~ |
      fis'4 cis'4 d'4 g'4 |
      d'8 cis'8 b2 e4 |
      cis'4 fis'2 b'4 |
      fis'4 cis''4 gis'4 cis'4~ |
      cis'4 a4 e'4 gis4 |
      dis'4 b4 fis'4 cis'4 |
      cis'4 a2 fis4 |
      a8 b8 cis'4 a4 e'4 |
      b8 a8 gis4 cis'4 a4 |
      cis'4 d'2 a4~ |
      a4 fis4 b2 |
      d'8 e'8 fis'2 d'4 |
      r1 |
      a4 cis'2 a4~ |
      a4 cis'2 a4~ |
      a4 fis4 a4 d'4~ |
      d'4 fis'4 a'4 fis'4~ |
      fis'4 d'2 b4~ |
      b4 d'2 fis'4~ |
      fis'4 cis'2 fis'4~ |
      fis'4 a'2 fis'4 |
      fis'4 cis'2 a4~ |
      a4 cis'2 fis4~ |
      fis4 a4 d'2~ |
      d'4 a2 d'4~ |
      d'4 b2 d'4 |
      fis'4 d'4 fis'4 b4~ |
      b2. gis4~ |
      gis4 b2 gis'4~ |
      gis'4 b'2.~ |
      b'4 gis'2. |
      gis2. cis'4~ |
      cis'2 gis2~ |
      gis4 cis'2.~ |
      cis'2. a4~ |
      a4 cis'2 fis'4~ |
      fis'4 d'2 a4~ |
      a4 fis4 a4 d'4 |
      fis'4 d'4 cis'4 fis'4~ |
      fis'4 a'2 cis'4 |
      gis'4 b'4 fis'4 d'4 |
      b4 fis4 cis'4 gis4 |
      cis'2. a4~ |
      a4 fis4 a4 cis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'2^\markup { \tiny \italic "Real answer" } gis'4 fis'4 |
      e'2 a'4 gis'4 |
      dis'2 cis'2 |
      a2 fis2 |
      d4.^\markup { \tiny \italic "Countersubject" } cis16 d16 e4 d4 |
      fis2~ fis8 e16 fis16 eis4 |
      e4. d16 e16 d2 |
      d2 cis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'1 |
      e4 b4 fis4 b,4 |
      d4 b4 d'4 cis'4~ |
      cis'4 a4 d2 |
      g4 b4 e'4 b4 |
      cis'4 fis2. |
      fis8 gis8 a4 gis4 a4 |
      gis4 a4 cis'4 gis4~ |
      gis4 b4 fis2 |
      fis4 a4 e4 fis4 |
      cis'4 a4. b8 cis'4 |
      e'4 gis4 a4 fis4 |
      cis4 fis4 a4 fis4~ |
      fis4 a4 gis2 |
      b,4 fis4 a4 fis4 |
      r1 |
      cis'4 a4 fis2 |
      cis4 fis2. |
      a4 d'2 a4~ |
      a4 fis2. |
      b4 fis2 b4 |
      fis2. b4 |
      cis'4 fis2 a4~ |
      a4 cis'2 a4 |
      cis'4 a4 cis'4 a'4~ |
      a'2. fis'4~ |
      fis'4 d'2 a'4~ |
      a'4 fis'4 d'4 fis4 |
      d4 d'4 b2~ |
      b1 |
      gis1 |
      b4 d'2. |
      b2. gis'4 |
      eis'2 gis2~ |
      gis4 eis'2. |
      cis'2 gis'2 |
      cis'2 eis4 cis'4~ |
      cis'4 a2 cis4~ |
      cis4 a,2. |
      a1 |
      fis4 a2 fis4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis2^\markup { \tiny \italic "Real answer" } gis4 fis4 |
      e2 a4 gis4 |
      dis2 cis2 |
      d4.^\markup { \tiny \italic "Countersubject" } cis16 d16 e4 d4 |
      fis2~ fis8 e16 fis16 eis4 |
      e4. d16 e16 d2 |
      fis2 fis'2 |
      eis'4 gis4 fis4 cis4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis4 fis4 e4 b4 |
      fis4 a,4 a4 e4~ |
      e4 b,4 fis2~ |
      fis4 b4 fis2 |
      a4 cis4 gis4 b,4 |
      fis2 d2 |
      r1 |
      cis4 fis2 a4 |
      cis2 fis2 |
      d'4 a2. |
      d2 a2 |
      fis4 b4 fis2 |
      b,4 fis,4 b,4 d4 |
      a2 fis2 |
      cis4 fis4 cis2 |
      cis2 fis2~ |
      fis4 cis4 fis2~ |
      fis4 d'4 a2 |
      d2 fis2~ |
      fis4 b,2. |
      d4 b,2.~ |
      b,4 gis2. |
      gis,2 b,2~ |
      b,4 gis2. |
      gis,1 |
      gis1 |
      cis1 |
      cis'2. cis4~ |
      cis2 a2~ |
      a4 fis4 a2~ |
      a4 d4 fis2 |
      d'4 a2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis2^\markup { \tiny \italic "Subject" } cis'4 b4 |
      a2 d'4 cis'4 |
      gis2 fis2 |
      fis,2 b,2 |
      cis4. b,8 a,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,2 cis2 |
      fis,4 cis2. |
      fis,2 d2 |
      fis2 d4 a,4 |
      b,2 fis2 |
      b2 fis2 |
      a,2 fis2~ |
      fis4 cis2. |
      a,2 fis2 |
      a,2. cis4 |
      d4 fis2. |
      d2. a,4 |
      b,2 fis,2 |
      b,2. fis,4 |
      gis,4 b,2. |
      gis2 b,2 |
      gis1 |
      b,1 |
      cis2 gis2~ |
      gis2 gis,2~ |
      gis,4 gis2. |
      fis2 cis2 |
      fis2 cis2 |
      d4 fis2. |
      a,2 d2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,1 |
      fis,2^\markup { \tiny \italic "Subject" } cis4 b,4 |
      a,2 d4 cis4 |
      gis,2 fis,2 |
      fis,4 b,4 cis8 b,8 a,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,4 cis2. |
      a4 cis2. |
      fis4 a,4 d2 |
      fis,2 d2~ |
      d4 fis,2. |
      d4 fis,4 d2 |
      fis,2 cis2 |
      fis,4 cis2. |
      cis2 fis,2~ |
      fis,4 cis2. |
      fis,2 d2~ |
      d4 fis,2. |
      b,4 fis,2. |
      d2. fis,4 |
      d,2 b,2~ |
      b,4 d,4 b,2~ |
      b,4 b,,2. |
      gis,1 |
      cis,1 |
      cis1 |
      cis,1 |
      a,4 cis4 fis2 |
      cis4 fis,2. |
      d4 a,2. |
      d,4 a,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key fis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,2^\markup { \tiny \italic "Subject" } cis4 b,4 |
      a,2 d4 cis4 |
      gis,2 fis,2 |
      fis,8 e,8 d,4 b,,2 |
      cis,2 fis,,2 |
      cis,2 fis,4 a,4 |
      g,4.^\markup { \tiny \italic "Countersubject" } fis,16 g,16 a,4 g,4 |
      b,2~ b,8 a,16 b,16 ais,4 |
      a,4. g,16 a,16 g,2 |
      b,2 g,2 |
      fis,4. e,8 d,2 |
      a,4.^\markup { \tiny \italic "Countersubject" } gis,16 a,16 b,4 a,4 |
      cis2~ cis8 b,16 cis16 bis,4 |
      b,4. a,16 b,16 a,2 |
      fis,2^\markup { \tiny \italic "Stretto subject" } cis4 b,4 |
      a,2 d4 cis4 |
      gis,2 fis,2 |
      fis,4 b,,4 fis,2~ |
      fis,2 gis,4 b,4~ |
      b,4 fis,2. |
      r1 |
      fis,1~ |
      fis,1~ |
      fis,1~ |
      fis,1 |
      b,,1~ |
      b,,1 |
      fis,1~ |
      fis,1 |
      fis,1~ |
      fis,1 |
      d,1~ |
      d,1 |
      b,,1~ |
      b,,1~ |
      b,,1~ |
      b,,1 |
      gis,,1~ |
      gis,,1 |
      cis,1~ |
      cis,1~ |
      cis,1 |
      fis,1~ |
      fis,1 |
      d,1~ |
      d,1 |
      d,4.^\markup { \tiny \italic "Countersubject" } cis,16 d,16 e,4 d,4 |
      fis,2~ fis,8 e,16 fis,16 eis,4 |
      e,4. d,16 e,16 d,2 |
      d,2^\markup { \tiny \italic "Final cadence" } cis,4 eis,4 |
      fis,1 |
      fis,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
