\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "X. Prelude in E minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key e \minor \time 4/4
      \tempo "Andante, parlando" 4 = 82
      \mark \markup \box \small "Opening cell" e''8\p fis''8 g''4 r2 |
      e''8 b''8 g''4 r2 |
      a''8 b''8 c'''4 r2 |
      dis'''8 b''8 b''4 r2 |
      e''8 fis''8 g''4 r2 |
      c''8 g''8 e''4 r2 |
      fis''8 g''8 a''4 r2 |
      dis'''8 b''8 b''4 r2 |
      \mark \markup \box \small "Contrasting span" b''8\mp a''8 g''4 r2 |
      fis''8 d''8 d''4 r2 |
      e''8 d''8 c''4 r2 |
      g'8 d''8 b'4 r2 |
      c''8 b'8 a'4 r2 |
      g'8 e'8 e'4 r2 |
      ais'8 fis'8 fis'4 r2 |
      b'8 fis''8 dis''4 r2 |
      \mark \markup \box \small "Development" e''8\mf g''8 b''4 r4 g''8 b''8 |
      d''8 fis''8 a''4 r4 fis''8 a''8 |
      c''8 e''8 g''4 r4 e''8 g''8 |
      fis''8 b'8 b'4 r4 b'8 b'8 |
      g'8 b'8 d''4 r4 b'8 d''8 |
      c''8 e''8 g''4 r4 e''8 g''8 |
      a''8 c'''8 e'''4 r4 c'''8 e'''8 |
      fis'''8 b''8 b''4 r4 b''8 b''8 |
      \mark \markup \box \small "Return" e''8\mp fis''8 g''4 r2 |
      a''8 e'''8 c'''4 r2 |
      f''8 g''8 a''4 r2 |
      dis''8 b'8 b'4 r2 |
      \mark \markup \box \small "Cadence" e'8\p fis'8 g'4 r2 |
      a'8 e''8 c''4 r2 |
      b'8 fis''8 dis''4 r2 |
      e''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key e \minor \time 4/4
      r2 e'8 b'8 g'4 |
      r2 e'8 b'8 g'4 |
      r2 a'8 e''8 c''4 |
      r2 dis''8 b'8 b'4 |
      r2 e'8 b'8 g'4 |
      r2 c'8 g'8 e'4 |
      r2 fis'8 c''8 a'4 |
      r2 dis''8 b'8 b'4 |
      r2 b'8 g'8 g'4 |
      r2 fis'8 d'8 d'4 |
      r2 e'8 c'8 c'4 |
      r2 g8 d'8 b4 |
      r2 c'8 a8 a4 |
      r2 g8 e8 e4 |
      r2 ais8 fis8 fis4 |
      r2 b8 fis'8 dis'4 |
      r2 e'8 g'8 b'4 |
      r2 d'8 fis'8 a'4 |
      r2 c'8 e'8 g'4 |
      r2 fis'8 b8 b4 |
      r2 g8 b8 d'4 |
      r2 c'8 e'8 g'4 |
      r2 a'8 c''8 e''4 |
      r2 fis''8 b'8 b'4 |
      r2 e'8 b'8 g'4 |
      r2 a'8 e''8 c''4 |
      r2 f'8 c''8 a'4 |
      r2 dis'8 b8 b4 |
      r2 e8 b8 g4 |
      r2 a8 e'8 c'4 |
      r2 b8 fis'8 a'4 |
      g'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key e \minor \time 4/4
      e,1\p |
      g,1 |
      a,1 |
      b,1 |
      e,1 |
      c,2.~ c,8 b,,8 |
      a,,1 |
      b,,1 |
      g,,1\mp |
      d,1 |
      c,1 |
      g,1 |
      a,1 |
      g,1 |
      fis,1 |
      b,,1 |
      e,1\mf |
      d,1 |
      c,1 |
      b,,1 |
      g,,1 |
      c,2.~ c,8 b,,8 |
      a,,1 |
      b,,1 |
      e,1\mp |
      a,1 |
      a,1 |
      b,1 |
      g,1\p |
      a,1 |
      b,1 |
      e,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
