\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXIII. Prelude in B major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key b \major \time 12/8
      \tempo "Allegro luminoso" 4 = 112
      \mark \markup \box \small "Opening cell" b'16\p cis''16 dis''16 b''16 dis''16 fis''16 dis'''16 b''16 b'16 fis''16 dis''16 b''16 dis''16 fis''16 dis'''16 b''16 b'16 fis''16 dis''16 b''16 dis''16 fis''16 dis'''16 b''16 |
      dis''16 ais''16 fis''16 dis'''16 fis''16 ais''16 fis'''16 dis'''16 dis''16 ais''16 fis''16 dis'''16 fis''16 ais''16 fis'''16 dis'''16 dis''16 ais''16 fis''16 dis'''16 fis''16 ais''16 fis'''16 dis'''16 |
      gis''16 ais''16 b''16 gis'''16 b''16 dis'''16 b'''16 gis'''16 gis''16 dis'''16 b''16 gis'''16 b''16 dis'''16 b'''16 gis'''16 gis''16 dis'''16 b''16 gis'''16 b''16 dis'''16 b'''16 gis'''16 |
      gis'''16 e'''16 e''16 b''16 gis''16 e'''16 gis''16 b''16 gis'''16 e'''16 e''16 b''16 gis''16 e'''16 gis''16 b''16 gis'''16 e'''16 e''16 b''16 gis''16 e'''16 gis''16 b''16 |
      cis''16 dis''16 e''16 cis'''16 e''16 gis''16 e'''16 cis'''16 cis''16 gis''16 e''16 cis'''16 e''16 gis''16 e'''16 cis'''16 cis''16 gis''16 e''16 cis'''16 e''16 gis''16 e'''16 cis'''16 |
      cis''16 gis''16 eis''16 cis'''16 eis''16 gis''16 eis'''16 cis'''16 cis''16 gis''16 eis''16 cis'''16 eis''16 gis''16 eis'''16 cis'''16 cis''16 gis''16 eis''16 cis'''16 eis''16 gis''16 eis'''16 cis'''16 |
      ais''16 fis'''16 ais''16 cis'''16 ais'''16 fis'''16 fis''16 gis''16 ais''16 fis'''16 ais''16 cis'''16 ais'''16 fis'''16 fis''16 cis'''16 ais''16 fis'''16 ais''16 cis'''16 ais'''16 fis'''16 fis''16 cis'''16 |
      b''16 fis'''16 dis'''16 b'''16 dis'''16 fis'''16 dis''''16 b'''16 b''16 fis'''16 dis'''16 b'''16 dis'''16 fis'''16 dis''''16 b'''16 b''16 fis'''16 dis'''16 b'''16 dis'''16 fis'''16 dis''''16 b'''16 |
      \mark \markup \box \small "Contrasting span" b''16\mp gis'''16 b''16 dis'''16 b'''16 gis'''16 gis''16 ais''16 b''16 gis'''16 b''16 dis'''16 b'''16 gis'''16 gis''16 dis'''16 b''16 gis'''16 b''16 dis'''16 b'''16 gis'''16 gis''16 dis'''16 |
      fisis''16 dis'''16 fisis''16 ais''16 fisis'''16 dis'''16 dis''16 ais''16 fisis''16 dis'''16 fisis''16 ais''16 fisis'''16 dis'''16 dis''16 ais''16 fisis''16 dis'''16 fisis''16 ais''16 fisis'''16 dis'''16 dis''16 ais''16 |
      b'16 gis''16 b'16 dis''16 b''16 gis''16 gis'16 ais'16 b'16 gis''16 b'16 dis''16 b''16 gis''16 gis'16 dis''16 b'16 gis''16 b'16 dis''16 b''16 gis''16 gis'16 dis''16 |
      e''16 b''16 gis''16 e'''16 gis''16 b''16 gis'''16 e'''16 e''16 b''16 gis''16 e'''16 gis''16 b''16 gis'''16 e'''16 e''16 b''16 gis''16 e'''16 gis''16 b''16 gis'''16 e'''16 |
      dis'''16 fis'''16 ais''16 fis''16 dis'''16 fis''16 e''16 dis''16 dis'''16 fis'''16 ais''16 fis''16 dis'''16 fis''16 ais''16 dis''16 dis'''16 fis'''16 ais''16 fis''16 dis'''16 fis''16 ais''16 dis''16 |
      gis''16 b''16 dis''16 b'16 gis''16 b'16 dis''16 gis'16 gis''16 b''16 dis''16 b'16 gis''16 b'16 dis''16 gis'16 gis''16 b''16 dis''16 b'16 gis''16 b'16 dis''16 gis'16 |
      cis''16 e''16 gis'16 e'16 cis''16 e'16 dis'16 cis'16 cis''16 e''16 gis'16 e'16 cis''16 e'16 gis'16 cis'16 cis''16 e''16 gis'16 e'16 cis''16 e'16 gis'16 cis'16 |
      cis''16 fis'16 fis''16 ais''16 cis''16 ais'16 fis''16 ais'16 cis''16 fis'16 fis''16 ais''16 cis''16 ais'16 fis''16 ais'16 cis''16 fis'16 fis''16 ais''16 cis''16 ais'16 fis''16 ais'16 |
      \mark \markup \box \small "Return" b'16\mp dis''16 fis'16 dis'16 b'16 dis'16 cis'16 b16 b'16 dis''16 fis'16 dis'16 b'16 dis'16 fis'16 b16 b'16 dis''16 fis'16 dis'16 b'16 dis''16 fis''16 b''16 |
      e''16 gis''16 b'16 gis'16 e''16 gis'16 b'16 e'16 e''16 gis''16 b'16 gis'16 e''16 gis'16 b'16 e'16 e''16 gis''16 b'16 gis'16 e''16 gis'16 b'16 e'16 |
      e'16 b'16 g'16 e''16 g'16 b'16 g''16 e''16 e'16 fis'16 g'16 e''16 g'16 b'16 g''16 e''16 e'16 b'16 g'16 e''16 g'16 b'16 g''16 e''16 |
      dis''16 b'16 b16 fis'16 dis'16 b'16 dis'16 fis'16 dis''16 b'16 b16 fis'16 dis'16 b'16 dis'16 fis'16 dis''16 b'16 b16 fis'16 dis'16 b'16 dis'16 fis'16 |
      \mark \markup \box \small "Cadence" cis'16\p dis'16 e'16 cis''16 e'16 gis'16 e''16 cis''16 cis'16 gis'16 e'16 cis''16 e'16 gis'16 e''16 cis''16 cis'16 gis'16 e'16 cis''16 e'16 gis'16 e''16 cis''16 |
      b'16 fis''16 dis''16 b''16 dis''16 fis''16 dis'''16 b''16 b'16 fis''16 dis''16 b''16 dis''16 fis''16 dis'''16 b''16 b'16 fis''16 dis''16 b''16 dis''16 fis''16 dis'''16 b''16 |
      fis''16 cis'''16 ais''16 fis'''16 ais''16 cis'''16 ais'''16 fis'''16 fis''16 cis'''16 ais''16 fis'''16 ais''16 cis'''16 ais'''16 fis'''16 fis''16 cis'''16 ais''16 fis'''16 ais''16 cis'''16 ais'''16 ais'''16 |
      b'''1~ b'''2 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key b \major \time 12/8
      dis'2\p fis'2 dis'2 |
      fis'2 ais'2 fis'2 |
      b'2 b'2 gis'2 |
      b'2 gis'2 e'2 |
      e'2 gis'2 e'2 |
      eis'2 gis'2 eis'2 |
      cis'2 cis'2 cis'2 |
      dis'2 fis'2 dis'2 |
      b2\mp b2 gis2 |
      fisis2 ais2 fisis2 |
      b2 dis'2 b2 |
      gis2 b2 gis2 |
      fis2 ais2 fis2 |
      b2 b2 b2 |
      e'2 e'2 cis'2 |
      ais2 cis'2 ais2 |
      b2\mp dis'2 dis'2 |
      gis'2 gis'2 e'2 |
      b2 b2 b2 |
      dis'2 dis'2 b2 |
      gis2\p gis2 gis2 |
      b2 dis'2 b2 |
      ais2 ais2 fis2 |
      fis1~ fis2 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key b \major \time 12/8
      fis2.\p fis2. |
      ais2. ais2. |
      dis'2. b2. |
      b2. gis2. |
      gis2. e2. |
      gis2. gis2. |
      cis'2. cis'2. |
      dis'2. fis'2. |
      dis'2.\mp b2. |
      ais2. ais2. |
      dis'2. b2. |
      b2. gis2. |
      ais2. fis2. |
      dis2. b,2. |
      e2. e2. |
      cis2. cis2. |
      dis2.\mp fis2. |
      gis2. gis2. |
      b2. g2. |
      fis2. fis2. |
      gis2.\p e2. |
      fis2. dis2. |
      cis2. e2. |
      dis1~ dis2 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key b \major \time 12/8
      b,,4.\p b,,4. b,,4. b,,4. |
      dis,4. dis,4. dis,4. dis,4. |
      gis,4. gis,4. gis,4. gis,4 fis,8 |
      e,4. e,4. e,4. e,4. |
      e,4. e,4. e,4. e,4. |
      cis,4. cis,4. cis,4. cis,4. |
      fis,4. fis,4. fis,4. fis,4. |
      b,,4. b,,4. b,,4. b,,4. |
      gis,,4.\mp gis,,4. gis,,4. gis,,4. |
      dis,4. dis,4. dis,4. dis,4. |
      gis,4. gis,4. gis,4. gis,4 fis,8 |
      e,4. e,4. e,4. e,4. |
      dis,4. dis4. dis,4. dis4. |
      gis,4. gis4. gis,4. gis4. |
      e,4. e4. e,4. e4. |
      fis,4. fis4. fis,4. fis4. |
      b,,4.\mp b,4. b,,4. b,4. |
      e,4. e4. e,4. e4. |
      e,4. e,4. e,4. e,4. |
      dis,4. dis,4. dis,4. dis,4. |
      e,4.\p e,4. e,4. e,4. |
      fis,4. fis,4. fis,4. fis,4. |
      fis,4. fis,4. fis,4. fis,4. |
      b,,1~ b,,2 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
