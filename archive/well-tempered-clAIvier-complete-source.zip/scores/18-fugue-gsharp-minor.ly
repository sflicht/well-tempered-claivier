\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XVIII. Fugue in G# minor — The gathered dusk"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a2")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key gis \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 86
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4^\markup { \tiny \italic "Subject" } b''4 ais''2 |
      fis''4 gis''4 cis'''2 |
      b''2 gis''2 |
      b''4^\markup { \tiny \italic "Countersubject" } ais''4 gis''4. fis''16 gis''16 |
      ais''4 b''2~ b''8 ais''16 b''16 |
      ais''4. gis''16 ais''16 b''2 |
      gis''4 fis''2. |
      ais''4 gis''2~ gis''8 ais''8 |
      b''2.~ b''8 ais''8 |
      \mark \markup \box \small "Sequential episode" gis''2 fisis''4 gis''4 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4 dis''8 e''8 fis''4. e''8 |
      dis''4 gis''2. |
      dis''2 gis''2 |
      dis''4 ais'8 b'8 cis''2~ |
      cis''4 fis''8 eis''8 dis''4. eis''8 |
      fis''2 b''4. ais''8~ |
      ais''8 gis''4. cis''4 fis''4~ |
      fis''4 b'4 gis''2 |
      b'2 gis''2 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 4" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Development" fis''2 gis''2 |
      eis''4 dis''4 b''2 |
      fis''2 gis''2 |
      \mark \markup \box \small "Linking episode" b''4. ais''8 gis''2 |
      ais''2.~ ais''8 b''8 |
      \mark \markup \box \small "Development" cis'''4^\markup { \tiny \italic "Related-key subject" } e'''4 dis'''2 |
      b''4 cis'''4 fis'''2 |
      e'''2 cis'''2 |
      cis'''4 dis'''4 ais''2~ |
      ais''4 gis''2. |
      b''1 |
      \mark \markup \box \small "Stretto" b''4 gis''4 ais''2 |
      cis'''4 b''4 e''2 |
      gis''2 gis''4^\markup { \tiny \italic "Stretto subject" } b''4 |
      ais''2 fis''4 gis''4 |
      cis'''2 b''2 |
      gis''2 ais''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" dis'''1 |
      b''1 |
      e'''1~ |
      e'''4 b'''4 e'''2~ |
      e'''2. gis'''4 |
      e'''1 |
      dis'''2. b''4 |
      dis'''1 |
      \mark \markup \box \small "Final return" cis'''4 b''4 cis'''2 |
      b''2 cis'''2 |
      dis'''2 cis'''2 |
      \mark \markup \box \small "Final cadence" cis'''4 e''4 dis''4 fisis''4 |
      gis''1 |
      gis''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4^\markup { \tiny \italic "Subject" } b''4 ais''2 |
      fis''4 gis''4 cis'''2 |
      b''2 gis''2 |
      b''4^\markup { \tiny \italic "Countersubject" } ais''4 gis''4. fis''16 gis''16 |
      ais''4 b''2~ b''8 ais''16 b''16 |
      ais''4. gis''16 ais''16 b''2 |
      b''2 fis''2 |
      ais''4 gis''2. |
      dis''2 gis''2 |
      e'''2. gis''4~ |
      gis''8 fisis''4. gis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4 dis''4 ais'2 |
      dis''4 gis''2. |
      dis''4 gis''2. |
      b'4 fis''4 cis''2 |
      ais''4 dis''4 gis'4 eis''4 |
      cis''4 fis''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis'2 dis''2~ |
      dis''4 b''2. |
      e''2 b''2~ |
      b''4 gis'''4 b''2 |
      e''2 e'''2~ |
      e'''4 gis''2. |
      b'4 gis''2. |
      dis'''2 gis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4^\markup { \tiny \italic "Subject" } b''4 ais''2 |
      fis''4 gis''4 cis'''2 |
      b''2 gis''2 |
      b''4^\markup { \tiny \italic "Countersubject" } ais''4 gis''4. fis''16 gis''16 |
      ais''4 b''2~ b''8 ais''16 b''16 |
      ais''4. gis''16 ais''16 b''2 |
      gis''2 cis''4 fis''4 |
      ais''4 gis''2.~ |
      gis''1 |
      gis''8 ais''8 b''4 gis''2~ |
      gis''8 fisis''4. gis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e''4 b''4 fis''4 ais'4 |
      dis''4 gis'4 gis''2~ |
      gis''4 dis''4 gis''8 fis''8 e''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''2 dis''2~ |
      dis''4 gis'4 dis''4 b''4~ |
      b''2 e''2~ |
      e''4 gis'4 gis''2~ |
      gis''4 cis'''2 e''4~ |
      e''2 e'''4 gis''4~ |
      gis''2 b'2~ |
      b'4 gis''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4^\markup { \tiny \italic "Subject" } b''4 ais''2 |
      fis''4 gis''4 cis'''2 |
      b''2 gis''2 |
      b'4^\markup { \tiny \italic "Countersubject" } ais'4 gis'4. fis'16 gis'16 |
      ais'4 b'2~ b'8 ais'16 b'16 |
      ais'4. gis'16 ais'16 b'2 |
      b'4 cis''4 dis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''4 dis''2 gis'4~ |
      gis'4 dis''2 gis'4~ |
      gis'4 e''2 b''4~ |
      b''4 e''2. |
      cis'''4 gis''2 cis''4~ |
      cis''4 gis'2. |
      dis'4 gis'2 dis''4~ |
      dis''2. gis''4 |
      cis''4 fis''4 ais'2 |
      dis''4 gis''2 cis'''4 |
      fis''2 cis''4 gis'4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      dis''4^\markup { \tiny \italic "Real answer" } fis''4 eis''2 |
      cis''4 dis''4 gis''2 |
      fis''2 dis''2 |
      e''4^\markup { \tiny \italic "Countersubject" } dis''4 cis''4. b'16 cis''16 |
      dis''4 e''2~ e''8 dis''16 e''16 |
      dis''4. cis''16 dis''16 e''2 |
      fis''2 cis''2~ |
      cis''4 fis'4 b'8 cis''8 dis''4~ |
      dis''2 b'2 |
      b'2 cis''8 b'8 ais'4 |
      dis''4 gis'2.~ |
      gis'4 fis'4 gis'8 fis'8 e'4 |
      gis'2 dis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e''4 b'4 cis''8 b'8 ais'4~ |
      ais'4 b'8 ais'8 gis'4 cis''4 |
      dis''8 cis''8 b'4 e''8 dis''8 cis''4~ |
      cis''8 b'8 cis''8 dis''8 eis''8 dis''8 cis''4 |
      eis''4 dis''8 cis''8 b'8 cis''8 dis''4~ |
      dis''4 ais'4 dis''8 eis''8 fis''4 |
      e''4 b'4 cis''8 b'8 ais'4 |
      dis''4 gis''4 cis''8 dis''8 e''4 |
      b'4 fis'4 gis'8 ais'8 b'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e''4 b'4 cis''4 fis''8 e''8 |
      dis''4 b'4 cis''4 gis'4~ |
      gis'8 ais'8 b'4 e''8 fis''8 gis''4 |
      dis''4 ais'4 eis''8 dis''8 cis''4 |
      ais'4 fis'4 gis'8 fis'8 eis'4 |
      ais'8 b'8 cis''4 b'8 cis''8 dis''4 |
      b'2 fis'4 cis''4 |
      fis''4 b'4 e'4 gis'4~ |
      gis'4 dis'4 gis'4 b'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e''4 gis'4 dis''2 |
      gis'4 cis'2 fis'4 |
      b4 e'4 a'4 cis''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis''4 b'2 dis''4~ |
      dis''2 gis'2 |
      e''4 b'2 e''4~ |
      e''2. gis'4~ |
      gis'2 cis''2~ |
      cis''4 gis''4 cis''4 gis'4~ |
      gis'2 dis''2~ |
      dis''4 gis'2 dis'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis''4^\markup { \tiny \italic "Real answer" } fis''4 eis''2 |
      cis''4 dis''4 gis''2 |
      fis''2 dis''2 |
      e''4^\markup { \tiny \italic "Countersubject" } dis''4 cis''4. b'16 cis''16 |
      dis''4 e''2~ e''8 dis''16 e''16 |
      dis''4. cis''16 dis''16 e''2 |
      fis''4 cis''2. |
      ais'4 fis'4 gis'2 |
      ais'2 fis'2 |
      gis'4 dis''8 e''8 fis''2 |
      dis''4 b'4 cis''2 |
      fis'4 b2. |
      b'4 e''8 dis''8 cis''4 gis'4 |
      dis''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4 fis'8 gis'8 ais'8 gis'8 fis'4 |
      ais'4 gis'8 fis'8 e'8 fis'8 gis'4 |
      b'8 ais'8 gis'4 b'8 ais'8 gis'4~ |
      gis'8 fis'4. gis'4 eis'4 |
      ais'4 dis''8 cis''8 b'8 ais'8 gis'4 |
      cis''2 dis''8 cis''8 b'4 |
      b'2 cis''4 fis'4~ |
      fis'4 b'8 ais'8 gis'4 cis''4 |
      gis'4. fis'8 e'4 gis'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis'4 dis'4 ais'8 gis'8 fis'4~ |
      fis'4 cis''4 gis'4 cis''4 |
      gis'2~ gis'8 ais'8 b'4 |
      dis'4 ais'4 eis'8 dis'8 cis'4 |
      ais'4 dis'2 gis'4 |
      dis'8 eis'8 fis'4 b'4 fis'4 |
      r1 |
      fis'2 b'4 gis'4 |
      cis''4 fis'4 gis'4 dis''4 |
      ais'4 fis'4 b'4 gis'4 |
      r1 |
      r1 |
      e'2 a'2 |
      gis'4 cis''4 a'4 fis'4 |
      b'2 fis'4 cis'4 |
      gis4 dis'4 ais'2 |
      dis''4 gis'2 cis''4 |
      fis'2 b'4 e''4 |
      dis''2 ais'4 cis''4~ |
      cis''4 gis'4 cis'4 gis'4~ |
      gis'2 b'2 |
      fis'2. cis''4~ |
      cis''2 e''4 gis'4~ |
      gis'4 b'4 fis''4 cis''4 |
      r1 |
      dis'2 gis'4 b'4~ |
      b'2 gis'2 |
      e'2 gis'4 e''4 |
      b'2. e''4 |
      cis''2 gis'4 cis''4 |
      gis'2 e'4 gis'4~ |
      gis'2 b'2~ |
      b'2 gis'4 b'4 |
      e'4 b'4 e''4 cis''4 |
      fis''4 b'4 e'2 |
      b'2 e'4 gis'4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis'4^\markup { \tiny \italic "Real answer" } fis'4 eis'2 |
      cis'4 dis'4 gis'2 |
      fis'2 dis'2 |
      e'4^\markup { \tiny \italic "Countersubject" } dis'4 cis'4. b16 cis'16 |
      dis'4 e'2~ e'8 dis'16 e'16 |
      dis'4. cis'16 dis'16 e'2 |
      dis'4 cis'8 dis'8 eis'4 gis'4 |
      eis'4 fis'4 eis'4 gis'4 |
      ais'2 fis'2 |
      e'8 fis'8 gis'4 ais'8 b'8 cis''4 |
      fis'4 e'4 gis'2 |
      b'2~ b'8 ais'8 gis'4 |
      b4 e'4 cis''4 gis'4 |
      ais'4 dis'2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4 fis'4 cis'2 |
      fis'4 cis'4 gis'4. ais'8 |
      b'2 e'2 |
      b'4 dis'4 gis'8 fis'8 eis'4 |
      ais'4 fis'4 gis'4 b'4 |
      fis'8 gis'8 ais'4 fis'2 |
      r1 |
      dis'4^\markup { \tiny \italic "Related-key subject" } fis'4 eis'2 |
      cis'4 dis'4 gis'2 |
      fis'2 dis'2 |
      fis'4. eis'8 dis'2 |
      cisis'2 dis'8 eis'8 fis'4 |
      e'4 b4 dis'2 |
      e'4 a'4 fis'2 |
      gis'2 fis'4 e'4 |
      gis'4^\markup { \tiny \italic "Related-key subject" } b'4 ais'2 |
      fis'4 gis'4 cis''2 |
      b'2 gis'2 |
      gis'2 cis'2 |
      fis'4 b'4 e''2 |
      b'4 gis'2. |
      fis'2. e'4~ |
      e'2 b2 |
      gis'2 cis''2 |
      r1 |
      b'2 gis'4 dis'4 |
      gis'2 dis'4 gis'4~ |
      gis'2 e'2 |
      gis'4 e'2 gis'4~ |
      gis'2 cis'2 |
      gis'2 cis''2 |
      gis'4 dis'2. |
      gis'2 b'2 |
      e''4 b'4 e'2 |
      b'4 gis'4 e'2 |
      b2 e'2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis'4^\markup { \tiny \italic "Real answer" } fis'4 eis'2 |
      cis'4 dis'4 gis'2 |
      fis'2 dis'2 |
      e'4^\markup { \tiny \italic "Countersubject" } dis'4 cis'4. b16 cis'16 |
      dis'4 e'2~ e'8 dis'16 e'16 |
      dis'4. cis'16 dis'16 e'2 |
      fis'2 cis'2~ |
      cis'4 b4. cis'8 dis'4 |
      fis'2~ fis'8 eis'8 dis'4 |
      gis'2 fisis'4 gis'4 |
      r1 |
      r1 |
      r1 |
      b4. cis'8 dis'4 gis4 |
      eis'2 ais'4 dis'4 |
      r1 |
      r1 |
      r1 |
      gis'4 dis'4 e'4 cis'4 |
      fis4 cis'4 e'4 cis'4 |
      fis'2 gis'4 b'4 |
      gis'2 fis'2 |
      cis'4 gis'4 e'4 cis'4 |
      dis'2 gis'4 dis'4 |
      cis'2 b4 e'4 |
      gis'2 b'4 gis'4 |
      dis'2 ais4 cis'4 |
      r1 |
      gis'2 dis'4 gis'4 |
      dis'2 b4 dis'4 |
      e'4 gis'4 b'4 gis'4 |
      e'2 gis'4 e'4 |
      gis'4 e'4 cis'4 gis4 |
      cis'2 e'2 |
      gis'2 dis'4 gis'4 |
      dis'2 b4 dis'4 |
      e'4 fis'4 e'2 |
      b2 e'4 cis'4 |
      fis'4 dis'4 gis'4 e'4 |
      gis'2 dis''4 ais'4 |
      gis'2 dis'4 b4 |
      dis'2 b4 dis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key gis \minor \time 4/4
      gis4^\markup { \tiny \italic "Subject" } b4 ais2 |
      fis4 gis4 cis'2 |
      b2 gis2 |
      b4^\markup { \tiny \italic "Countersubject" } ais4 gis4. fis16 gis16 |
      ais4 b2~ b8 ais16 b16 |
      ais4. gis16 ais16 b2 |
      cis'4 dis'8 e'8 fis'2 |
      dis'4 cis'2. |
      dis'8 cis'8 b4 cis'2~ |
      cis'8 b8 cis'2~ cis'8 dis'8 |
      eis'4 fis'8 eis'8 dis'2~ |
      dis'4. eis'8 fis'2~ |
      fis'8 e'8 fis'2 ais4 |
      fis'4 e'8 dis'8 cis'4 gis4~ |
      gis8 ais8 b2. |
      b4 cis'4 dis'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'4 dis'4 fis'4 cis'4 |
      ais4 b8 ais8 gis4 cis'4 |
      dis'8 cis'8 b2 e'4 |
      b4 cis'2 gis4 |
      cis'4 b8 ais8 gis4 b4 |
      cis'8 b8 ais4 dis'4 fis'4 |
      b8 ais8 gis4 cis'4 ais4 |
      dis'4 gis4. fis8 e4 |
      gis8 ais8 b2 e'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'4 b4 cis'4 fis'4~ |
      fis'4 e'4. dis'8 cis'4 |
      dis'8 cis'8 b2 e'4 |
      b4 fis4 gis4 cis'4 |
      ais4 dis'4. cis'8 b4 |
      dis'2~ dis'8 eis'8 fis'4 |
      r1 |
      dis'4 cis'4 eis'4 gis'4 |
      cis'4 fis'4 b4 gis4 |
      ais4 cis'4 b4 dis'4 |
      b8 cis'8 dis'2. |
      ais2. dis'4 |
      e'4 gis'4 dis'4 fis'4 |
      e'4 cis'2 a4 |
      b4 gis4 cis'4 a4 |
      cis4 fis4 cis'2 |
      fis'4 cis'2 e'4 |
      fis'4 dis'4 gis'4 e'4 |
      b4 dis'4 fis'4 cis'4 |
      ais4 b4 cis'4 gis4 |
      b4 dis'2 b4 |
      cis'4 fis'4 dis'4 e'4 |
      cis'4 e'2. |
      dis'4 b4 cis'4 ais4 |
      r1 |
      b4 dis'2 b4 |
      gis4 b2 gis4 |
      b4 gis2 b4 |
      gis4 b4 gis4 b4 |
      e'4 cis'2 e'4 |
      cis'4 e'2 cis'4 |
      dis'4 b2 gis4 |
      b4 dis'2 b4 |
      cis'4 dis'4 e'2 |
      dis'4 b4 gis4 e4 |
      fis4 b4 cis'4 e'4 |
      cis'2 ais4 dis'4 |
      b4 dis'4 b4 gis4 |
      b4 dis'2 b4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis4^\markup { \tiny \italic "Subject" } b4 ais2 |
      fis4 gis4 cis'2 |
      b2 gis2 |
      b4^\markup { \tiny \italic "Countersubject" } ais4 gis4. fis16 gis16 |
      ais4 b2~ b8 ais16 b16 |
      ais4. gis16 ais16 b2 |
      cis'4 b4 fis2~ |
      fis4 e2. |
      gis8 ais8 b4 cis'2 |
      dis'4 cis'2.~ |
      cis'4 b2. |
      dis'2.~ dis'8 cis'8 |
      b8 ais8 gis4 fis2 |
      ais,4 b,4 e8 fis8 gis4 |
      b1 |
      b8 ais8 gis4 cis'4 gis'4 |
      dis'2 gis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis4 fis4. gis8 ais4~ |
      ais4 cis'2 gis4~ |
      gis4 b4. ais8 gis4 |
      fis8 gis8 ais4 cis'4 eis'4~ |
      eis'4 dis'8 cis'8 b4 gis4 |
      ais4 fis2 b4 |
      r1 |
      fis4 ais4 b2~ |
      b8 ais8 dis'4 b4 dis'4~ |
      dis'8 cis'8 ais4 gis4 b4 |
      dis'4 b2 gis4 |
      eis4 ais4. gis8 fis4 |
      cis'4 gis4 a4 fis4 |
      b4 a2 cis'4 |
      gis4 e4 fis4 a4 |
      e'4 b4 cis'4 e'4 |
      fis'4 e'4 cis'4 gis4 |
      fis4 b2 gis4 |
      dis'4 b4 fis2 |
      ais4 gis2 cis'4 |
      gis4 b,2 dis4 |
      fis4 ais4 dis4 cis4 |
      gis4 e4 gis4 e4 |
      gis2 fis2 |
      r1 |
      b1 |
      dis1 |
      b,1 |
      b4 e'4 b2 |
      gis2. e4 |
      gis1 |
      b2. dis'4 |
      b1 |
      gis4^\markup { \tiny \italic "Subject" } b4 ais2 |
      fis4 gis4 cis'2 |
      b2 gis2 |
      e'4 gis4 fisis4 ais4 |
      b1 |
      b1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis4^\markup { \tiny \italic "Subject" } b4 ais2 |
      fis4 gis4 cis'2 |
      b2 gis2 |
      b4^\markup { \tiny \italic "Countersubject" } ais4 gis4. fis16 gis16 |
      ais4 b2~ b8 ais16 b16 |
      ais4. gis16 ais16 b2 |
      cis'4 b4 fis2~ |
      fis4 e2. |
      gis2 e2 |
      fis4 cis2~ cis8 dis8 |
      eis4 dis4 eis2 |
      fis1 |
      gis2 fis2 |
      dis8 cis8 b,4 cis2 |
      dis8 cis8 b,4 e2 |
      gis8 fis8 e2 cis4 |
      ais,2 b,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis4 dis4 b,4 dis4 |
      ais4 eis4 fis4 ais4 |
      a4 b4 fis4 dis4 |
      gis4 e4 fis4 a4 |
      e4 gis4 cis4 e4 |
      e4 fis4 e2 |
      dis4 gis2. |
      dis4 fis4 e4 gis4 |
      gis4 dis4 cis4 fis4~ |
      fis4 dis4 e4 gis4~ |
      gis4 b2 gis4 |
      cis'4 ais4 b4 gis4 |
      e4 gis4 e4 b,4 |
      dis2 fis4 ais4 |
      r1 |
      gis4 b2 gis4 |
      b4 gis2 b4 |
      gis4 e2 gis4 |
      b4 gis4 b4 gis4 |
      e4 gis4 e4 cis4 |
      e4 gis2 cis'4 |
      b4 gis2 b4 |
      gis4 b2 gis4 |
      gis4 fis4 cis4 e4 |
      fis4 e2 gis4 |
      dis4 fis4 e4 cis4 |
      e4 gis4 dis2~ |
      dis4 gis2 b4 |
      gis4 b2 gis4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis4^\markup { \tiny \italic "Subject" } b4 ais2 |
      fis4 gis4 cis'2 |
      b2 gis2 |
      b,4^\markup { \tiny \italic "Countersubject" } ais,4 gis,4. fis,16 gis,16 |
      ais,4 b,2~ b,8 ais,16 b,16 |
      ais,4. gis,16 ais,16 b,2 |
      cis4 dis4 fis2 |
      dis4 cis8 dis8 e2 |
      gis2 e2 |
      dis2 eis2~ |
      eis4 fis8 eis8 dis2~ |
      dis2 fis2 |
      e8 dis8 cis4 ais,4 b,8 cis8 |
      dis4 ais4 eis2 |
      ais4 fis4 dis2 |
      fis4 ais4 dis2 |
      r1 |
      r1 |
      e2 fis4 a4 |
      e4 a,4 cis2 |
      e4 b,4 cis2 |
      cis4 b,4 e4 cis'4 |
      ais4 cis4 gis4 e4 |
      b,4 dis4 b,2 |
      b,2 cis4 ais,4~ |
      ais,4 dis4 cis4 e4 |
      dis4 gis4 dis2 |
      ais,4 cis4 dis4 gis4~ |
      gis4 cis'4 e2 |
      b,4 dis4 cis2 |
      r1 |
      gis4 dis4 b,2 |
      dis4 b,4 dis2 |
      gis4 b4 gis4 e4~ |
      e4 gis4 e4 b,4 |
      cis4 e4 gis2~ |
      gis4 e4 gis2~ |
      gis4 b4 gis4 dis4~ |
      dis4 b,4 dis2 |
      gis4 dis4 ais,2 |
      b,4 e4 gis2 |
      b4 fis4 gis2 |
      gis4 cis4 ais2 |
      dis4 b,4 dis2 |
      gis2 dis2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis4^\markup { \tiny \italic "Real answer" } fis4 eis2 |
      cis4 dis4 gis2 |
      fis2 dis2 |
      e4^\markup { \tiny \italic "Countersubject" } dis4 cis4. b,16 cis16 |
      dis4 e2~ e8 dis16 e16 |
      dis4. cis16 dis16 e2 |
      e8 dis8 cis4 ais,4 b,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'4 dis'4 ais8 gis8 fis4 |
      ais4 gis8 fis8 e8 fis8 gis4 |
      b8 cis'8 dis'4 cis'2 |
      fis2 gis2 |
      eis4 fis4 b2 |
      fis2~ fis8 eis8 dis4 |
      gis,2 ais,4 cis4 |
      fis4 e8 dis8 cis2 |
      dis8 cis8 b,4 e2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis4 fis8 gis8 ais2 |
      dis4 gis8 fis8 e4 gis4~ |
      gis2 b2 |
      fis8 eis8 dis4 gis,2 |
      cis4 fis4 b,2 |
      fis4 dis2. |
      r1 |
      b,4 cis4 b,2 |
      cis4 b,2. |
      cis2 dis2 |
      dis1 |
      eis2 dis2 |
      cis4 b,4 a,2 |
      b,4 e4 cis2 |
      b,2 a,2 |
      gis,4 fis,4 ais,2~ |
      ais,4 cis2. |
      dis4 b,2. |
      b,2 fis2~ |
      fis4 b,4 gis,2 |
      dis2 b,2 |
      fis2. cis4 |
      e4 cis4 gis,4 b,4~ |
      b,2 fis,2 |
      r1 |
      b,2 dis2 |
      gis,2 b,2~ |
      b,4 e4 b,2 |
      e2 gis,2 |
      cis2 e2~ |
      e4 cis4 gis,4 e,4 |
      b,2 dis2~ |
      dis4 gis4 dis2 |
      gis,4 dis4 ais2 |
      dis4 gis,2. |
      fis,2 cis2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis4^\markup { \tiny \italic "Real answer" } fis4 eis2 |
      cis4 dis4 gis2 |
      fis2 dis2 |
      e4^\markup { \tiny \italic "Countersubject" } dis4 cis4. b,16 cis16 |
      dis4 e2~ e8 dis16 e16 |
      dis4. cis16 dis16 e2 |
      b,2 cis2 |
      dis2~ dis8 cis8 b,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,8 gis,8 ais,4 cis2~ |
      cis4 fis4 b,2 |
      fis,2 b,2 |
      b,8 cis8 dis4 ais,4 fis,4 |
      dis4 gis8 fis8 e2 |
      b,4 gis,4 b,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,4 e4 a,2 |
      e2 a,2 |
      e2 a,2 |
      r1 |
      r1 |
      r1 |
      dis,4 gis,4 cis2 |
      ais4 dis4 gis,2 |
      dis,4 b,,4 dis,2 |
      ais,2 dis4 gis,4~ |
      gis,4 cis,4 gis,2 |
      dis4 gis4 cis2 |
      r1 |
      b,4 gis,4 b,2~ |
      b,4 dis2 b,4~ |
      b,2 e2~ |
      e4 b,4 e2~ |
      e4 gis,2. |
      e2 cis4 e4 |
      b,4 dis4 b,2~ |
      b,4 gis,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis,4^\markup { \tiny \italic "Real answer" } fis,4 eis,2 |
      cis,4 dis,4 gis,2 |
      fis,2 dis,2 |
      e,4^\markup { \tiny \italic "Countersubject" } dis,4 cis,4. b,,16 cis,16 |
      dis,4 e,2~ e,8 dis,16 e,16 |
      dis,4. cis,16 dis,16 e,2 |
      e2~ e8 fis8 gis4 |
      dis4. cis8 b,4 dis,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,2 cis2~ |
      cis4 fis,4 dis2~ |
      dis4 ais,4 dis4 b,4 |
      r1 |
      fis4 cis4 gis,4 eis,4 |
      ais,,4 fis,4 b,2 |
      fis4 cis4 gis,4 dis,4 |
      r1 |
      r1 |
      e,4 b,4 dis,2 |
      b,4 e,4 a,4 cis,4 |
      gis,4 b,4 fis4 a,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,4 dis4 gis,2~ |
      gis,4 dis,4 b,2~ |
      b,4 e,2 b,,4~ |
      b,,2 gis,2~ |
      gis,4 cis,2 gis,4~ |
      gis,4 cis,4 gis,2~ |
      gis,4 dis4 gis,2~ |
      gis,4 dis,4 gis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 16" shortInstrumentName = "V16" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis,4^\markup { \tiny \italic "Real answer" } fis,4 eis,2 |
      cis,4 dis,4 gis,2 |
      fis,2 dis,2 |
      e,2 dis,8 cis,8 b,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis,4 b,2 dis,4~ |
      dis,4 gis,2 dis,4 |
      b,2. e,4~ |
      e,2 b,4 e,4~ |
      e,2. gis,,4~ |
      gis,,4 cis,2 gis,4~ |
      gis,2. gis,,4~ |
      gis,,4 dis,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 17" shortInstrumentName = "V17" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,4^\markup { \tiny \italic "Subject" } b,4 ais,2 |
      fis,4 gis,4 cis2 |
      b,2 gis,2 |
      e,2 dis,8 cis,8 b,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,,8 cis,8 dis,4 ais,4 fis,4~ |
      fis,4 b,8 ais,8 gis,4 e,4 |
      fis,8 e,8 dis,4 b,,4 e,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,4 dis,4 fis,4 cis,4 |
      ais,,4 b,,4 e,4 cis,4 |
      gis,2. e,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis,4 gis,,2 dis,4~ |
      dis,2 gis,4 b,,4~ |
      b,,2 gis,2~ |
      gis,4 gis,,2 e,4~ |
      e,2 gis,,4 e,4~ |
      e,2 gis,,2~ |
      gis,,2 gis,2~ |
      gis,4 b,,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 18" shortInstrumentName = "V18" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,,4^\markup { \tiny \italic "Subject" } b,,4 ais,,2 |
      fis,,4 gis,,4 cis,2 |
      b,,2 gis,,2 |
      gis,,2 e,2 |
      dis,4. cis,8 b,,8 ais,,8 gis,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,,1 |
      dis,1 |
      gis,,2 e,4 gis,,4~ |
      gis,,2 e,2 |
      gis,,2 e,2 |
      gis,,2. e,4 |
      gis,,2. gis,4~ |
      gis,2 b,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 19" shortInstrumentName = "V19" } {
      \clef "bass" \key gis \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,,4^\markup { \tiny \italic "Subject" } b,,4 ais,,2 |
      fis,,4 gis,,4 cis,2 |
      b,,2 gis,,2 |
      gis,,4. fis,,8 e,,2 |
      dis,,2 gis,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,,4^\markup { \tiny \italic "Countersubject" } ais,,4 gis,,4. fis,,16 gis,,16 |
      ais,,4 b,,2~ b,,8 ais,,16 b,,16 |
      ais,,4. gis,,16 ais,,16 b,,2 |
      b,,1 |
      ais,,4. gis,,8 fis,,2 |
      a,,4^\markup { \tiny \italic "Countersubject" } gis,,4 fis,,4. e,,16 fis,,16 |
      gis,,4 a,,2~ a,,8 gis,,16 a,,16 |
      gis,,4. fis,,16 gis,,16 a,,2 |
      e,,4^\markup { \tiny \italic "Countersubject" } dis,,4 cis,,4. b,,,16 cis,,16 |
      dis,,4 e,,2~ e,,8 dis,,16 e,,16 |
      dis,,4. cis,,16 dis,,16 e,,2 |
      gis,,4^\markup { \tiny \italic "Stretto subject" } b,,4 ais,,2 |
      fis,,4 gis,,4 cis,2 |
      b,,2 gis,,2 |
      ais,,4 fis,,4 b,,4 e,,4~ |
      e,,2. gis,,4 |
      b,,2 ais,,2 |
      r1 |
      gis,,1~ |
      gis,,1~ |
      gis,,1~ |
      gis,,1 |
      cis,,1~ |
      cis,,1 |
      gis,,1~ |
      gis,,1 |
      e,,4^\markup { \tiny \italic "Countersubject" } dis,,4 cis,,4. b,,,16 cis,,16 |
      dis,,4 e,,2~ e,,8 dis,,16 e,,16 |
      dis,,4. cis,,16 dis,,16 e,,2 |
      e,,4 cis,,4 dis,,2 |
      gis,,1 |
      gis,,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
