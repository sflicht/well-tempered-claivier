\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "VIII. Prelude in E-flat minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key ees \minor \time 12/8
      \tempo "Andante sostenuto" 4 = 96
      \mark \markup \box \small "Opening cell" bes''4.\p aes''4. ges''2. |
      ges''8 f''8 ges''8 aes''4. ges''2. |
      aes''4. ees''4. ees''2. |
      ges''4. f''4. ees''2. |
      f''4. ges''4. f''2. |
      f''8 ges''8 f''8 ges''4. f''2. |
      ees''4. d''4. ees''2. |
      d''4. des''4. d''2. |
      \mark \markup \box \small "Contrasting span" ges''4.\mp aes''4. ges''2. |
      aes''8 ges''8 f''8 aes''4. aes''2.~^\markup { \tiny \italic "Prepared suspension" } |
      aes''4 ges''8^\markup { \tiny \italic "Resolution" } f''4. ges''2. |
      ees''4. des''4. ces''2. |
      ees''4. f''4. ees''2. |
      f''8 ges''8 f''8 ges''4. f''2. |
      d''4. ees''4. d''2. |
      f''4. d''4. f''2. |
      \mark \markup \box \small "Return" ges''4.\mp aes''4. ges''2. |
      aes''8 ges''8 aes''8 ges''4. aes''2. |
      fes''4. f''4. fes''2. |
      f''4. ees''4. d''2. |
      \mark \markup \box \small "Cadence" ees''4.\p f''4. ges''2. |
      aes''8 ges''8 aes''8 ges''4. aes''2. |
      f''4. ees''4. d''2. |
      ees''1~ ees''2 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key ees \minor \time 12/8
      ees'8\p f'8 ges'8 bes'8 ees'8 ges'8 ees'8 bes'8 ges'8 bes'8 ees'8 ges'8 |
      ces'8 ges'8 ees'8 ges'8 ces'8 ees'8 ces'8 ges'8 ees'8 ges'8 ces'8 ees'8 |
      aes8 bes8 ces'8 ees'8 aes8 ces'8 aes8 ees'8 ces'8 ees'8 aes8 ces'8 |
      ees8 bes8 ges8 bes8 ees8 ges8 ees8 bes8 ges8 bes8 ees8 ges8 |
      f8 ges8 aes8 ces'8 f8 aes8 f8 ces'8 aes8 ces'8 f8 aes8 |
      bes8 f'8 d'8 f'8 bes8 d'8 bes8 f'8 d'8 f'8 bes8 d'8 |
      ees'8 f'8 ges'8 bes'8 ees'8 ges'8 ees'8 bes'8 ges'8 bes'8 ees'8 ges'8 |
      bes8 f'8 d'8 f'8 bes8 d'8 bes8 f'8 d'8 f'8 bes8 d'8 |
      ges8\mp aes8 bes8 des'8 ges8 bes8 ges8 des'8 bes8 des'8 ges8 bes8 |
      des8 aes8 f8 aes8 des8 f8 des8 aes8 f8 aes8 des8 f8 |
      ges8 aes8 bes8 des'8 ges8 bes8 ges8 des'8 bes8 des'8 ges8 bes8 |
      ces'8 ges'8 ees'8 ges'8 ces'8 ees'8 ces'8 ges'8 ees'8 ges'8 ces'8 ees'8 |
      aes8 bes8 ces'8 ees'8 aes8 ces'8 aes8 ees'8 ces'8 ees'8 aes8 ces'8 |
      f8 c'8 a8 c'8 f8 a8 f8 c'8 a8 c'8 f8 a8 |
      bes8 f'8 d'8 f'8 bes8 d'8 bes8 f'8 d'8 f'8 bes8 d'8 |
      bes8 f'8 d'8 f'8 bes8 d'8 bes8 f'8 d'8 f'8 bes8 d'8 |
      ees'8\mp f'8 ges'8 bes'8 ees'8 ges'8 ees'8 bes'8 ges'8 bes'8 ees'8 ges'8 |
      aes8 ees'8 ces'8 ees'8 aes8 ces'8 aes8 ees'8 ces'8 ees'8 aes8 ces'8 |
      fes8 ges8 aes8 ces'8 fes8 aes8 fes8 ces'8 aes8 ces'8 fes8 aes8 |
      bes8 f'8 d'8 f'8 bes8 d'8 bes8 f'8 d'8 f'8 bes8 d'8 |
      ees'8\p ges'8 ees'8 des'8 ces'8 ees'8 ces'8 ges'8 ees'8 ges'8 ces'8 ees'8 |
      aes8 ees'8 ces'8 ees'8 aes8 ces'8 aes8 ees'8 ces'8 ees'8 aes8 ces'8 |
      bes8 f'8 d'8 f'8 bes8 d'8 bes8 f'8 d'8 f'8 bes8 aes8 |
      ges1~ ges2 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key ees \minor \time 12/8
      ees,1~\p ees,2 |
      ces,1~ ces,4. bes,,8 |
      aes,,1~ aes,,2 |
      ges,,1~ ges,,2 |
      aes,,1~ aes,,2 |
      bes,,1~ bes,,2 |
      ees,1~ ees,2 |
      bes,,1~ bes,,2 |
      ges,,1~\mp ges,,2 |
      des,1~ des,2 |
      ges,1~ ges,2 |
      ces,1~ ces,2 |
      aes,,1~ aes,,2 |
      f,,1~ f,,2 |
      bes,,1~ bes,,2 |
      bes,,1~ bes,,2 |
      ees,1~\mp ees,2 |
      aes,1~ aes,2 |
      aes,1~ aes,2 |
      bes,1~ bes,2 |
      ces1~\p ces2 |
      aes,1~ aes,2 |
      bes,1~ bes,2 |
      ees,1~ ees,2 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
