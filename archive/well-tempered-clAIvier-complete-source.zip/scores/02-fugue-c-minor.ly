\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "II. Fugue in C minor — The turning path"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key c \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 94
      \mark \markup \box \small "Continuous exposition" r1 |
      r1 |
      g''4^\markup { \tiny \italic "Real answer" } d'''4 c'''4 bes''4 |
      a''8 g''8 f''4 g''2 |
      aes''4^\markup { \tiny \italic "Countersubject" } bes''4 aes''16 bes''16 aes''8 g''4 |
      f''4 g''4 aes''2 |
      \mark \markup \box \small "Sequence toward the relative major" aes''2 bes''4^\markup { \tiny \italic "Subject-head fragment" } f'''4 |
      ees'''2 ees''4^\markup { \tiny \italic "Subject-head fragment" } bes''4 |
      \mark \markup \box \small "Relative-key development" ees''4^\markup { \tiny \italic "Relative-key subject" } bes''4 aes''4 g''4 |
      f''8 ees''8 d''4 ees''2 |
      \mark \markup \box \small "Major-mode episode" ees''2 f''4^\markup { \tiny \italic "Subject-head fragment" } c'''4 |
      d'''8 c'''8 bes''4 ees''4^\markup { \tiny \italic "Subject-head fragment" } bes''4 |
      \mark \markup \box \small "Minor-mode return" aes''4. g''8 f''2 |
      g''1 |
      \mark \markup \box \small "Stretto" g''2 aes''4 g''4 |
      b''8 c'''8 d'''4 c'''4^\markup { \tiny \italic "Stretto subject" } g'''4 |
      f'''4 ees'''4 d'''8 c'''8 bes''4 |
      c'''2 g''2 |
      \mark \markup \box \small "Middle-voice final return" aes''4^\markup { \tiny \italic "Countersubject" } bes''4 aes''16 bes''16 aes''8 g''4 |
      f''4 g''4 aes''2 |
      \mark \markup \box \small "Final cadence" f''2 g''4 b''4 |
      c'''1^\markup { \tiny \italic "Cadential tonic arrival" } |
      c'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key c \minor \time 4/4
      c'4^\markup { \tiny \italic "Subject" } g'4 f'4 ees'4 |
      d'8 c'8 bes4 c'2 |
      ees'4^\markup { \tiny \italic "Countersubject" } f'4 ees'16 f'16 ees'8 d'4 |
      c'4 d'4 ees'2 |
      ees'2~ ees'8 d'8 c'4 |
      b4 bes4 aes8 bes8 c'4 |
      f'4^\markup { \tiny \italic "Subject-head fragment" } c''4 bes'2 |
      ees'4^\markup { \tiny \italic "Subject-head fragment" } bes'4 g'8 f'8 ees'4 |
      ees'4 f'4. ees'8 d'8 ees'8 |
      f'2~ f'8 ees'4 d'8 |
      c'4^\markup { \tiny \italic "Subject-head fragment" } g'4 f'2 |
      bes4^\markup { \tiny \italic "Subject-head fragment" } f'4 g'2 |
      ees'4. d'8 c'2 |
      b8 c'8 d'4 ees'2 |
      ees'2 d'4 ees'4 |
      f'2 ees'2 |
      f'4 g'8 aes'8 bes'8 aes'8 g'4 |
      ees'2 d'2 |
      c'4^\markup { \tiny \italic "Subject" } g'4 f'4 ees'4 |
      d'8 c'8 bes4 c'2 |
      c'2 b8 c'8 d'4 |
      ees'1 |
      ees'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "bass" \key c \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      c4^\markup { \tiny \italic "Subject" } g4 f4 ees4 |
      d8 c8 bes,4 c2 |
      aes,8 g,8 f,4 d,2 |
      g,1 |
      c4^\markup { \tiny \italic "Countersubject" } d4 c4 bes,4 |
      aes,4 bes,4 c2 |
      c4. bes,8 aes,2 |
      bes,8 c8 d4 ees2 |
      c2 aes,2 |
      g,4 b,4 c2 |
      c4^\markup { \tiny \italic "Stretto subject" } g4 f4 ees4 |
      d8 c8 bes,4 c2 |
      aes,4 g,2 ees4~ |
      ees4 c4 b,2 |
      c4 bes,4 f,4 g,8 aes,8 |
      bes,2 aes,2 |
      aes,2 g,2 |
      c1^\markup { \tiny \italic "Cadential tonic bass" } |
      c1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
