\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XIII. Prelude in F-sharp major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key fis \major \time 5/4
      \tempo "Con moto, in cinque" 4 = 102
      \mark \markup \box \small "Opening cell" fis'8\p gis'8 ais'8 fis''8 cis''8 ais''8 fis''8 ais'8 cis''8 fis'8 |
      dis'8 ais'8 fis'8 dis''8 ais'8 fis''8 dis''8 fis'8 ais'8 dis'8 |
      b'8 cis''8 dis''8 b''8 fis''8 dis'''8 b''8 dis''8 fis''8 b'8 |
      dis''8 gis'8 gis'8 dis''8 b'8 gis''8 dis''8 b''8 gis''8 b'8 |
      cis''8 dis''8 eis''8 cis'''8 gis''8 eis'''8 cis'''8 eis''8 gis''8 cis''8 |
      fis'8 cis''8 ais'8 fis''8 cis''8 ais''8 fis''8 ais'8 cis''8 fis'8 |
      cis''8 dis''8 eis''8 cis'''8 ais''8 cis''8 eis''8 ais'8 ais'8 eis''8 |
      dis''8 ais''8 fis''8 dis'''8 ais''8 fis'''8 dis'''8 fis''8 ais''8 dis''8 |
      \mark \markup \box \small "Contrasting span" dis''8\mp eis''8 fis''8 dis'''8 b''8 dis''8 fis''8 b'8 b'8 fis''8 |
      b'8 gis''8 dis''8 b''8 gis''8 b'8 dis''8 gis'8 gis'8 dis''8 |
      bis'8 cis''8 dis''8 bis''8 gis''8 bis'8 dis''8 gis'8 gis'8 dis''8 |
      cis''8 gis''8 eis''8 cis'''8 gis''8 eis'''8 cis'''8 eis''8 gis''8 cis''8 |
      fis'8 gis'8 ais'8 fis''8 ais''8 cis''8 fis''8 ais'8 cis''8 fis'8 |
      b'8 fis''8 dis''8 b''8 dis'''8 fis''8 b''8 dis''8 fis''8 b'8 |
      b'8 cis''8 d''8 b''8 d'''8 fis''8 b''8 d''8 fis''8 b'8 |
      cis''8 fis'8 fis'8 cis''8 ais'8 fis''8 ais''8 cis''8 fis''8 ais'8 |
      \mark \markup \box \small "Return" dis''8\mp eis''8 fis''8 dis'''8 fis'''8 ais''8 dis'''8 fis''8 ais''8 dis''8 |
      ais'8 eis''8 cisis''8 ais''8 cisis'''8 eis''8 ais''8 cisis''8 eis''8 ais'8 |
      dis''8 eis''8 fis''8 dis'''8 ais''8 fis'''8 dis'''8 fis''8 ais''8 dis''8 |
      dis''8 gis'8 gis'8 dis''8 b'8 gis''8 dis''8 b''8 gis''8 b'8 |
      \mark \markup \box \small "Cadence" fis'8\p gis'8 ais'8 fis''8 cis''8 ais''8 fis''8 ais'8 cis''8 fis'8 |
      cis''8 gis''8 eis''8 cis'''8 gis''8 eis'''8 cis'''8 eis''8 gis''8 cis''8 |
      fis'8 cis''8 ais'8 fis''8 cis''8 ais''8 fis''8 ais'8 cis''8 fis'8 |
      fis'1~ fis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key fis \major \time 5/4
      ais4.\p cis'4. ais2 |
      fis4. ais4. fis2 |
      dis4. fis4. dis2 |
      b,4. dis4. b,2 |
      cis4. eis4. gis2 |
      ais4. cis'4. ais2 |
      cis'4. eis'4. cis'2 |
      fis'4. fis'4. dis'2 |
      dis'4.\mp fis'4. dis'2 |
      b4. dis'4. b2 |
      bis4. dis'4. bis2 |
      eis'4. eis'4. cis'2 |
      ais4. cis'4. ais2 |
      dis'4. dis'4. b2 |
      d'4. fis'4. d'2 |
      ais4. ais4. fis2 |
      fis4.\mp ais4. fis2 |
      cisis4. eis4. cisis2 |
      fis4. ais4. fis2 |
      gis4. b4. gis2 |
      ais4.\p ais4. fis2 |
      eis4. gis4. eis2 |
      fis4. ais4. fis2 |
      fis1~ fis4 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key fis \major \time 5/4
      cis1~\p cis4 |
      ais,1~ ais,4 |
      dis1~ dis4 |
      dis1~ dis4 |
      eis1~ eis4 |
      fis1~ fis4 |
      eis1~ eis4 |
      ais1~ ais4 |
      fis1~\mp fis4 |
      dis1~ dis4 |
      dis1~ dis4 |
      eis1~ eis4 |
      fis1~ fis4 |
      fis1~ fis4 |
      d1~ d4 |
      cis1~ cis4 |
      ais,1~\mp ais,4 |
      cisis1~ cisis4 |
      fis1~ fis4 |
      dis1~ dis4 |
      cis1~\p cis4 |
      eis1~ eis4 |
      fis1~ fis4 |
      fis1~ fis4 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key fis \major \time 5/4
      fis,2\p fis,2. |
      dis,2 dis,2~ dis,8 cis,8 |
      b,,2 b,,2. |
      b,,2 b,,2. |
      cis,2 cis,2. |
      fis,2 fis,2~ fis,8 gis,8 |
      ais,2 ais,2. |
      dis,2 dis,2. |
      b,,2\mp b,,2. |
      b,,2 b,,2~ b,,8 ais,,8 |
      gis,,2 gis,,2. |
      cis,2 cis,2. |
      fis,2 fis,2. |
      b,,2 b,,2. |
      b,,2 b,,2. |
      ais,,2 ais,,2. |
      dis,2\mp dis,2. |
      ais,,2 ais,,2. |
      dis,2 dis,2~ dis,8 cis,8 |
      b,,2 b,,2. |
      cis,2\p cis,2. |
      cis,2 cis,2. |
      fis,2 fis,2. |
      fis,,1~ fis,,4 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
