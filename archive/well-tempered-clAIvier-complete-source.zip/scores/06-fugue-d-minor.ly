\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "VI. Fugue in D minor — A descending question"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key d \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 88
      \mark \markup \box \small "Continuous exposition" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4^\markup { \tiny \italic "Real answer" } e'''4 f'''2 |
      e'''8 d'''8 c'''4 b''2 |
      g''2 a''2 |
      bes''4^\markup { \tiny \italic "Countersubject" } c'''4 d'''4. c'''16 d'''16 |
      cis'''4 d'''4 cis'''4 c'''8 bes''8 |
      a''4. g''16 a''16 bes''2 |
      \mark \markup \box \small "Seven-part ascent to the relative major" d'''2 c'''4^\markup { \tiny \italic "Subject-head fragment" } g'''4 |
      c'''8 bes''8 a''4 f''4^\markup { \tiny \italic "Subject-head fragment" } c'''4 |
      \mark \markup \box \small "Relative-key development" bes''4 c'''4 f'''2 |
      c'''2.~ c'''8 bes''8 |
      a''2 bes''2 |
      \mark \markup \box \small "Subject-head sequence" a''2 g''4^\markup { \tiny \italic "Subject-head fragment" } d'''4 |
      g''2 f''4^\markup { \tiny \italic "Subject-head fragment" } c'''4 |
      \mark \markup \box \small "The seven parts reconvene" bes''4. a''8 g''2 |
      a''2.~ a''8 g''8 |
      \mark \markup \box \small "Stretto" f''2 d'''2 |
      c'''4. d'''8 e'''2 |
      a''4^\markup { \tiny \italic "Stretto subject" } e'''4 f'''2 |
      e'''8 d'''8 c'''4 b''2 |
      g''2 a''2 |
      \mark \markup \box \small "Seven-part final return" d'''4 c'''4. d'''8 e'''4 |
      d'''4 c'''4 bes''4 f'''4 |
      a''1 |
      a'''2 d'''4 d''4 |
      \mark \markup \box \small "Final cadence" g''2 e'''8 d'''8 cis'''4 |
      d'''1^\markup { \tiny \italic "Cadential tonic arrival" } |
      d'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key d \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4^\markup { \tiny \italic "Real answer" } e'''4 f'''2 |
      e'''8 d'''8 c'''4 b''2 |
      g''2 a''2 |
      f''2 e''4 d''4 |
      bes'4^\markup { \tiny \italic "Countersubject" } c''4 d''4. c''16 d''16 |
      cis''4 d''4 cis''4 c''8 bes'8 |
      a'4. g'16 a'16 bes'2 |
      d''4 b'4 a'2 |
      e'2~ e'8 f'8 g'4 |
      c''1 |
      f''4 c'''4 bes''4 d'''4 |
      a''2 g''8 f''8 e''4~ |
      e''2 d''8 e''8 f''4 |
      bes'2 c''2~ |
      c''2. a'4 |
      f''4^\markup { \tiny \italic "Relative-key subject" } c'''4 d'''2 |
      c'''8 bes''8 a''4 g''2 |
      e''2 f''2 |
      f''2 g''4. f''8~ |
      f''8 e''4. f''2 |
      f''2 g''4 d''4 |
      a'2. d''4 |
      f''2 bes''2 |
      c'''2 e''4 c''4 |
      e'4 a'2. |
      e''2 b'4 d''4 |
      e''2~ e''8 d''8 c''4 |
      d''8 e''8 f''4 c'''4 c''4 |
      f''2 f'2 |
      a'4 f''4 a'8 bes'8 c''4~ |
      c''4 f''4 bes''4 d''4 |
      d''2 cis''4 a'4~ |
      a'1 |
      a'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key d \minor \time 4/4
      r1 |
      r1 |
      r1 |
      a'4^\markup { \tiny \italic "Real answer" } e''4 f''2 |
      e''8 d''8 c''4 b'2 |
      g'2 a'2 |
      bes'4^\markup { \tiny \italic "Countersubject" } c''4 d''4. c''16 d''16 |
      cis''4 d''4 cis''4 c''8 bes'8 |
      a'4. g'16 a'16 bes'2 |
      a'4 b'4 c''2 |
      b'4 a'4 b'2 |
      c''2 a'2 |
      a'1 |
      d'4 c'4 g'2 |
      a'2 g'4. f'8 |
      e'2 f'8 e'8 d'4 |
      d'4 g'4 c''2 |
      b'4 c''4 e'2 |
      c''1~ |
      c''8 bes'8 a'4 d''4 f''4 |
      a'2 e''8 d''8 c''4~ |
      c''2 bes'2 |
      bes'4. a'8 g'2~ |
      g'8 f'8 c'4 a2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes'4 f'4 bes'4 d''4 |
      cis''8 d''8 e''4 f''2 |
      d''4 c''4 bes'2 |
      f''2 c''2 |
      a'8 bes'8 c''4 f'2 |
      g'2. d''4 |
      g'8 a'8 b'4 e''2 |
      d''4 a''4 g''2 |
      bes'4^\markup { \tiny \italic "Countersubject" } c''4 d''4. c''16 d''16 |
      cis''4 d''4 cis''4 c''8 bes'8 |
      a'4. g'16 a'16 bes'2 |
      g''2 e''2 |
      f''2 d''2 |
      d''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key d \minor \time 4/4
      d'4^\markup { \tiny \italic "Subject" } a'4 bes'2 |
      a'8 g'8 f'4 e'2 |
      c'2 d'2 |
      f'4^\markup { \tiny \italic "Countersubject" } g'4 a'4. g'16 a'16 |
      gis'4 a'4 gis'4 g'8 f'8 |
      e'4. d'16 e'16 f'2 |
      f'8 g'8 a'4 d''2 |
      a'2 g'8 f'8 e'4~ |
      e'2 f'2 |
      f'4 e'8 d'8 c'4. d'8 |
      e'1~ |
      e'2 d'2 |
      c'4 c''2 f'4~ |
      f'4 c'4 bes8 c'8 d'4 |
      e'4 a'4 e'2~ |
      e'8 d'8 c'4 bes2 |
      f'4 e'8 d'8 c'8 b8 a4 |
      b4 a4 b2 |
      e'2 c'2 |
      d'8 e'8 f'4 d'2 |
      a'2 e'2~ |
      e'2 f'4. e'8 |
      d'2 e'2 |
      c'2 f'2 |
      d'4^\markup { \tiny \italic "Countersubject" } e'4 f'4. e'16 f'16 |
      e'4 f'4 e'16 f'16 e'4. |
      e'4. f'8 d'2 |
      d'4^\markup { \tiny \italic "Subject-head fragment" } a'4 d'2 |
      c'4^\markup { \tiny \italic "Subject-head fragment" } g'4 a'2 |
      d'8 c'8 bes4 d'2 |
      e'2 a'4 f'4 |
      f'2.~ f'8 g'8 |
      a'2 g'2 |
      a'4. g'8 f'2 |
      c'4. d'8 e'4 d'4 |
      b2 c'2 |
      f2 e4 c'4 |
      bes4 a4 f'2 |
      e'4 d'4 a'2 |
      e'4 f'2~ f'8 e'8 |
      d'2 a'2 |
      d'2 a2 |
      a1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "bass" \key d \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'4^\markup { \tiny \italic "Subject" } a'4 bes'2 |
      a'8 g'8 f'4 e'2 |
      c'2 d'2 |
      f4^\markup { \tiny \italic "Countersubject" } g4 a4. g16 a16 |
      gis4 a4 gis4 g8 f8 |
      e4. d16 e16 f2 |
      a4. bes8 c'4 a4 |
      f'4 e'4 g'2 |
      e'4 d'4 e'2 |
      a2 f4. g8 |
      a4 b4 c'2 |
      e'2 b2 |
      c'2~ c'8 b8 a4 |
      f'2.~ f'8 g'8 |
      a'4 d'4 g4 c'4~ |
      c'4 a4 f2 |
      g8 a8 bes4 g'2 |
      a'8 g'8 f'4 c'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'2. g4 |
      e'4 a2. |
      a8 bes8 c'4 f'2~ |
      f'4 c'2.~ |
      c'4. bes8 a2 |
      g2. gis8 a8 |
      b4 g4 c'2 |
      f'4 a4 e4 g4 |
      d'4^\markup { \tiny \italic "Subject" } a'4 bes'2 |
      a'8 g'8 f'4 e'2 |
      c'2 d'2 |
      d'2 a2~ |
      a8 g8 f4 a2 |
      a1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "bass" \key d \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f8 g8 a2 d4 |
      d4^\markup { \tiny \italic "Subject" } a4 bes2 |
      a8 g8 f4 e2 |
      c2 d2 |
      f4^\markup { \tiny \italic "Countersubject" } g4 a4. g16 a16 |
      gis4 a4 gis4 g8 f8 |
      e4. d16 e16 f2 |
      f'2. d'4 |
      e'4 d'4 e'4 g4 |
      e4 a4 d2 |
      g4^\markup { \tiny \italic "Subject-head fragment" } d'4 g4 e4 |
      f4^\markup { \tiny \italic "Subject-head fragment" } c'4 c'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes2. g4 |
      e4 cis4 d4 a,4 |
      f4 a4 d'4 f'4 |
      c'4 f4 g4 c'4~ |
      c'4 e'4 a2 |
      e4. f8 g4 d4 |
      g4 e2. |
      f4 c2 g4 |
      d4 a,8 g,8 f,4 d4 |
      a,2. e4~ |
      e4 c'4 bes4 bes,8 c8 |
      d4 g4 a2~ |
      a2 f2 |
      f1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "bass" \key d \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d4^\markup { \tiny \italic "Subject" } a4 bes2 |
      a8 g8 f4 e2 |
      c2 d2 |
      bes,4 g,4 c2 |
      a,1 |
      bes,4 a,8 g,8 f,4. g,8 |
      a,4. bes,8 c2~ |
      c2 bes,4. c8 |
      d4. c8 bes,2 |
      c4. bes,8 a,2 |
      bes,1 |
      a,2 f,2 |
      d4^\markup { \tiny \italic "Stretto subject" } a4 bes2 |
      a8 g8 f4 e2 |
      c2 d2 |
      e2. b,4 |
      e4 g,4 c,2 |
      bes,,4 a,,4 c,2 |
      d,8 e,8 f,4 d,2 |
      a,4 d,4 a,,4 a,4~ |
      a,8 g,8 f,4 bes,,4 bes,4 |
      bes,2 a,2 |
      d1^\markup { \tiny \italic "Cadential tonic bass" } |
      d1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
