\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XIII. Fugue in F# major — Clear water"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a3")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key fis \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 114
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''4^\markup { \tiny \italic "Subject" } ais'''4 cis''''4 dis''''4 |
      eis''''8 dis''''8 cis''''8 b'''8 ais'''2 |
      b'''4 gis'''4 fis'''2 |
      ais'''8^\markup { \tiny \italic "Countersubject" } bis'''8 cis''''4 bis'''4 cis''''4 |
      dis''''8 cis''''8 bis'''8 ais'''8 gis'''2 |
      ais'''4 fis'''4 eis'''2 |
      ais'''2 eis'''4 dis'''4 |
      gis'''2 cis''''2~ |
      cis''''8 b'''4. dis'''2 |
      \mark \markup \box \small "Sequential episode" ais'''2 gis'''2~ |
      gis'''2 ais'''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''2 cis''''8 b'''8 ais'''4 |
      cis'''2 eis'''2 |
      dis'''4 gis'''4 dis'''2 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Development" gis''''2 fis''''8 e''''8 dis''''4 |
      cis''''2 fis''''2~ |
      fis''''8 e''''4. b'''2 |
      \mark \markup \box \small "Linking episode" b'''4 gis'''4 ais'''4 b'''4 |
      \mark \markup \box \small "Development" cis''''4^\markup { \tiny \italic "Related-key subject" } eis''''4 gis''''4 ais''''4 |
      bis''''8 ais''''8 gis''''8 fis''''8 eis''''2 |
      fis''''4 dis''''4 cis''''2 |
      \mark \markup \box \small "Stretto" fis'''2 eis'''4 dis'''4 |
      cis'''8 b''8 ais''4 fis'''2 |
      gis'''8 fis'''8 eis'''4 fis'''4^\markup { \tiny \italic "Stretto subject" } ais'''4 |
      cis''''4 dis''''4 eis''''8 dis''''8 cis''''8 b'''8 |
      ais'''2 b'''4 gis'''4 |
      fis'''2 ais'''4 gis'''4 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" ais''''1 |
      ais'''4. b'''8 cis''''2 |
      dis''''4 ais'''4 dis''''2 |
      ais''''4 dis''''4 ais''''4 dis''''4 |
      fis''''2~ fis''''8 eis''''8 dis''''4~ |
      dis''''4 fis''''4 dis''''2 |
      cis''''4. b'''8 ais'''2 |
      cis''''1 |
      \mark \markup \box \small "Gathered development" fis'''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } ais'''2~ |
      ais'''4 cis'''4 cis''''2 |
      fis''''4. gis''''8 ais''''2 |
      fis''''4 ais'''2 fis'''4~ |
      fis'''2 dis''''4 fis''''4~ |
      fis''''2. dis''''4 |
      b'''2~ b'''8 ais'''8 gis'''4 |
      dis'''1 |
      eis'''4 gis'''4 eis'''2~ |
      eis'''2 gis'''2~ |
      gis'''4 eis'''2.~ |
      eis'''4 gis'''4 gis''''4 eis''''4 |
      cis''''2 gis'''4 cis''''4 |
      ais'''2 cis''''2~ |
      cis''''2 ais'''2 |
      fis'''2 ais'''4 fis'''4~ |
      fis'''1 |
      \mark \markup \box \small "Final return" b'''4 ais'''4 gis'''4 fis'''4 |
      b'''4 cis''''2. |
      b'''2 cis''''2 |
      \mark \markup \box \small "Final cadence" b'''2 cis''''2 |
      ais'''1 |
      ais'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''4^\markup { \tiny \italic "Subject" } ais'''4 cis''''4 dis''''4 |
      eis''''8 dis''''8 cis''''8 b'''8 ais'''2 |
      b'''4 gis'''4 fis'''2 |
      ais'''8^\markup { \tiny \italic "Countersubject" } bis'''8 cis''''4 bis'''4 cis''''4 |
      dis''''8 cis''''8 bis'''8 ais'''8 gis'''2 |
      ais'''4 fis'''4 eis'''2 |
      dis'''4 cis'''2 fis''4 |
      cis'''4. dis'''8 eis'''8 dis'''8 cis'''4 |
      fis''4 b''8 cis'''8 dis'''2 |
      dis'''1 |
      eis'''8 fis'''8 gis'''4 ais'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''2 cis'''2~ |
      cis'''4 ais'''2. |
      dis'''4 ais'''4 dis'''2~ |
      dis'''4 ais'''2. |
      fis''''4 b'''4 fis'''2 |
      b''2 fis'''2~ |
      fis'''4 cis''''4 fis'''4 cis'''4~ |
      cis'''2 ais'''2 |
      cis'''2 fis''2 |
      cis'''2 ais'''2 |
      dis''''4 ais'''4 dis'''2~ |
      dis'''4 fis''2. |
      b''4 fis'''2. |
      dis'''1 |
      gis'''8 ais'''8 b'''4 dis'''2~ |
      dis'''4 gis''4 dis'''2 |
      b''1~ |
      b''1 |
      gis''1~ |
      gis''2. gis'''4~ |
      gis'''1 |
      fis'''2 cis''''4 ais'''4~ |
      ais'''4 fis'''4 ais''2 |
      dis'''4 fis'''2. |
      ais''4 fis'''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'''4^\markup { \tiny \italic "Subject" } ais'''4 cis''''4 dis''''4 |
      eis''''8 dis''''8 cis''''8 b'''8 ais'''2 |
      b'''4 gis'''4 fis'''2 |
      ais''8^\markup { \tiny \italic "Countersubject" } bis''8 cis'''4 bis''4 cis'''4 |
      dis'''8 cis'''8 bis''8 ais''8 gis''2 |
      ais''4 fis''4 eis''2 |
      ais''4 b''4 cis'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'''4 fis'''2. |
      cis'''2~ cis'''8 b''8 ais''4 |
      dis'''2 ais'''4 fis'''4~ |
      fis'''4 ais''2 dis'''4~ |
      dis'''2 b'''4 dis'''4~ |
      dis'''2 b''4 fis'''4~ |
      fis'''2 cis'''4 fis'''4~ |
      fis'''4 cis'''4 fis'''4 cis'''4 |
      cis'''4 fis'''2 cis'''4~ |
      cis'''2 fis'''2~ |
      fis'''4 ais''2 fis''4~ |
      fis''4 ais''2 fis'''4~ |
      fis'''2 b'''4 dis'''4~ |
      dis'''4 b''4 fis''4 dis'''4~ |
      dis'''4 b''4 gis''4 dis''4~ |
      dis''2 gis''2~ |
      gis''1~ |
      gis''2 gis'''2~ |
      gis'''4 gis''2.~ |
      gis''4 cis''4 gis''4 cis'''4~ |
      cis'''1~ |
      cis'''4 ais'''2 fis'''4~ |
      fis'''4 cis'''4 fis'''2~ |
      fis'''4 ais''4 dis'''4 ais''4~ |
      ais''4 fis''4 ais''4 fis'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      cis'''4^\markup { \tiny \italic "Real answer" } eis'''4 gis'''4 ais'''4 |
      bis'''8 ais'''8 gis'''8 fis'''8 eis'''2 |
      fis'''4 dis'''4 cis'''2 |
      dis'''8^\markup { \tiny \italic "Countersubject" } eis'''8 fis'''4 eis'''4 fis'''4 |
      gis'''8 fis'''8 eis'''8 dis'''8 cis'''2 |
      dis'''4 b''4 ais''2 |
      ais''4 gis''4. fis''8 eis''4 |
      gis''1~ |
      gis''8 fis''4 gis''8 ais''2 |
      ais''1 |
      gis''2 cis''8 b'8 ais'4 |
      dis''2. ais'4 |
      ais'2 b'8 cis''8 dis''4 |
      cis''2~ cis''8 b'8 ais'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis'''4 ais''4 eis'''4 dis'''4 |
      gis''4 cis'''4. b''8 ais''4 |
      fis''4 gis''4 ais''4 dis'''4 |
      ais''4 eis''2 ais''4 |
      gis''2~ gis''8 fis''8 eis''4 |
      ais'4 dis''4 gis'4 cis''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4 cis'''4 fis''4 b''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''4 cis'''2 fis'''4~ |
      fis'''4 cis'''2 fis''4~ |
      fis''4 ais''2 dis'''4 |
      ais''2~ ais''8 gis''8 fis''4~ |
      fis''4 b''2 fis'''4~ |
      fis'''4 b''2. |
      fis''2. cis'''4~ |
      cis'''4 ais''2. |
      ais''8 gis''8 fis''2 cis'''4 |
      fis'''4 cis'''2 fis''4~ |
      fis''2 dis'''2~ |
      dis'''4 ais''4 fis''2~ |
      fis''4 dis''2 b''4~ |
      b''4 fis''4 dis''2~ |
      dis''4 gis''4 b''2~ |
      b''4 dis'''2 gis''4~ |
      gis''4 b'2. |
      gis''2. gis'4~ |
      gis'4 gis''2.~ |
      gis''4 cis'''2. |
      gis'''4 cis'''2.~ |
      cis'''4 fis''2 cis'''4~ |
      cis'''4 ais''4 cis'''4 fis''4~ |
      fis''4 ais''2 dis'''4~ |
      dis'''4 fis'''2 dis'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis''4^\markup { \tiny \italic "Real answer" } eis''4 gis''4 ais''4 |
      bis''8 ais''8 gis''8 fis''8 eis''2 |
      fis''4 dis''4 cis''2 |
      dis''8^\markup { \tiny \italic "Countersubject" } eis''8 fis''4 eis''4 fis''4 |
      gis''8 fis''8 eis''8 dis''8 cis''2 |
      dis''4 b'4 ais'2 |
      cis''2 dis''4 cis''4 |
      gis''1~ |
      gis''8 fis''4. gis''2 |
      dis''4 ais''4 cis''4 b'4 |
      cis''8 b'8 ais'4 cis''4 fis''4~ |
      fis''4 eis''4 dis''8 eis''8 fis''4 |
      dis''2. gis''4~ |
      gis''4 cis''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b''4^\markup { \tiny \italic "Related-key subject" } dis'''4 fis'''4 gis'''4 |
      ais'''8 gis'''8 fis'''8 e'''8 dis'''2 |
      e'''4 cis'''4 b''2 |
      gis''2 fis''2 |
      fis''4 eis''4 dis''4 cis''4 |
      fis''8 eis''8 dis''4 eis''4 gis''4 |
      fis''2 gis''2 |
      fis''4 cis''2 fis'4 |
      cis''4 eis''4 ais''4 cis'''4 |
      gis''8 ais''8 b''4 fis''2~ |
      fis''4 dis''4 gis'4 cis''4~ |
      cis''4 eis''8 fis''8 gis''2 |
      dis'''4 cis'''2 gis''4 |
      r1 |
      ais'8 b'8 cis''4 fis''4 ais''4~ |
      ais''4 fis''4 cis''4 fis''4~ |
      fis''4 dis''4 fis''2~ |
      fis''4 ais''4 fis''4 dis''4~ |
      dis''2 fis''2~ |
      fis''4 b''2 fis''4~ |
      fis''4 cis''4 fis''2 |
      ais''8 b''8 cis'''4 ais''4 cis'''4 |
      ais''4 cis''2. |
      ais'4 ais''4 cis'''2 |
      fis''8 gis''8 ais''2 dis''4~ |
      dis''1~ |
      dis''1~ |
      dis''2. fis''4 |
      b''1~ |
      b''2.~ b''8 ais''8 |
      gis''4 eis'''4 gis''4 b'4~ |
      b'1 |
      gis''1~ |
      gis''4 eis''2 gis''4~ |
      gis''4 eis''2. |
      fis''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } ais''2 |
      cis'''2 cis''2 |
      ais''2 fis''2 |
      dis''4 ais'2. |
      fis''2 cis''4 fis''4 |
      b'4 gis''4 eis'''4 cis'''4 |
      fis''4 b''4 fis''4 ais''4 |
      fis''4 dis''4 gis''4 cis''4~ |
      cis''4 fis''2 cis''4 |
      ais'4 cis''4 fis''4 ais''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis''4^\markup { \tiny \italic "Real answer" } eis''4 gis''4 ais''4 |
      bis''8 ais''8 gis''8 fis''8 eis''2 |
      fis''4 dis''4 cis''2 |
      dis''8^\markup { \tiny \italic "Countersubject" } eis''8 fis''4 eis''4 fis''4 |
      gis''8 fis''8 eis''8 dis''8 cis''2 |
      dis''4 b'4 ais'2 |
      cis''4. dis''8 eis''2 |
      dis''4 eis''4. dis''8 cis''4~ |
      cis''4 dis''4 eis''2~ |
      eis''8 dis''4. eis''4 fis''4 |
      gis''2 cis''4 b'4 |
      e'4 cis''4 dis''4 fis''4 |
      b'4 e''4 fis''8 e''8 dis''4 |
      dis''4 gis''4 cis''4 fis'4 |
      r1 |
      r1 |
      r1 |
      fis''2 cis''4 fis''4 |
      cis''2~ cis''8 b'8 ais'4 |
      gis'2 dis'4 fis'4 |
      ais'4 dis''4 gis''4 cis''4 |
      eis''2 gis'2 |
      ais'2. b'4 |
      r1 |
      cis''4. b'8 ais'4 fis'4 |
      ais'8 b'8 cis''4 fis''4 cis''4 |
      fis''4. eis''8 dis''4 fis''4 |
      dis''4. eis''8 fis''4 ais''4 |
      fis''8 eis''8 dis''4 b'4 fis'4 |
      b'4. cis''8 dis''4 b'4 |
      ais'4. gis'8 fis'4 ais'4~ |
      ais'2 cis''4 fis''4 |
      fis''2 cis''4 fis''4 |
      cis''2. fis''4~ |
      fis''2 dis''4 ais'4~ |
      ais'2 dis''2~ |
      dis''4 fis''4 dis''4 b'4 |
      dis''4. eis''8 fis''4 b''4~ |
      b''4 gis''4 dis''4 gis'4 |
      b'4. cis''8 dis''4 gis''4~ |
      gis''2 gis'2~ |
      gis'4 b'2 gis''4~ |
      gis''2 cis''4 gis''4 |
      cis''2. gis''4~ |
      gis''2 cis''2~ |
      cis''2 fis''4 ais''4 |
      fis''2 cis''4 ais'4~ |
      ais'2 fis''4 ais''4 |
      fis''2 dis''4 ais'4 |
      b'4 cis''4 gis'4 dis'4 |
      gis'4 cis''4 eis''2 |
      dis''2 ais'4 fis'4 |
      fis'2 cis''4 gis'4 |
      ais'2 cis''4 fis''4 |
      cis''2 ais'4 fis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key fis \major \time 4/4
      fis'4^\markup { \tiny \italic "Subject" } ais'4 cis''4 dis''4 |
      eis''8 dis''8 cis''8 b'8 ais'2 |
      b'4 gis'4 fis'2 |
      ais'8^\markup { \tiny \italic "Countersubject" } bis'8 cis''4 bis'4 cis''4 |
      dis''8 cis''8 bis'8 ais'8 gis'2 |
      ais'4 fis'4 eis'2 |
      fis'4. gis'8 ais'4 dis'4 |
      cis'2. fis'8 eis'8 |
      dis'4 b'8 cis''8 dis''2 |
      cis''4. dis''8 eis''2 |
      dis''4 gis'8 ais'8 bis'2 |
      dis''8 cis''8 bis'4 ais'2 |
      ais'1 |
      cis'4 gis'4 ais'8 gis'8 fis'4~ |
      fis'4 dis''2. |
      ais'8 gis'8 fis'4 dis'2 |
      eis'8 fis'8 gis'4 fis'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis''4 cis''4 ais'2 |
      cis''4 gis'4 ais'2 |
      dis''4. eis''8 fis''2 |
      eis''8 fis''8 gis''4 eis''4 cis''4 |
      gis'2 cis''2 |
      fis''2 cis''2 |
      r1 |
      dis''2 cis''4 gis'8 fis'8 |
      e'4 fis'8 gis'8 ais'2 |
      gis'4. ais'8 b'2 |
      b'4 cis''4 fis''2 |
      cis''2 dis''4 ais'8 gis'8 |
      fis'4 gis'8 ais'8 bis'2 |
      cis''8 bis'8 ais'4 cis''2 |
      ais'2 gis'8 ais'8 b'4 |
      gis'8 fis'8 eis'4 fis'2 |
      b'2 ais'2 |
      fis'2 gis'4 ais'4 |
      cis''2 b'2 |
      ais'4. b'8 cis''4 b'4 |
      r1 |
      ais'4. b'8 cis''4 ais'4 |
      fis'2 ais'2 |
      fis'4. gis'8 ais'2 |
      fis'4. gis'8 ais'2 |
      b'4. cis''8 dis''4 b'4 |
      fis'2 b'2 |
      cis''2~ cis''8 b'8 ais'4 |
      fis'4. gis'8 ais'2 |
      ais'8 b'8 cis''4 ais'2 |
      fis'4. gis'8 ais'4 fis'4 |
      ais'4. gis'8 fis'2 |
      dis'4. eis'8 fis'4 dis'4 |
      fis'4 b'4 dis''2 |
      b'4. cis''8 dis''4 b'4 |
      dis''2 b'2 |
      gis'2 b'2~ |
      b'4 gis'4 b'2 |
      gis'2 b'4 gis'4~ |
      gis'4 cis''2 gis'4~ |
      gis'2 cis''2 |
      gis'2 cis''2~ |
      cis''4 ais'4 fis'2 |
      ais'2 fis'2~ |
      fis'4 dis'4 fis'2 |
      ais'2 dis''2 |
      dis''4 cis''2 ais'4 |
      gis'2 ais'2 |
      dis''2 fis''2 |
      dis''2 cis''2 |
      fis'2 ais'2 |
      cis''4 ais'4 cis''2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'4^\markup { \tiny \italic "Subject" } ais'4 cis''4 dis''4 |
      eis''8 dis''8 cis''8 b'8 ais'2 |
      b'4 gis'4 fis'2 |
      ais'8^\markup { \tiny \italic "Countersubject" } bis'8 cis''4 bis'4 cis''4 |
      dis''8 cis''8 bis'8 ais'8 gis'2 |
      ais'4 fis'4 eis'2 |
      dis'2 cis'4 b4 |
      gis'4 ais'2. |
      gis'2 ais'2 |
      eis'2 dis'4 ais'4 |
      gis'4 dis'4 eis'2 |
      dis'2 eis'2 |
      fis'2 gis'4 fis'4 |
      cis'2 eis4 fis4~ |
      fis4 gis4 ais2 |
      ais4 dis'2. |
      cis'1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis'2 cis''4 dis''4 |
      cis''2 gis'8 fis'8 eis'4 |
      fis'4 dis''4 gis'4 eis'4 |
      cis'4 dis'4 eis'8 fis'8 gis'4 |
      dis'8 eis'8 fis'4 gis'4 b4 |
      cis'2 fis'2 |
      b4. cis'8 dis'4 dis''4 |
      ais'8 gis'8 fis'4 cis'2~ |
      cis'2 dis'4 eis'4 |
      fis'2. eis'4 |
      r1 |
      cis''1~ |
      cis''2 ais''2~ |
      ais''4 dis''4 ais'2 |
      dis''4 ais'4 dis'4 ais4 |
      dis'2. fis'4~ |
      fis'4 dis'4 fis'2 |
      ais'2 cis''2 |
      ais'1 |
      ais'4. gis'8 fis'4 ais'4 |
      cis''8 b'8 ais'4 fis'4 ais'4 |
      fis'4 dis'4 fis'4 dis'4 |
      fis'4. eis'8 dis'4 fis'4 |
      dis'4. eis'8 fis'4 b'4 |
      fis'8 eis'8 dis'4 b4 dis'4~ |
      dis'2 gis'4 b'4~ |
      b'2 gis'4 b'4~ |
      b'2 gis'4 b'4~ |
      b'2 gis'2~ |
      gis'4 cis'4 gis'4 cis''4~ |
      cis''2 gis'4 cis'4~ |
      cis'2 gis'4 cis'4~ |
      cis'2 ais4 cis'4 |
      fis'2 ais'4 fis'4~ |
      fis'2 dis'4 fis'4~ |
      fis'4 dis'4 fis'4 ais'4 |
      fis'4^\markup { \tiny \italic "Subject" } ais'4 cis''4 dis''4 |
      eis''8 dis''8 cis''8 b'8 ais'2 |
      b'4 gis'4 fis'2 |
      fis'2 gis'2 |
      fis'1 |
      fis'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'4^\markup { \tiny \italic "Subject" } ais'4 cis''4 dis''4 |
      eis''8 dis''8 cis''8 b'8 ais'2 |
      b'4 gis'4 fis'2 |
      ais8^\markup { \tiny \italic "Countersubject" } bis8 cis'4 bis4 cis'4 |
      dis'8 cis'8 bis8 ais8 gis2 |
      ais4 fis4 eis2 |
      fis4. gis8 ais4 dis'4~ |
      dis'8 cis'2.~ cis'8 |
      b2 dis'2 |
      eis'1 |
      gis'2 cis'2~ |
      cis'4 bis4 cis'2 |
      dis'2 cis'2 |
      b8 ais8 gis4 cis'4 gis'4 |
      cis'4 fis'4. e'8 dis'4 |
      b8 ais8 gis4 fis4 b4 |
      b4 e'8 dis'8 cis'4 fis'4 |
      fis'4 ais4 dis4 ais4 |
      dis'4 gis'2. |
      cis'4 fis'4 cis'8 dis'8 eis'4 |
      dis'4 cis'2 b4 |
      gis'4 ais'2 fis'4 |
      dis'4 gis4 ais4 dis'4 |
      cis'8 b8 ais4 cis'8 dis'8 eis'4 |
      cis'8 b8 ais4 gis4 b4 |
      dis'8 eis'8 fis'2 b'4 |
      r1 |
      cis'4 ais2 cis'4 |
      fis'4 ais'2 fis'4 |
      dis'8 eis'8 fis'2 dis'4 |
      fis'4 dis'2 fis'4 |
      dis'4 b2 dis'4 |
      b8 cis'8 dis'2 fis'4 |
      cis'4 ais2 cis'4 |
      fis'8 gis'8 ais'2 fis'4 |
      fis'4 cis'2 ais4~ |
      ais4 cis'2 ais4~ |
      ais4 fis2 ais4 |
      dis'8 eis'8 fis'4 ais'4 dis'4~ |
      dis'4 b2 dis'4 |
      fis'2. b4~ |
      b4 dis'2 b4 |
      dis'4 b2 gis4~ |
      gis4 b2 gis'4 |
      b'4 gis'2. |
      gis1 |
      cis'2. gis4~ |
      gis4 cis'2.~ |
      cis'4 fis'2 cis'4 |
      ais4 cis'2 fis'4 |
      ais'4 fis'2 dis'4 |
      ais4 dis'2 fis'4 |
      b4 fis4 gis4 ais4 |
      b4 gis4 cis'4 ais4 |
      fis4 gis4 ais4 cis'4 |
      dis'4 b4 gis4 cis'4 |
      fis'4 cis'2 ais4 |
      fis4 ais2 cis'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "bass" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'4^\markup { \tiny \italic "Real answer" } eis'4 gis'4 ais'4 |
      bis'8 ais'8 gis'8 fis'8 eis'2 |
      fis'4 dis'4 cis'2 |
      dis'8^\markup { \tiny \italic "Countersubject" } eis'8 fis'4 eis'4 fis'4 |
      gis'8 fis'8 eis'8 dis'8 cis'2 |
      dis'4 b4 ais2 |
      fis2 gis8 ais8 b4 |
      cis'1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ais8 b8 cis'2 fis'4 |
      cis'2~ cis'8 dis'8 eis'4 |
      fis'8 eis'8 dis'2 fis'4 |
      cis'4 gis8 ais8 bis4 ais4 |
      dis'4 gis2 cis'4~ |
      cis'4 fis4 gis8 fis8 eis4 |
      r1 |
      b2 cis'4 dis'4 |
      e'8 dis'8 cis'4 ais2 |
      b4 cis'4 dis'2 |
      dis'4 cis'2 b4 |
      ais2 dis'4 eis'4 |
      dis'4. cis'8 bis2 |
      ais2 gis2 |
      ais8 b8 cis'4 gis4 fis4 |
      gis4 cis'2. |
      dis'4 b4 dis4 ais,4~ |
      ais,4 fis4 cis'4 eis4~ |
      eis4 ais4 dis'4 b4 |
      fis4 cis'2 gis'4 |
      r1 |
      ais4 fis2 cis4~ |
      cis4 fis2 ais4~ |
      ais4 fis2 ais4~ |
      ais4 fis2. |
      b4 fis2 b4~ |
      b4 fis2 dis4 |
      fis4 ais2 fis4~ |
      fis4 cis'2 ais4 |
      cis'4 ais4 cis'2~ |
      cis'2 ais2~ |
      ais2 fis'2 |
      ais4 fis2 ais4 |
      b8 cis'8 dis'4 fis4 dis4~ |
      dis4 fis4 b2 |
      dis1 |
      b,2. gis4 |
      b2. gis4~ |
      gis2 eis2~ |
      eis4 gis4 cis'2 |
      gis2 cis2 |
      eis4 gis2. |
      cis2 ais2~ |
      ais1~ |
      ais1~ |
      ais2. fis4 |
      fis4 cis4 gis4 dis'4 |
      gis4 cis2 eis4 |
      fis4 dis4 cis4 fis4 |
      b4 dis'4 gis2 |
      cis'4 ais2 cis'4~ |
      cis'4 fis'4 cis'4 ais4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis4^\markup { \tiny \italic "Real answer" } eis4 gis4 ais4 |
      bis8 ais8 gis8 fis8 eis2 |
      fis4 dis4 cis2 |
      dis8^\markup { \tiny \italic "Countersubject" } eis8 fis4 eis4 fis4 |
      gis8 fis8 eis8 dis8 cis2 |
      dis4 b,4 ais,2 |
      ais,4 fis4 gis2~ |
      gis2 fis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ais4 cis4 gis4 dis4 |
      gis4 cis2. |
      b,2 fis2~ |
      fis4 ais4 cis4 ais4 |
      eis8 dis8 cis4 gis4 b,4 |
      fis4 cis4 fis4 b,4 |
      r1 |
      fis4 ais2. |
      cis'4 ais2 cis'4 |
      ais4 dis'2 ais4 |
      dis4 fis4 dis2~ |
      dis4 fis2. |
      dis8 cis8 b,2 dis4 |
      ais4 fis2. |
      cis4 fis2 ais4 |
      fis4 ais2 fis4 |
      ais8 gis8 fis2. |
      ais,4 dis2 fis4~ |
      fis4 dis4 ais,4 dis4~ |
      dis4 b2 fis4 |
      b,4 dis2. |
      b2. dis'4 |
      gis4 dis2 b,4~ |
      b,4 gis2. |
      b,2 gis2~ |
      gis2. cis4~ |
      cis4 gis2. |
      cis'1 |
      cis2. fis4 |
      cis4 fis2 ais4~ |
      ais4 dis2. |
      fis4 ais2 dis'4 |
      r1 |
      r1 |
      r1 |
      dis4 fis4 cis4 gis4 |
      cis2 fis2 |
      ais4 fis4 ais2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis4^\markup { \tiny \italic "Real answer" } eis4 gis4 ais4 |
      bis8 ais8 gis8 fis8 eis2 |
      fis4 dis4 cis2 |
      fis,4 gis,4 cis8 b,8 ais,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis4 cis2. |
      ais,2 fis,2 |
      ais,2 fis,2 |
      ais,4 dis4 ais,2 |
      dis,4 b,2. |
      dis1 |
      ais,4 cis4 ais2~ |
      ais4 fis4 cis2 |
      cis2 fis2~ |
      fis4 ais4 ais,2~ |
      ais,2 dis2 |
      ais,4 dis2. |
      fis,4 dis4 b,2~ |
      b,4 fis4 b,2~ |
      b,2 dis2~ |
      dis2 b,2~ |
      b,2 gis2~ |
      gis2 gis,2~ |
      gis,2 gis2~ |
      gis4 gis,2. |
      cis,2 cis2~ |
      cis2 fis,2~ |
      fis,4 ais,4 fis2 |
      ais,4 dis4 ais,2 |
      dis4 ais4 fis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,4^\markup { \tiny \italic "Subject" } ais,4 cis4 dis4 |
      eis8 dis8 cis8 b,8 ais,2 |
      b,4 gis,4 fis,2 |
      dis,4 dis4 gis,2 |
      cis,8 dis,8 eis,4 fis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      ais,2 fis,2 |
      cis2 ais,2~ |
      ais,2 fis2 |
      ais,2 dis2 |
      fis,2 dis,2 |
      fis,2 dis2 |
      fis,2 ais,2~ |
      ais,2 fis,2 |
      fis,2 cis2~ |
      cis4 fis4 cis2 |
      dis2 fis,2 |
      ais,2 fis2 |
      b,2 fis,2 |
      b,2. fis,4 |
      gis,2 dis2 |
      gis2 dis2 |
      gis,1 |
      gis2 b,2 |
      cis2 gis,2~ |
      gis,4 gis2. |
      gis,1 |
      ais,4 cis2. |
      fis,2 cis2 |
      dis4 ais,2. |
      dis,2 ais,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key fis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,4^\markup { \tiny \italic "Subject" } ais,4 cis4 dis4 |
      eis8 dis8 cis8 b,8 ais,2 |
      b,4 gis,4 fis,2 |
      fis,8 eis,8 dis,4 b,,2 |
      cis,8 dis,8 eis,4 fis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,8^\markup { \tiny \italic "Countersubject" } ais,8 b,4 ais,4 b,4 |
      cis8 b,8 ais,8 gis,8 fis,2 |
      gis,4 e,4 dis,2 |
      gis,8 fis,8 e,4 fis,8 e,8 dis,4 |
      ais,8^\markup { \tiny \italic "Countersubject" } bis,8 cis4 bis,4 cis4 |
      dis8 cis8 bis,8 ais,8 gis,2 |
      ais,4 fis,4 eis,2 |
      fis,4^\markup { \tiny \italic "Stretto subject" } ais,4 cis4 dis4 |
      eis8 dis8 cis8 b,8 ais,2 |
      b,4 gis,4 fis,2 |
      fis,4 dis4 cis4 ais,4~ |
      ais,4 cis4 gis,2 |
      dis,4 ais,,8 gis,,8 fis,,4 gis,,4 |
      r1 |
      fis,1~ |
      fis,1~ |
      fis,1~ |
      fis,1 |
      b,,1~ |
      b,,1 |
      fis,1~ |
      fis,1 |
      fis,1~ |
      fis,1 |
      dis,1~ |
      dis,1 |
      b,,1~ |
      b,,2.~ b,,8 ais,,8 |
      gis,,1~ |
      gis,,1~ |
      gis,,1~ |
      gis,,1 |
      cis,1~ |
      cis,1~ |
      cis,1 |
      fis,1~ |
      fis,1 |
      dis,1~ |
      dis,1 |
      dis,8^\markup { \tiny \italic "Countersubject" } eis,8 fis,4 eis,4 fis,4 |
      gis,8 fis,8 eis,8 dis,8 cis,2 |
      dis,4 b,,4 ais,,2 |
      dis,2 eis,2 |
      fis,1 |
      fis,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
