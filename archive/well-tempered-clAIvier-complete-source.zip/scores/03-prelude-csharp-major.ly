\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "III. Prelude in C-sharp major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key cis \major \time 12/8
      \tempo "Moderato, luminoso" 4 = 96
      \mark \markup \box \small "Opening cell" gis''8.\p r8. cis''8 r4. cis'''4 r8 eis''8. r16 |
      gis''8. r8. cis''8 r4. cis'''4 r8 eis''8. r16 |
      eis''8. r8. ais'8 r4. ais''4 r8 cis''8. r16 |
      gis''8. r8. bis'8 r4. bis'4 r8 eis'8. r16 |
      cis''8. r8. fis'8 r4. fis''4 r8 ais'8. r16 |
      gis''8. r8. cis''8 r4. cis'''4 r8 eis''8. r16 |
      dis'''8. r8. fis''8 r4. fis'''4 r8 ais''8. r16 |
      dis''8. r8. gis'8 r4. gis''4 r8 bis'8. r16 |
      \mark \markup \box \small "Contrasting span" eis''8.\mp r8. gis'8 r4. gis''4 r8 bis'8. r16 |
      eis''8. r8. gisis'8 r4. gisis''4 r8 bis'8. r16 |
      ais''8. r8. cis''8 r4. cis'''4 r8 eis''8. r16 |
      cis''8. r8. fis'8 r4. fis''4 r8 ais'8. r16 |
      ais'8. r8. fis''8 r4. fis'4 r8 dis''8. r16 |
      ais'8. r8. fisis''8 r4. fisis'4 r8 dis''8. r16 |
      dis''8. r8. bis''8 r4. bis'4 r8 gis''8. r16 |
      gis'8. r8. dis''8 r4. dis''4 r8 bis''8. r16 |
      \mark \markup \box \small "Return" gis''8.\mp r8. eis'''8 r4. eis''4 r8 cis'''8. r16 |
      cis'''8. r8. ais'''8 r4. ais''4 r8 fis'''8. r16 |
      cis'''8. r8. fis''8 r4. fis'''4 r8 a''8. r16 |
      eis'''8. r8. gis''8 r4. gis''4 r8 cis''8. r16 |
      \mark \markup \box \small "Cadence" ais''8.\p r8. dis''8 r4. dis'''4 r8 fis''8. r16 |
      gis''8. r8. cis''8 r4. cis'''4 r8 eis''8. r16 |
      dis''8. r8. gis'8 r4. gis''4 r8 bis'8. r16 |
      cis''1~ cis''2 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key cis \major \time 12/8
      r8 eis'4 r4 gis'8. r4 r16 cis'8. r8. |
      r8 eis'4 r4 gis'8. r4 r16 cis'8. r8. |
      r8 cis'4 r4 eis'8. r4 r16 ais8. r8. |
      r8 gis4 r4 bis8. r4 r16 eis8. r8. |
      r8 ais4 r4 cis'8. r4 r16 fis8. r8. |
      r8 eis'4 r4 gis'8. r4 r16 cis'8. r8. |
      r8 fis'4 r4 ais'8. r4 r16 dis'8. r8. |
      r8 bis4 r4 dis'8. r4 r16 gis8. r8. |
      r8 gis4 r4 bis8. r4 r16 eis8. r8. |
      r8 gisis4 r4 bis8. r4 r16 eis8. r8. |
      r8 cis'4 r4 eis'8. r4 r16 ais8. r8. |
      r8 ais4 r4 cis'8. r4 r16 fis8. r8. |
      r8 fis'4 r4 ais'8. r4 r16 dis'8. r8. |
      r8 fisis'4 r4 ais'8. r4 r16 dis'8. r8. |
      r8 bis4 r4 dis'8. r4 r16 gis8. r8. |
      r8 bis4 r4 dis'8. r4 r16 gis8. r8. |
      r8 eis'4 r4 gis'8. r4 r16 cis'8. r8. |
      r8 ais'4 r4 cis''8. r4 r16 fis'8. r8. |
      r8 a'4 r4 cis''8. r4 r16 fis'8. r8. |
      r8 eis''4 r4 gis''8. r4 r16 cis''8. r8. |
      r8 fis'4 r4 ais'8. r4 r16 dis'8. r8. |
      r8 eis'4 r4 gis'8. r4 r16 cis'8. r8. |
      r8 bis4 r4 dis'8. r4 r16 gis8. r8. |
      gis1~ gis2 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key cis \major \time 12/8
      r4 gis4~ gis16 r4. r16 eis4~ eis16 r8. |
      r4 gis4~ gis16 r4. r16 eis4~ eis16 r8. |
      r4 eis4~ eis16 r4. r16 cis4~ cis16 r8. |
      r4 bis,4~ bis,16 r4. r16 gis,4~ gis,16 r8. |
      r4 ais,4~ ais,16 r4. r16 cis4~ cis16 r8. |
      r4 eis4~ eis16 r4. r16 gis4~ gis16 r8. |
      r4 ais4~ ais16 r4. r16 fis4~ fis16 r8. |
      r4 dis4~ dis16 r4. r16 bis,4~ bis,16 r8. |
      r4 bis,4~ bis,16 r4. r16 gis,4~ gis,16 r8. |
      r4 bis,4~ bis,16 r4. r16 bis,4~ bis,16 r8. |
      r4 eis4~ eis16 r4. r16 cis4~ cis16 r8. |
      r4 cis4~ cis16 r4. r16 cis4~ cis16 r8. |
      r4 fis4~ fis16 r4. r16 fis4~ fis16 r8. |
      r4 ais4~ ais16 r4. r16 fisis4~ fisis16 r8. |
      r4 dis4~ dis16 r4. r16 dis4~ dis16 r8. |
      r4 dis4~ dis16 r4. r16 dis4~ dis16 r8. |
      r4 eis4~ eis16 r4. r16 gis4~ gis16 r8. |
      r4 ais4~ ais16 r4. r16 ais4~ ais16 r8. |
      r4 cis'4~ cis'16 r4. r16 cis'4~ cis'16 r8. |
      r4 eis'4~ eis'16 r4. r16 cis'4~ cis'16 r8. |
      r4 ais4~ ais16 r4. r16 fis4~ fis16 r8. |
      r4 gis4~ gis16 r4. r16 eis4~ eis16 r8. |
      r4 dis4~ dis16 r4. r16 fis4~ fis16 r8. |
      eis1~ eis2 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key cis \major \time 12/8
      cis,1~\p cis,2 |
      eis,1~ eis,2 |
      ais,,1~ ais,,2 |
      eis,,1~ eis,,2 |
      fis,,1~ fis,,2 |
      eis,,1~ eis,,2 |
      fis,,1~ fis,,2 |
      gis,,1~ gis,,2 |
      eis,,1~\mp eis,,2 |
      eis,,1~ eis,,2 |
      ais,,1~ ais,,2 |
      fis,,1~ fis,,2 |
      fis,,1~ fis,,2 |
      dis,,1~ dis,,2 |
      gis,,1~ gis,,2 |
      gis,,1~ gis,,2 |
      cis,1~\mp cis,2 |
      fis,,1~ fis,,2 |
      fis,,1~ fis,,2 |
      eis,,1~ eis,,2 |
      fis,,1~\p fis,,2 |
      gis,,1~ gis,,2 |
      gis,,1~ gis,,2 |
      cis,1~ cis,2 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
