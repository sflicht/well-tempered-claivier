\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "IX. Fugue in E major — The returning light"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a3")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key e \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 108
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis'''2 a'''2 |
      e'''4^\markup { \tiny \italic "Subject" } b'''4 dis''''4 e''''8 dis''''8 |
      cis''''4 b'''8 a'''8 gis'''2 |
      fis'''2 e'''2 |
      gis'''4^\markup { \tiny \italic "Countersubject" } ais'''8 b'''8 cis''''4 dis''''8 cis''''8 |
      b'''4 ais'''4 b'''4. cis''''16 b'''16 |
      ais'''2 gis'''2 |
      cis''''4 b'''4 fis'''4 e'''4~ |
      e'''4 b'''2.~ |
      b'''8 a'''4. gis'''2 |
      \mark \markup \box \small "Sequential episode" cis''''2 dis''''4 e''''4 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'''4 fis'''4 b'''2 |
      a'''8 gis'''8 fis'''4 e'''4 b''4~ |
      b''8 a''4. e'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" gis'''4 cis''''2 b'''4~ |
      b'''4 fis'''2.~ |
      fis'''2 e'''4. fis'''8 |
      \mark \markup \box \small "Linking episode" gis'''2 fis'''4. gis'''8 |
      \mark \markup \box \small "Development" a'''4^\markup { \tiny \italic "Related-key subject" } e''''4 gis''''4 a''''8 gis''''8 |
      fis''''4 e''''8 d''''8 cis''''2 |
      b'''2 a'''2 |
      a'''4 b'''4 a'''4 gis'''4~ |
      gis'''8 a'''8 b'''2.~ |
      b'''2 a'''2 |
      \mark \markup \box \small "Stretto" cis'''4 b''2. |
      e'''8 fis'''8 gis'''2 dis'''4~ |
      dis'''2 e'''4^\markup { \tiny \italic "Stretto subject" } b'''4 |
      dis''''4 e''''8 dis''''8 cis''''4 b'''8 a'''8 |
      gis'''2 fis'''2 |
      e'''2 e'''4 b''4 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" gis'''4. a'''8 b'''2 |
      gis'''1~ |
      gis'''1~ |
      gis'''1 |
      cis''''1~ |
      cis''''1 |
      b'''2 gis''''4 gis'''4~ |
      gis'''4 b'''8 a'''8 gis'''2 |
      \mark \markup \box \small "Gathered development" e'''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } b'''2 |
      cis''''8 dis''''8 e''''4 gis''''4 e''''4~ |
      e''''2 cis''''4 a'''4~ |
      a'''4 cis''''4 a''''4 cis''''4 |
      dis''''2 dis'''2 |
      dis''''8 e''''8 fis''''4 fis'''2~ |
      fis'''4 dis''''4 fis''''2 |
      b'''4. a'''8 gis'''2 |
      e'''4. fis'''8 gis'''2 |
      \mark \markup \box \small "Final return" gis'''4 fis'''8 gis'''8 a'''4 gis'''4~ |
      gis'''4 b'''2.~ |
      b'''2 a'''2 |
      \mark \markup \box \small "Final cadence" a'''2 b'''2 |
      gis'''1 |
      gis'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'''4^\markup { \tiny \italic "Subject" } b'''4 dis''''4 e''''8 dis''''8 |
      cis''''4 b'''8 a'''8 gis'''2 |
      fis'''2 e'''2 |
      gis''4^\markup { \tiny \italic "Countersubject" } ais''8 b''8 cis'''4 dis'''8 cis'''8 |
      b''4 ais''4 b''4. cis'''16 b''16 |
      ais''2 gis''2 |
      gis''4. a''8 b''4 gis''4~ |
      gis''2 e''2 |
      a''4. b''8 cis'''2 |
      cis'''2. fis'''4~ |
      fis'''2 b''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'''8 fis'''8 gis'''4 e'''2~ |
      e'''4 gis'''4 e'''2 |
      cis'''8 dis'''8 e'''4 cis'''2~ |
      cis'''4 e'''2 gis'''4 |
      e'''4. dis'''8 cis'''2 |
      e'''4 a'''2. |
      e'''2 b''2 |
      e'''8 fis'''8 gis'''2. |
      b''4 e'''4 gis''2~ |
      gis''4 e''4 e'''2~ |
      e'''4 a''4 cis'''2~ |
      cis'''4 fis'''2.~ |
      fis'''2 fis''2~ |
      fis''2 fis'''2~ |
      fis'''4 b''2.~ |
      b''4 gis'''4 e'''2~ |
      e'''2 gis''2 |
      r1 |
      r1 |
      r1 |
      e'''4 a''4 fis'''4 b''4~ |
      b''2 gis'''4 e'''4 |
      b''4 e'''4 b''2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      b''4^\markup { \tiny \italic "Real answer" } fis'''4 ais'''4 b'''8 ais'''8 |
      gis'''4 fis'''8 e'''8 dis'''2 |
      cis'''2 b''2 |
      b''2 a''2 |
      cis''4^\markup { \tiny \italic "Countersubject" } dis''8 e''8 fis''4 gis''8 fis''8 |
      e''4 dis''4 e''4. fis''16 e''16 |
      dis''2 cis''2 |
      gis''4 fis''4 cis''4 b'8 cis''8 |
      dis''4. e''8 fis''2~ |
      fis''8 e''4. dis''2 |
      e''4 fis''2 cis''8 dis''8 |
      e''4 fis''4 gis''8 a''8 b''4 |
      fis''2 cis''4. dis''8 |
      e''4 fis''2 gis''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''4 b''4 fis''4 e''4~ |
      e''4 b'4 gis''8 a''8 b''4 |
      fis''8 gis''8 a''4 cis'''4 e'''4 |
      r1 |
      r1 |
      r1 |
      e''4 dis''4 b'4 cis''4~ |
      cis''4 dis''8 cis''8 b'2 |
      fis''2 cis'''4 gis''4 |
      r1 |
      r1 |
      dis'''8 e'''8 fis'''4 cis'''4 fis''4 |
      dis''8 e''8 fis''4 b''8 cis'''8 dis'''4 |
      fis'''4 cis'''8 dis'''8 e'''4 b''4 |
      gis''4 cis'''2 fis''4 |
      fis''4 e''4 b''4 e''4 |
      fis''4 b''4 e''4 a''4 |
      e'''4 b''4 fis'''4 a'''4 |
      a'''4 fis'''4 a''4 e''4~ |
      e''4 fis''4 e''2 |
      fis''4 b''4 e'''8 dis'''8 cis'''4 |
      gis''8 a''8 b''4 fis''4 b''4 |
      cis'''4 gis''8 a''8 b''4 dis'''4 |
      fis''2 cis''4 b'4~ |
      b'2 e''4 gis''4 |
      dis'''4 e'''8 dis'''8 cis'''4 a''4~ |
      a''4 e''4 a''4 gis''4 |
      r1 |
      b''4 gis''2 e''4~ |
      e''4 b'4 e''4 gis''4~ |
      gis''4 e''4 gis''4 e''4~ |
      e''4 gis''2 cis'''4~ |
      cis'''2 e'''4 cis'''4 |
      a''4 e''4 cis''4 e''4~ |
      e''4 gis''2 e''4~ |
      e''4 b'4 e''4 gis''4 |
      gis''8 fis''8 e''4 gis''2 |
      e''8 dis''8 cis''4 gis''4 cis'''4~ |
      cis'''4 e'''2 cis'''4 |
      a''4. gis''8 fis''2~ |
      fis''4 a'4 fis''2~ |
      fis''4 b'4 fis''4 b''4~ |
      b''4 fis''4 b''2~ |
      b''4 e''4 gis''2~ |
      gis''4 cis'''4 gis''4 cis'''4 |
      cis'''4 fis'''4 a''4 e''4~ |
      e''4 b'4 e''4 b''4~ |
      b''4 fis'''4 cis'''4 e'''4 |
      cis'''4 e'''4 b''2 |
      e'''4 b''4 gis''4 b''4~ |
      b''4 gis''4 b''4 e'''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b'4^\markup { \tiny \italic "Real answer" } fis''4 ais''4 b''8 ais''8 |
      gis''4 fis''8 e''8 dis''2 |
      cis''2 b'2 |
      cis''4^\markup { \tiny \italic "Countersubject" } dis''8 e''8 fis''4 gis''8 fis''8 |
      e''4 dis''4 e''4. fis''16 e''16 |
      dis''2 cis''2 |
      dis''4 cis''2 b'8 cis''8 |
      dis''2 fis'4 b'4 |
      cis''2 dis''2 |
      gis'2 fis'4 cis''4 |
      gis'1 |
      a'2 e'2 |
      e'2 cis''4 fis'4~ |
      fis'2 e'2 |
      b'4^\markup { \tiny \italic "Related-key subject" } fis''4 ais''4 b''8 ais''8 |
      gis''4 fis''8 e''8 dis''2 |
      cis''2 b'2 |
      b'4 cis''2 b'4 |
      cis''4 b'2 e''4 |
      a''4 e''4. d''8 cis''4 |
      e''4. d''8 cis''4 d''4 |
      e''4^\markup { \tiny \italic "Related-key subject" } b''4 dis'''4 e'''8 dis'''8 |
      cis'''4 b''8 a''8 gis''2 |
      fis''2 e''2 |
      e''4 fis''2 e''4~ |
      e''4 b'2. |
      fis'2 cis''4 e''4 |
      fis''4 e''2 b'4~ |
      b'4 gis'4 cis''4 fis''4 |
      cis''8 dis''8 e''4 cis''4 dis''4 |
      r1 |
      b'4 e''2 gis''4~ |
      gis''4 e''2 b'4 |
      gis'4 cis''2 e''4~ |
      e''4 cis''2 e''4~ |
      e''4 cis''2 e''4~ |
      e''4 cis''2 a'4 |
      gis'8 a'8 b'4 e''4 gis''4~ |
      gis''4 e''2 b'4 |
      b'2 e''2 |
      gis'2. gis''4 |
      cis''4. dis''8 e''2 |
      fis''2~ fis''8 gis''8 a''4 |
      a'8 gis'8 fis'2 a'4 |
      b'4. cis''8 dis''2 |
      fis''4. e''8 dis''2 |
      e''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } b''2 |
      e''4 gis'4 e'2 |
      e'4 fis'2 b'4 |
      cis''4 fis''4 e''4 b'4~ |
      b'2 e''4 a''4 |
      e''4 cis''4 fis''2 |
      gis''4 e''2 gis''4~ |
      gis''4 b''2 gis''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key e \major \time 4/4
      e'4^\markup { \tiny \italic "Subject" } b'4 dis''4 e''8 dis''8 |
      cis''4 b'8 a'8 gis'2 |
      fis'2 e'2 |
      gis'4^\markup { \tiny \italic "Countersubject" } ais'8 b'8 cis''4 dis''8 cis''8 |
      b'4 ais'4 b'4. cis''16 b'16 |
      ais'2 gis'2 |
      gis'8 a'8 b'4 cis''2~ |
      cis''4 b'4. a'8 gis'4 |
      a'4 b'4 e'2 |
      fis'4. gis'8 a'2 |
      b'4 cis''4 fis''8 e''8 dis''4~ |
      dis''2 b'2 |
      cis''2 gis'2 |
      gis'4 b'4. a'8 gis'4 |
      cis''4 fis''4 e''2 |
      a'2 e'4. fis'8 |
      gis'4 fis'4 b'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      dis'4 cis'4 fis'4 b'4 |
      fis'4 b'8 cis''8 d''4 a'4~ |
      a'4 b'4 cis''8 b'8 a'4 |
      e'2 a'8 gis'8 fis'4 |
      e'4 fis'8 gis'8 a'4 b'4 |
      gis'4 fis'4 gis'8 a'8 b'4~ |
      b'2 cis''4 a'4 |
      gis'4 fis'4 b'4 gis'4~ |
      gis'4 b'2 gis'4 |
      a'8 gis'8 fis'4 gis'4 b'4~ |
      b'2 cis''4 gis'4~ |
      gis'4 e'4 fis'4 a'4~ |
      a'4 cis''8 dis''8 e''4 dis''4 |
      r1 |
      gis'4 e'4 gis'4 b'4~ |
      b'4 gis'4 b'4 gis'4 |
      e'8 dis'8 cis'4 e'4 gis'4~ |
      gis'4 cis''4 e''4 cis''4~ |
      cis''4 a'4 cis''4 a'4~ |
      a'4 cis''4 e''4 cis''4 |
      gis'8 fis'8 e'4 gis'4 b'4~ |
      b'4 e''4 gis''4 e''4 |
      b'8 a'8 gis'4 b'4 gis'4~ |
      gis'4 cis''4 e''4 cis''4~ |
      cis''4 a'4 e'4 a'4~ |
      a'4 fis'4 a'4 fis'4~ |
      fis'2 a'4 fis'4~ |
      fis'4 b'2 fis'4~ |
      fis'4 b'4 fis'4 b'4~ |
      b'4 gis'2 e'4~ |
      e'4 cis'4 e'4 gis'4 |
      gis'8 a'8 b'4 a'4 b'4 |
      gis'4 fis'4 gis'8 a'8 b'4~ |
      b'4 fis'4 a'4 cis''4 |
      cis''4 a'4 fis'4 b'4~ |
      b'4 gis'4 b'4 gis'4~ |
      gis'4 e'4 gis'4 b'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4^\markup { \tiny \italic "Subject" } b'4 dis''4 e''8 dis''8 |
      cis''4 b'8 a'8 gis'2 |
      fis'2 e'2 |
      gis4^\markup { \tiny \italic "Countersubject" } ais8 b8 cis'4 dis'8 cis'8 |
      b4 ais4 b4. cis'16 b16 |
      ais2 gis2 |
      cis'4 b4. a8 gis4 |
      a4 b4 e'2 |
      fis'4. gis'8 a'2 |
      b'4 fis'4. e'8 dis'4~ |
      dis'4 ais4 dis'2 |
      e'8 dis'8 cis'4 gis2 |
      gis8 a8 b4 fis'4 cis'4 |
      e'4 gis'2 e'4 |
      fis'4 a4 gis2 |
      gis2 a4. gis8 |
      fis2 gis2 |
      gis4 fis4 e4 fis4 |
      b4 cis'4 dis'4 fis'4 |
      cis'2 gis4 b4 |
      dis'4 e'8 dis'8 cis'4 dis'4 |
      cis'8 d'8 e'4 d'4 e'4 |
      cis'4 e'4 a'2 |
      b'2 fis'4 d'4 |
      cis'4 b4 fis4 b4 |
      cis'4 fis'4 b'8 a'8 gis'4 |
      b'4 fis'4 cis'4 e'4 |
      e'4 dis'8 e'8 fis'4 gis'4~ |
      gis'2 e'4 b4 |
      a2 cis'4 gis'4 |
      b'4 e'4 gis'2 |
      b'2 a'4 cis''4~ |
      cis''4 gis'4 cis'4 gis4 |
      r1 |
      b'2 gis'2 |
      b'1 |
      cis''2 cis'2~ |
      cis'2. cis''4 |
      e'1~ |
      e'1 |
      gis2 b4 b'4~ |
      b'4 gis'4 b'2 |
      b'2 gis'4 e'4~ |
      e'2 cis'4 e'4 |
      cis'4. b8 a4 cis'4~ |
      cis'2 fis'2 |
      a'4. gis'8 fis'2~ |
      fis'2 b'2 |
      fis'2. b4~ |
      b2 e'4 gis'4~ |
      gis'4 e'4 cis'4 e'4 |
      e'4^\markup { \tiny \italic "Subject" } b'4 dis''4 e''8 dis''8 |
      cis''4 b'8 a'8 gis'2 |
      fis'2 e'2 |
      e'2 fis'2 |
      e'2. b4 |
      b1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "bass" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b4^\markup { \tiny \italic "Real answer" } fis'4 ais'4 b'8 ais'8 |
      gis'4 fis'8 e'8 dis'2 |
      cis'2 b2 |
      cis'4^\markup { \tiny \italic "Countersubject" } dis'8 e'8 fis'4 gis'8 fis'8 |
      e'4 dis'4 e'4. fis'16 e'16 |
      dis'2 cis'2 |
      cis'2 b2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4 b2. |
      cis'4 fis'4 gis'2 |
      a'1~ |
      a'8 gis'8 cis'4 fis'2 |
      b4 fis4 b2 |
      e'2 dis'2 |
      cis'4 b4 fis4 e4 |
      gis4. a8 b2 |
      a8 gis8 fis4 gis2 |
      r1 |
      r1 |
      b4 cis'8 dis'8 e'4 dis'4~ |
      dis'4 cis'4 b2 |
      cis'4 fis4 gis2 |
      gis2 ais4 b4 |
      a4 b2 a4 |
      cis'4 b4 a4 e4~ |
      e2 fis2 |
      cis'4 fis'2 e'4~ |
      e'4 b2. |
      fis4. gis8 a2 |
      cis'4 fis'4 b2 |
      e4 dis4 e4 dis4 |
      fis8 gis8 a4 gis2 |
      fis4 gis4 e2 |
      gis8 a8 b4 cis'2 |
      a4 gis4 cis'4 b4 |
      r1 |
      e'2 b4 gis4 |
      e4. fis8 gis2 |
      cis'2 gis2 |
      e4. fis8 gis2 |
      a8 b8 cis'4 a2 |
      e2 a2 |
      b2 gis2 |
      e2 b2 |
      gis1 |
      e'4 gis4 e4 gis4 |
      e'4 cis'2.~ |
      cis'4 a4 cis'4 fis4~ |
      fis4 a2. |
      fis4 dis4 b2 |
      dis'8 cis'8 b2. |
      gis4. a8 b4 e'4 |
      gis'2.~ gis'8 fis'8 |
      e'4 b4 fis4 e4~ |
      e4 fis4 b4 gis4 |
      b2 cis'2 |
      cis'2 b2 |
      e2 gis2 |
      b2 e'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "bass" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      b,4^\markup { \tiny \italic "Real answer" } fis4 ais4 b8 ais8 |
      gis4 fis8 e8 dis2 |
      cis2 b,2 |
      cis4^\markup { \tiny \italic "Countersubject" } dis8 e8 fis4 gis8 fis8 |
      e4 dis4 e4. fis16 e16 |
      dis2 cis2 |
      e2 fis2 |
      b,1 |
      r1 |
      r1 |
      r1 |
      gis,2 cis4 fis4 |
      fis'4 b4 d4 cis4 |
      fis4 b,4 e2 |
      b,2 cis4 fis4 |
      a4 fis'2 b4 |
      e4 b4 e4 b,4 |
      fis2 cis'2 |
      e4 b,4 b4 e4 |
      gis4 dis4 b,2 |
      fis4 a,4 e4 gis4 |
      b,4. a,8 gis,4 b,4 |
      dis4 gis4 a2 |
      e2. gis4 |
      r1 |
      b,2 e2 |
      b,4. a,8 gis,4 b,4 |
      e2. cis4 |
      e4. dis8 cis2 |
      e2 a4 e4 |
      cis4. b,8 a,4 cis4 |
      e2 b2 |
      e2 b,4 gis,4 |
      b,2. e4 |
      gis2 cis2 |
      e2 a2 |
      cis2. a,4 |
      fis,2. fis4~ |
      fis2 b,2 |
      fis2 b,2~ |
      b,4 e4 b,4 gis,4~ |
      gis,2 cis4 gis4 |
      gis4 b,4 fis4 b,4 |
      e4 b4 e2 |
      fis2 cis'4 a4 |
      a4 e4 b4 fis4 |
      b,4 e4 b,4 e4 |
      gis2 e4 gis4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "bass" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4^\markup { \tiny \italic "Subject" } b4 dis'4 e'8 dis'8 |
      cis'4 b8 a8 gis2 |
      fis2 e2 |
      cis8 b,8 a,4 b,8 a,8 gis,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,4 dis4 b4 e4~ |
      e4 b,2. |
      fis,4 a,4 e4 cis4 |
      r1 |
      r1 |
      dis,4 cis,2 fis,4 |
      gis,4 cis4 fis4 dis4 |
      fis,2 b,4 gis,4 |
      gis4 cis4 fis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,4 b,2 e,4 |
      gis,4 b,2. |
      e,4 gis,2. |
      cis4 gis,2 e,4 |
      cis,4 e,2 a,4 |
      cis8 dis8 e2. |
      b,4 gis,2. |
      b,2. e4 |
      e4 b,2 e,4~ |
      e,4 gis,4 cis2 |
      e,4 a,2. |
      cis2. fis4 |
      a,2. fis4~ |
      fis4 fis,2. |
      b,,2. b,4~ |
      b,2. e,4~ |
      e,4 gis,2 e,4 |
      r1 |
      r1 |
      r1 |
      a,4 cis4 fis,2 |
      b,2 e4 gis,4 |
      e,4 gis,2 e,4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "bass" \key e \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,4^\markup { \tiny \italic "Subject" } b,4 dis4 e8 dis8 |
      cis4 b,8 a,8 gis,2 |
      fis,2 e,2 |
      e,8 dis,8 cis,4 a,4 fis,4 |
      dis,2 e,2 |
      gis,,4^\markup { \tiny \italic "Countersubject" } ais,,8 b,,8 cis,4 dis,8 cis,8 |
      b,,4 ais,,4 b,,4. cis,16 b,,16 |
      ais,,2 gis,,2 |
      b,,4 e,4 fis,4 dis,4 |
      fis,4^\markup { \tiny \italic "Countersubject" } gis,8 a,8 b,4 cis8 b,8 |
      a,4 gis,4 a,4. b,16 a,16 |
      gis,2 fis,2 |
      cis,4^\markup { \tiny \italic "Countersubject" } dis,8 e,8 fis,4 gis,8 fis,8 |
      e,4 dis,4 e,4. fis,16 e,16 |
      dis,2 cis,2 |
      e,4^\markup { \tiny \italic "Stretto subject" } b,4 dis4 e8 dis8 |
      cis4 b,8 a,8 gis,2 |
      fis,2 e,2 |
      b,,8 a,,8 gis,,4 e,2 |
      b,,4 e,4 a,2~ |
      a,4 cis,4 a,,4 b,,4 |
      r1 |
      e,1~ |
      e,1~ |
      e,1~ |
      e,1 |
      a,,1~ |
      a,,1 |
      e,1~ |
      e,1 |
      e,1 |
      cis,1 |
      a,,1 |
      fis,,1~ |
      fis,,1 |
      b,,1~ |
      b,,1 |
      e,1 |
      cis,1 |
      cis,4^\markup { \tiny \italic "Countersubject" } dis,8 e,8 fis,4 gis,8 fis,8 |
      e,4 dis,4 e,4. fis,16 e,16 |
      dis,2 cis,2 |
      cis,2 dis,2 |
      e,1 |
      e,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
