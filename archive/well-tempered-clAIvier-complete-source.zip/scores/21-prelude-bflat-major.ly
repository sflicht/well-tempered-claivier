\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXI. Prelude in B-flat major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key bes \major \time 4/4
      \tempo "Moderato, sereno" 4 = 88
      \mark \markup \box \small "Opening cell" f'''8\p ees'''8 d'''4 r2 |
      r1 |
      bes'''8 a'''8 g'''4 r2 |
      r1 |
      f'''8 ees'''8 d'''4 r2 |
      r1 |
      c'''8 bes''8 a''4 r2 |
      r1 |
      \mark \markup \box \small "Contrasting span" bes''8\mp c'''8 d'''4 r2 |
      r1 |
      f''8 g''8 a''4 r2 |
      r1 |
      g''8 a''8 bes''4 r2 |
      r1 |
      ees''8 f''8 g''4 r2 |
      r1 |
      \mark \markup \box \small "Development" d''8\mf f''8 d'''4 r2 |
      g''8 bes''8 g'''4 r2 |
      ees'''8 g'''8 ees''''4 r2 |
      bes'''8 f'''8 bes''4 r2 |
      c'''8 ees'''8 c''''4 r2 |
      c'''8 e'''8 c''''4 r2 |
      f'''8 a'''8 f''''4 r2 |
      f''''8 c''''8 f'''4 r2 |
      \mark \markup \box \small "Return" f'''8\mp ees'''8 d'''4 r2 |
      bes'''8 ees''''8 g'''4 r2 |
      bes'''8 ees''''8 ges'''4 r2 |
      d'''8 ees'''8 f'''4 r2 |
      \mark \markup \box \small "Cadence" g'''8\p f'''8 ees'''4 r2 |
      f'''8 bes'''8 d'''4 r2 |
      c'''8 f'''8 a''4 r2 |
      bes''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key bes \major \time 4/4
      r1 |
      f''8 bes''8 d''4 r2 |
      r1 |
      g''8 ees''8 bes''4 r2 |
      r1 |
      f''8 bes''8 d''4 r2 |
      r1 |
      a'8 f'8 c''4 r2 |
      r1 |
      bes'8 g'8 d''4 r2 |
      r1 |
      a''8 d'''8 f''4 r2 |
      r1 |
      g''8 ees''8 bes''4 r2 |
      r1 |
      c''8 f''8 a'4 r2 |
      r2 d'8 f'8 d''4 |
      r2 g'8 bes'8 g''4 |
      r2 ees''8 g''8 ees'''4 |
      r2 bes''8 f''8 bes'4 |
      r2 c''8 ees''8 c'''4 |
      r2 c''8 e''8 c'''4 |
      r2 f''8 a''8 f'''4 |
      r2 f'''8 c'''8 f''4 |
      r2 f''8 bes''8 d''4 |
      r2 bes''8 ees'''8 g''4 |
      r2 bes''8 ees'''8 ges''4 |
      r2 d''8 bes'8 f''4 |
      r2 g''8 c'''8 ees''4 |
      r2 f''8 bes''8 d''4 |
      r2 c''8 f''8 a'4 |
      bes'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key bes \major \time 4/4
      d2\p f2 |
      d2 f2 |
      g2 bes2 |
      g2 g2 |
      d2 f2 |
      d2 d2 |
      a,2 c2 |
      a,2 c2 |
      bes,2\mp d2 |
      bes,2 d2 |
      f2 a2 |
      f2 a2 |
      g2 bes2 |
      g2 bes2 |
      g2 ees2 |
      c2 c2 |
      f2\mf f2 |
      d2 d2 |
      g2 g2 |
      f2 f2 |
      ees2 g2 |
      e2 e2 |
      c2 c2 |
      a,2 c2 |
      d2\mp f2 |
      g2 bes2 |
      ges2 bes2 |
      f2 f2 |
      ees2\p g2 |
      d2 d2 |
      c2 ees2 |
      d1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key bes \major \time 4/4
      bes,,1\p |
      bes,,1 |
      ees,1 |
      ees,1 |
      d,1 |
      d,1 |
      f,1 |
      f,1 |
      g,1\mp |
      g,1 |
      d,1 |
      d,1 |
      ees,1 |
      ees,1 |
      ees,1 |
      f,1 |
      d,1\mf |
      g,1 |
      ees,1 |
      d,1 |
      ees,1 |
      c,1 |
      f,1 |
      f,1 |
      bes,1\mp |
      ees,1 |
      ees,1 |
      d,1 |
      ees,1\p |
      f,1 |
      f,1 |
      bes,,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
