\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "VI. Prelude in D minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key d \minor \time 3/4
      \tempo "Lento, con gravita" 4 = 58
      \mark \markup \box \small "Opening cell" a''4\p g''4. f''8 |
      e''4 f''4. e''8 |
      f''4 e''4. d''8 |
      g''4 f''4. g''8 |
      e''4 f''4. e''8 |
      c''4 cis''4. c''8 |
      d''4 e''4. d''8 |
      e''4 d''4. e''8 |
      \mark \markup \box \small "Contrasting span" a''4\mp a''4. e''8 |
      f''4 e''4. f''8 |
      d''4 e''4. d''8 |
      cis''4 d''4. e''8 |
      f''4 e''4. f''8 |
      e''4 d''4. e''8 |
      f''4 e''4. f''8 |
      e''4 d''4. e''8 |
      \mark \markup \box \small "Development" a''4\mf g''4. f''8 |
      f''4 e''4. d''8 |
      d''4 e''4. d''8 |
      f''4 e''4. f''8 |
      e''4 f''4. e''8 |
      cis''4 d''4. cis''8 |
      d''4 e''4. f''8 |
      d''4 cis''4. d''8 |
      \mark \markup \box \small "Return" g''4\mp f''4. g''8 |
      a''4 g''4. f''8 |
      ees''4 e''4. ees''8 |
      e''4 f''4. e''8 |
      \mark \markup \box \small "Cadence" f''4\p e''4. f''8 |
      d''4 cis''4. d''8 |
      cis''4 e''4. cis''8 |
      d''2. \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key d \minor \time 3/4
      f'4\p f'2 |
      cis'4 e'2 |
      f'4 a'2 |
      bes'4 bes'2 |
      g'4 e'2 |
      c'4 c'2 |
      d'4 f'2 |
      g'4 g'2 |
      e'4\mp e'2 |
      f'4 a'2 |
      bes'4 bes'2 |
      a'4 a'2 |
      a'4 a'2 |
      g'4 e'2 |
      c'4 a2 |
      g4 g2 |
      a4\mf c'2 |
      d'4 d'2 |
      bes4 d'2 |
      f'4 a'2 |
      g'4 g'2 |
      e'4 e'2 |
      f'4 a'2 |
      f'4 d'2 |
      bes4\mp d'2 |
      f'4 a'2 |
      g'4 g'2 |
      e'4 e'2 |
      f'4\p a'2 |
      bes'4 bes'2 |
      a'4 a'2 |
      a'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key d \minor \time 3/4
      f2.\p |
      e2. |
      f2. |
      d2. |
      g2. |
      f2. |
      f2. |
      g2. |
      e2.\mp |
      f2. |
      d2. |
      e2. |
      c2. |
      e2. |
      c2. |
      e2. |
      c2.\mf |
      d2. |
      d2. |
      f2. |
      g2. |
      e2. |
      a2. |
      f2. |
      d2.\mp |
      f2. |
      g2. |
      e2. |
      f2.\p |
      d2. |
      g2. |
      f2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key d \minor \time 3/4
      d,4\p d,2 |
      cis,4 cis,4 d,8 e,8 |
      f,4 f,2 |
      g,4 g,2 |
      c,4 c,2 |
      f,4 f,2 |
      bes,4 bes,4. a,8 |
      g,4 g,2 |
      a,4\mp a,2 |
      f,4 f,2 |
      g,4 g,2 |
      a,4 a,2 |
      f,4 f,2 |
      c,4 c,2 |
      f,4 f,2 |
      c,4 c,2 |
      f,4\mf f,2 |
      bes,4 bes,4. a,8 |
      g,4 g,2 |
      f,4 f,2 |
      g,4 g,2 |
      a,4 a,2 |
      d,4 d,4. c,8 |
      bes,,4 bes,,2 |
      g,,4\mp g,,2 |
      f,,4 f,,2 |
      g,,4 g,,2 |
      a,,4 a,,2 |
      d,4\p d,2 |
      g,4 g,2 |
      a,4 a,2 |
      d,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
