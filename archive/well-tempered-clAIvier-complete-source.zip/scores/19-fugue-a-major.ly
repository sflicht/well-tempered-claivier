\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XIX. Fugue in A major — The answering garden"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a2")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key a \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 110
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''2^\markup { \tiny \italic "Subject" } cis'''4 e'''4 |
      d'''2 fis'''4 e'''8 d'''8 |
      cis'''4 b''4 a''2 |
      cis'''4.^\markup { \tiny \italic "Countersubject" } dis'''16 cis'''16 b''8 cis'''8 dis'''4 |
      cis'''4. dis'''8 e'''4 dis'''4 |
      e'''4 dis'''4 cis'''2 |
      cis'''2 e''2 |
      a''2. e'''4 |
      a''4 b''4 fis''4. gis''8 |
      \mark \markup \box \small "Sequential episode" a''2 b''2 |
      gis'''8 fis'''8 e'''4 cis'''2 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis''2 e''4 b''4 |
      fis''4 cis'''4 gis''8 a''8 b''4 |
      e''4 a''4 e''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''2 cis'''4. b''8 |
      a''4 d'''4 a''4 e''4 |
      a''4 d''4 a''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Exposition 4" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Development" a'''4 b'''8 a'''8 g'''4 fis'''4 |
      b'''2 cis''''4 e'''8 fis'''8 |
      g'''4 d'''8 cis'''8 b''4 e'''4 |
      a''2 b''2 |
      \mark \markup \box \small "Linking episode" b''2 a''2 |
      \mark \markup \box \small "Development" e'''2^\markup { \tiny \italic "Related-key subject" } gis'''4 b'''4 |
      a'''2 cis''''4 b'''8 a'''8 |
      gis'''4 fis'''4 e'''2 |
      \mark \markup \box \small "Stretto" e'''1 |
      b''4 d'''4 cis'''2 |
      a''4 gis''4 a''2^\markup { \tiny \italic "Stretto subject" } |
      cis'''4 e'''4 d'''2 |
      fis'''4 e'''8 d'''8 cis'''4 b''4 |
      a''2 cis'''2 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" e'''2 cis'''2 |
      e'''1 |
      fis'''1~ |
      fis'''1~ |
      fis'''4 a'''4 fis'''2 |
      a'''2 fis'''4 a'''4 |
      e'''1 |
      cis'''2 e'''2 |
      \mark \markup \box \small "Gathered development" a'''1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      cis''''1 |
      a'''2 cis'''2~ |
      cis'''4 a'''2 cis'''4 |
      fis''4 a''4 fis'''2~ |
      fis'''2. a'''4 |
      d'''1~ |
      d'''2 fis'''2 |
      d'''1~ |
      d'''4 b''4 gis''2~ |
      gis''4 b''4 gis''4 gis'''4 |
      b''4 gis''4 b''4 b'''4~ |
      b'''4 gis'''2 e'''4 |
      gis'''2 b''2 |
      cis'''4 e''2. |
      e'''1 |
      a'''2 cis'''2~ |
      cis'''4 a''2 fis''4 |
      \mark \markup \box \small "Final return" d'''2 cis'''4 b''4 |
      d'''2 cis'''4 e'''4~ |
      e'''2 d'''2 |
      \mark \markup \box \small "Final cadence" d'''2 e'''2~ |
      e'''1 |
      e'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''2 b''2 |
      a''2^\markup { \tiny \italic "Subject" } cis'''4 e'''4 |
      d'''2 fis'''4 e'''8 d'''8 |
      cis'''4 b''4 a''2 |
      cis'''4.^\markup { \tiny \italic "Countersubject" } dis'''16 cis'''16 b''8 cis'''8 dis'''4 |
      cis'''4. dis'''8 e'''4 dis'''4 |
      e'''4 dis'''4 cis'''2 |
      cis'''2.~ cis'''8 b''8 |
      a''2 gis''4. a''8 |
      b''4 a''4 cis''8 d''8 e''4~ |
      e''4 d''4 cis''2 |
      fis''1 |
      e''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis''8 gis''8 a''4 e''2 |
      a''4 b''4 cis'''2 |
      e''4 b''4 fis''2 |
      cis''2 gis'2 |
      cis''8 b'8 a'2 b'4 |
      e''4 a'8 b'8 cis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''2 cis''2~ |
      cis''4 cis'''2. |
      fis''4 cis''2. |
      a''2 fis'''2 |
      a''2 d''4 a''4~ |
      a''1~ |
      a''2 cis''2 |
      a''2. e'''4 |
      a''2 cis''2 |
      a''2 e'''2 |
      fis'''4 cis'''2. |
      fis''2. cis''4 |
      d''4 fis''2. |
      d'''2 a''2 |
      b''4 fis''2. |
      b'4 fis''2. |
      b''1~ |
      b''2 d''2 |
      e''2. b''4~ |
      b''4 e''4 b''2~ |
      b''4 e'''4 b''2 |
      e'''4 b''2. |
      a''4 cis''2. |
      a''2. e''4 |
      fis''4 a''2. |
      cis''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''2^\markup { \tiny \italic "Subject" } cis'''4 e'''4 |
      d'''2 fis'''4 e'''8 d'''8 |
      cis'''4 b''4 a''2 |
      cis''4.^\markup { \tiny \italic "Countersubject" } dis''16 cis''16 b'8 cis''8 dis''4 |
      cis''4. dis''8 e''4 dis''4 |
      e''4 dis''4 cis''2 |
      cis'''4 b''4 cis'''2~ |
      cis'''1 |
      b''8 cis'''8 d'''4 cis'''4. b''8~ |
      b''8 a''8 d''8 e''8 fis''2 |
      fis''2 gis''4 a''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''8 e''8 fis''4 cis'''4 e''4 |
      a'4 d''2 b''4 |
      e''4 b''4 r2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'''2 a''2~ |
      a''4 cis''2 cis'''4~ |
      cis'''2 fis''2~ |
      fis''4 cis'''4 fis''2~ |
      fis''4 d'''2 fis''4~ |
      fis''4 a'2 a''4~ |
      a''2. cis''4~ |
      cis''2 a''2 |
      a''4 e'''4 a''4 cis''4~ |
      cis''2 e''4 cis'''4~ |
      cis'''2 fis''2~ |
      fis''4 a'2. |
      fis''2 a'4 fis''4~ |
      fis''2 d'''2~ |
      d'''4 fis''2 b'4~ |
      b'2 b''4 b'4~ |
      b'1~ |
      b'1~ |
      b'1~ |
      b'2 e''2~ |
      e''1~ |
      e''1~ |
      e''1 |
      a'4 e''4 cis'''2~ |
      cis'''4 cis''2 a''4~ |
      a''4 cis''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''2^\markup { \tiny \italic "Subject" } cis'''4 e'''4 |
      d'''2 fis'''4 e'''8 d'''8 |
      cis'''4 b''4 a''2 |
      cis''4.^\markup { \tiny \italic "Countersubject" } dis''16 cis''16 b'8 cis''8 dis''4 |
      cis''4. dis''8 e''4 dis''4 |
      e''4 dis''4 cis''2 |
      a''2. gis''4 |
      b'8 cis''8 d''4 cis''2~ |
      cis''4 d''8 e''8 fis''2 |
      fis''8 gis''8 a''4 b''2~ |
      b''2 e''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 e''2.~ |
      e''4 a'2. |
      fis''2. cis'''4~ |
      cis'''4 fis''2. |
      d'''4 a''2 d''4~ |
      d''4 a''2.~ |
      a''4 cis''2 a''4~ |
      a''4 cis''2. |
      e''2 cis''4 a''4~ |
      a''4 cis''2. |
      a''2. cis''4~ |
      cis''4 fis'2 fis''4~ |
      fis''2 d'''2~ |
      d'''4 fis''2. |
      d'''2. fis''4~ |
      fis''4 b'2 b''4~ |
      b''2 b'2~ |
      b'1~ |
      b'1~ |
      b'4 e''2.~ |
      e''1~ |
      e''1~ |
      e''2. a'4 |
      e''4 a'2.~ |
      a'4 fis''4 cis'''2~ |
      cis'''4 fis''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      e''2^\markup { \tiny \italic "Real answer" } gis''4 b''4 |
      a''2 cis'''4 b''8 a''8 |
      gis''4 fis''4 e''2 |
      fis''4.^\markup { \tiny \italic "Countersubject" } gis''16 fis''16 e''8 fis''8 gis''4 |
      fis''4. gis''8 a''4 gis''4 |
      a''4 gis''4 fis''2 |
      e''2 b'8 a'8 gis'4 |
      a'2 gis'8 a'8 b'4~ |
      b'4 a'4 gis'2 |
      cis''2. b'4 |
      fis'2. cis''4~ |
      cis''4 d''4 cis''2 |
      cis''2 d''8 cis''8 b'4~ |
      b'4 e''2 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'8 b'8 cis''4 fis''8 e''8 d''4 |
      fis''8 e''8 d''4 e''8 d''8 cis''4 |
      a'4 b'4 cis''2~ |
      cis''8 d''8 e''8 d''8 cis''8 b'8 a'4 |
      gis'8 fis'8 e'4 b'4 fis''4~ |
      fis''8 gis''8 a''4 e''8 fis''8 gis''4 |
      e''4 fis''4 cis''8 dis''8 e''4 |
      e''4 a'4 cis''2~ |
      cis''4 fis''4 cis''2 |
      d''4 a'2 e'4 |
      a'4 b'4 cis''8 b'8 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d''8 e''8 fis''4 gis''8 fis''8 e''4 |
      fis''4 b''4 fis''4 cis''4~ |
      cis''4 d''8 e''8 fis''8 e''8 d''4 |
      r1 |
      r1 |
      r1 |
      cis'4 fis'4 gis'4 cis''4~ |
      cis''4 fis''4 cis''4 gis'8 a'8 |
      b'4 fis'2 cis'4 |
      a'4 d''4 cis''8 b'8 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'8 gis'8 a'4 e''2 |
      a''4 d''4 a'4 e''4~ |
      e''4 b'4 cis''4 fis''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'2 e''2~ |
      e''4 a''2 cis''4~ |
      cis''2 fis''4 cis''4~ |
      cis''2 a'4 cis''4 |
      fis'2 d''2~ |
      d''4 fis''2 a'4~ |
      a'4 e'4 a'4 e''4~ |
      e''4 a''4 cis''2 |
      cis''2 a''4 e''4~ |
      e''2 a'2~ |
      a'4 fis''4 cis''2~ |
      cis''4 fis''2.~ |
      fis''4 a'2 d''4~ |
      d''4 fis''2.~ |
      fis''4 b'2 fis''4~ |
      fis''2 b'2~ |
      b'2. b''4~ |
      b''2 b'2~ |
      b'4 e''2.~ |
      e''1~ |
      e''1~ |
      e''1~ |
      e''4 e'2 cis''4~ |
      cis''2 a'2~ |
      a'4 cis'4 a'2 |
      cis''2 a'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e''2^\markup { \tiny \italic "Real answer" } gis''4 b''4 |
      a''2 cis'''4 b''8 a''8 |
      gis''4 fis''4 e''2 |
      cis''2 b'4 fis'4 |
      fis'4.^\markup { \tiny \italic "Countersubject" } gis'16 fis'16 e'8 fis'8 gis'4 |
      fis'4. gis'8 a'4 gis'4 |
      a'4 gis'4 fis'2 |
      gis'2. fis'8 gis'8 |
      a'2 gis'2~ |
      gis'4 a'4 gis'2 |
      cis'4 a'2 cis''4 |
      fis''4 cis''8 d''8 e''2 |
      b'8 cis''8 d''4 cis''4. b'8~ |
      b'8 a'8 d'4 fis'8 gis'8 a'4 |
      cis''2 b'2~ |
      b'2 a'4 e'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'2 e'4 b'4 |
      d''2 a''4 e''4~ |
      e''4 d''4 a'8 gis'8 fis'4 |
      cis''2 gis'2 |
      cis'4 cis''4 e'4 b'4 |
      e'4 a'4 cis'4 gis'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'2 e'4 a'4~ |
      a'2 e''4 a'4 |
      fis'2 cis'4 fis'4 |
      cis''2. fis'4 |
      a'2. d''4 |
      a'2 fis''2 |
      a'2. e'4 |
      cis''2. a'4 |
      a'4 cis''4 a'2 |
      e''2 a''2 |
      cis''2. a'4~ |
      a'2 fis''4 a'4~ |
      a'2 d'4 a'4 |
      d''2 a''4 d''4~ |
      d''2 fis'4 b'4 |
      d''4 b'4 d''4 b''4 |
      b'2. b4~ |
      b2 b'2~ |
      b'1~ |
      b'1~ |
      b'1~ |
      b'2 e''2~ |
      e''2 e'4 a'4~ |
      a'2 e'4 cis''4~ |
      cis''2 fis'4 cis''4 |
      a'2 cis''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'2^\markup { \tiny \italic "Real answer" } gis'4 b'4 |
      a'2 cis''4 b'8 a'8 |
      gis'4 fis'4 e'2 |
      fis'4.^\markup { \tiny \italic "Countersubject" } gis'16 fis'16 e'8 fis'8 gis'4 |
      fis'4. gis'8 a'4 gis'4 |
      a'4 gis'4 fis'2 |
      gis'1 |
      a'2. fis'4~ |
      fis'8 e'8 fis'4 gis'2 |
      cis'4 d'4 e'8 d'8 cis'4 |
      fis'4 cis'4 gis4 cis'4 |
      fis'2 cis''2~ |
      cis''4 d''4 a'4. b'8 |
      cis''4 d''8 cis''8 b'4 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis''4 b'4 d'4 b'4 |
      d''2^\markup { \tiny \italic "Related-key subject" } fis''4 a''4 |
      g''2 b''4 a''8 g''8 |
      fis''4 e''4 d''2 |
      d''4 e''2 d''4 |
      cis''2 dis''4 b'4 |
      cis''2. fis''4 |
      b'4 fis'4 cis'4 a4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis''2 a'2 |
      cis''4 a'4 cis''2 |
      a'2 fis'2 |
      cis'4 fis'4 a'2 |
      d''2 a'2 |
      d'2 fis'2 |
      cis''2 a'2~ |
      a'4 e'4 a'2 |
      e''2. cis''4 |
      e''2 e'2 |
      a4 cis'4 a'2 |
      a''4 cis''2 fis'4~ |
      fis'2 a'2~ |
      a'2. fis''4~ |
      fis''1~ |
      fis''2. b'4 |
      gis'1~ |
      gis'2 b'2~ |
      b'4 gis'4 b2 |
      b'2 gis''4 e''4~ |
      e''4 b'2.~ |
      b'2 gis'2 |
      a'1^\markup { \tiny \italic "Subject-head fragment in augmentation" } |
      cis''2 e'4 a4~ |
      a1~ |
      a4 cis'2 a4 |
      a2 e'4 b'4 |
      fis'2 cis''4 e'4~ |
      e'4 b'4 fis''2 |
      fis''2 b'4 e'4~ |
      e'2 a'2 |
      cis''2 a'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'2^\markup { \tiny \italic "Real answer" } gis'4 b'4 |
      a'2 cis''4 b'8 a'8 |
      gis'4 fis'4 e'2 |
      fis'4.^\markup { \tiny \italic "Countersubject" } gis'16 fis'16 e'8 fis'8 gis'4 |
      fis'4. gis'8 a'4 gis'4 |
      a'4 gis'4 fis'2 |
      e'2 dis'8 cis'8 b4 |
      e'4 fis'4 gis'8 a'8 b'4~ |
      b'4 a'4 gis'2 |
      fis'2 a'4 e''4 |
      b'2 cis''4 e'4~ |
      e'4 d'4 a'4. gis'8 |
      fis'4 cis''4 fis'4 b'4~ |
      b'4 e'2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis'2 b4 fis'4 |
      a4 e'4 gis'4 b4~ |
      b2 r2 |
      cis'2 gis'4 e'4 |
      fis'4 d'4 a4 e4 |
      a4 d'4 a'2 |
      e'4 b'4 d'4 fis'4 |
      a'4 e'2 b'4 |
      fis'4 cis'2 a4 |
      r1 |
      e'2 a'2 |
      e'2. a'4 |
      cis''2 a'4 cis''4 |
      fis'2. a'4 |
      fis'2 d'4 fis'4~ |
      fis'4 a'2 fis'4 |
      a'2 e'4 a'4 |
      e'4 cis'4 a4 cis'4 |
      cis'2 e'4 a'4 |
      e'2. a4~ |
      a2 cis'4 fis'4~ |
      fis'2 cis'4 a'4~ |
      a'2 fis'4 d''4 |
      a'2 fis'2~ |
      fis'2 d'4 fis'4~ |
      fis'2 d'2~ |
      d'2 b'2 |
      d'2. b'4~ |
      b'2. e'4~ |
      e'1~ |
      e'1~ |
      e'1~ |
      e'2 cis''4 a'4 |
      e'2 a4 cis'4 |
      a'2 cis''2 |
      fis'2 cis'2 |
      d'4 fis'4 cis''4 e'4 |
      a2. e'4~ |
      e'2 a4 d'4 |
      d'2 b'2 |
      e'2. a'4 |
      e'2 a'4 cis''4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key a \major \time 4/4
      a'2^\markup { \tiny \italic "Subject" } cis''4 e''4 |
      d''2 fis''4 e''8 d''8 |
      cis''4 b'4 a'2 |
      cis'4.^\markup { \tiny \italic "Countersubject" } dis'16 cis'16 b8 cis'8 dis'4 |
      cis'4. dis'8 e'4 dis'4 |
      e'4 dis'4 cis'2 |
      d'2 cis'2 |
      d'8 cis'8 b4 a8 b8 cis'4~ |
      cis'4 e'4 fis'2 |
      cis'2 dis'2 |
      e'4 fis'4 gis'2~ |
      gis'4 a'4 e'2 |
      a'2 e'2 |
      a2. e4~ |
      e4 d8 e8 fis2 |
      fis2 b2~ |
      b4 e2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis'8 d'8 e'4 d'8 e'8 fis'4 |
      a'8 gis'8 fis'4 gis'8 fis'8 e'4 |
      fis'8 e'8 d'4 cis'8 d'8 e'4 |
      a'4 b'4 fis'8 gis'8 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a8 gis8 fis4 gis8 a8 b4 |
      fis'8 e'8 d'2 b4~ |
      b8 a8 d'4 fis'8 gis'8 a'4 |
      e'8 dis'8 cis'4 dis'4 gis'4 |
      cis''8 b'8 a'4 gis'4. fis'8~ |
      fis'8 e'8 fis'4 cis'8 dis'8 e'4 |
      cis'4. d'8 e'4 cis'4 |
      d'8 e'8 fis'4 cis'8 d'8 e'4 |
      a4 b4 fis'8 gis'8 a'4 |
      r1 |
      r1 |
      fis4 b2 fis'4 |
      g'4 fis'2 e'4 |
      b8 cis'8 d'4 fis'4 e'4 |
      fis'8 g'8 a'4 d'8 e'8 fis'4 |
      fis'4 g'8 fis'8 e'4 a4 |
      gis2 b2 |
      e'4 cis'2 fis4 |
      e4 fis4 cis'4 e'4 |
      e'4 cis'4 e'4 gis'4 |
      b'4 fis'2 gis'4 |
      cis'4 d'4 e'4 fis'4 |
      e'4 e'4 fis'4 d'4 |
      a4 gis2 b4 |
      cis'4 fis'4 e'4 cis'4 |
      r1 |
      a4 cis'2 e'4~ |
      e'4 cis'2 e'4 |
      cis'4 fis'2 a'4 |
      fis'4 a'2 fis'4 |
      d'4 fis'2 d'4 |
      fis'2. d'4 |
      cis'4 e'2 cis'4~ |
      cis'4 e'2 cis'4 |
      cis'4 e'2. |
      cis'4 e'2 a'4~ |
      a'4 fis'2 a'4 |
      fis'4 a'4 fis'4 a'4 |
      fis'2. d'4 |
      fis'4 d'2. |
      fis4 b4 d'2 |
      fis'4 d'2 b4~ |
      b2 d'2~ |
      d'4 b'2. |
      b2. e'4~ |
      e'1~ |
      e'1~ |
      e'1 |
      e4 cis'4 e'4 cis'4 |
      e'2. a'4~ |
      a'4 fis'2 cis'4 |
      fis'4 cis'2 fis'4 |
      fis'4 d'4 e'2 |
      a'4 fis'4 cis'4 b4 |
      cis'4 e'4 fis'4 d'4 |
      d'4 a4 b2 |
      cis'4 e'2 cis'4 |
      a4 cis'2 e'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "treble" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a2^\markup { \tiny \italic "Subject" } cis'4 e'4 |
      d'2 fis'4 e'8 d'8 |
      cis'4 b4 a2 |
      cis'4.^\markup { \tiny \italic "Countersubject" } dis'16 cis'16 b8 cis'8 dis'4 |
      cis'4. dis'8 e'4 dis'4 |
      e'4 dis'4 cis'2 |
      cis'2 d'2~ |
      d'2 cis'2 |
      d'8 cis'8 b4 a8 b8 cis'4 |
      a4 e4 fis2 |
      cis'2 e'4 fis'4~ |
      fis'2 gis'4 dis'8 cis'8~ |
      cis'8 b8 a8 b8 cis'2 |
      cis'8 d'8 e'4 cis'4 e'4 |
      a'8 b'8 cis''2.~ |
      cis''8 b'8 fis'4 cis'4. d'8 |
      e'4 b4 fis2 |
      fis2 b,2 |
      gis8 a8 b4 e2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'8 e'8 d'4 e'4 cis'4 |
      fis'8 e'8 d'4 cis'8 d'8 e'4~ |
      e'4 d'4. e'8 fis'4 |
      e'8 dis'8 cis'4 dis'8 cis'8 b4 |
      e'8 dis'8 cis'2 fis'4 |
      gis'4 a'4 e'8 dis'8 cis'4 |
      gis4 fis4 e8 fis8 gis4 |
      a8 b8 cis'4 e'8 d'8 cis'4 |
      d'8 cis'8 b4 a4 e4 |
      a4 b4 cis'4 fis'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'4 d'4. cis'8 b4~ |
      b4 d'4 cis'8 d'8 e'4 |
      d'8 cis'8 b4 fis4 a4 |
      d'4 e'4 fis'8 e'8 d'4 |
      d'8 cis'8 b4 e4 a8 b8 |
      cis'4 e'4 b4 fis4 |
      a4 cis'4 gis4 b4~ |
      b2 e'4 cis'4 |
      cis'4 e'2 cis'4 |
      d'4 b4 cis'4 e'4~ |
      e'4 d'4 cis'4 a4~ |
      a4 b4 d'4 b4 |
      cis'4 gis2 fis4 |
      a4 cis'2 e'4 |
      r1 |
      cis'4 a2 cis'4~ |
      cis'4 e'2 cis'4~ |
      cis'4 a2 fis4 |
      a4 cis'2 fis'4~ |
      fis'4 d'2 a4~ |
      a4 d'2 fis'4 |
      e'4 cis'2 a4~ |
      a4 cis'2 e'4 |
      e'4 cis'2 a4~ |
      a4 e'2 cis'4~ |
      cis'2 a4 fis4 |
      a4 cis'2 fis'4~ |
      fis'4 d'2 a4~ |
      a4 d'4 fis'4 d'4~ |
      d'4 b2 d'4~ |
      d'4 fis'2 d'4~ |
      d'4 b2 d'4~ |
      d'2 b2~ |
      b1~ |
      b1~ |
      b1~ |
      b4 e'2.~ |
      e'4 a4 cis'4 e'4~ |
      e'4 cis'4 e'4 cis'4 |
      a4 cis'4 a4 cis'4~ |
      cis'4 fis'2 a'4 |
      d'4 a4 gis4 e4 |
      fis4 a2 b4 |
      a4 b4 fis4 a4 |
      a4 d'4 b4 e'4~ |
      e'4 cis'2 e'4~ |
      e'4 cis'2 a4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a2^\markup { \tiny \italic "Subject" } cis'4 e'4 |
      d'2 fis'4 e'8 d'8 |
      cis'4 b4 a2 |
      cis'4.^\markup { \tiny \italic "Countersubject" } dis'16 cis'16 b8 cis'8 dis'4 |
      cis'4. dis'8 e'4 dis'4 |
      e'4 dis'4 cis'2 |
      d'2 cis'2 |
      d'8 cis'8 b4 a8 b8 cis'4 |
      a4 b8 cis'8 d'2~ |
      d'8 cis'8 gis8 a8 b2 |
      cis'8 dis'8 e'2 b4~ |
      b4 a4 gis2 |
      cis'4 fis4 cis4 cis'4 |
      fis2 gis2 |
      b,4 b4 cis'4. d'8 |
      e'4 d'4 fis2 |
      fis4 b4 e'8 d'8 cis'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'8 e'8 d'4 cis'4 b4 |
      a8 gis8 fis2 b4 |
      cis'4 d'4 cis'8 b8 a4 |
      cis'8 dis'8 e'4 b4 gis4 |
      a8 gis8 fis4 e4 gis4 |
      b4 fis4 gis4 cis'4 |
      cis'8 b8 a2 e4 |
      fis4 b4 a8 b8 cis'4 |
      e'4 b4 cis'8 b8 a4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'4 e'2 fis'4 |
      e'4 cis'4 gis4 fis4 |
      cis4 e2 fis4 |
      gis4 b4 gis4 a4 |
      cis'1 |
      b2 a4 cis'4 |
      e'4 b4 cis'4 fis4 |
      a4 gis8 a8^\markup { \tiny \italic "Upward leading-note resolution; weak upper escape" } fis4 d'4 |
      cis'2. fis4~ |
      fis2 a4 cis'4 |
      r1 |
      cis'2 e'2 |
      cis'1~ |
      cis'1~ |
      cis'1 |
      a'4 fis'4 a2 |
      fis2 a4 fis'4 |
      cis'1 |
      e'2 cis'2 |
      cis'4 a2 cis'4 |
      a4 cis'2 a4 |
      cis'4 a2 cis'4 |
      a4 fis4 a4 fis4 |
      a4 fis2 a4 |
      fis4 a2 d'4 |
      fis'4 d'2 b4 |
      fis4 b2 d'4 |
      b4 d'2 b4 |
      d'2. b4~ |
      b1~ |
      b1~ |
      b1 |
      e1~ |
      e4 a2 cis'4 |
      a4 cis'2 a4 |
      cis'4 a4 fis4 a4 |
      fis4 a2 cis'4 |
      a2^\markup { \tiny \italic "Subject" } cis'4 e'4 |
      d'2 fis'4 e'8 d'8 |
      cis'4 b4 a2 |
      a2 gis2 |
      a2 cis'2 |
      cis'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a2^\markup { \tiny \italic "Subject" } cis'4 e'4 |
      d'2 fis'4 e'8 d'8 |
      cis'4 b4 a2 |
      cis4.^\markup { \tiny \italic "Countersubject" } dis16 cis16 b,8 cis8 dis4 |
      cis4. dis8 e4 dis4 |
      e4 dis4 cis2 |
      d2 e2 |
      fis4. e8 d4 e4 |
      a4 b4 fis2 |
      gis1 |
      e8 dis8 cis4 gis2~ |
      gis4 a4 e2 |
      a8 b8 cis'4 a8 b8 cis'4 |
      b4 fis4 cis'2 |
      a4 d4 cis2 |
      cis8 b,8 a,4 fis,2 |
      gis,2 a,2 |
      a,4 g,4 d2~ |
      d4 fis8 g8 a2 |
      b8 a8 g4 d'4 a4~ |
      a4 e'4 b2 |
      b4 e4 a2 |
      e2 b2 |
      e4 a4 gis4 fis4 |
      b2 e2 |
      e4 a4 gis2 |
      fis2 a4 gis4 |
      a4 b4 e'4 cis'4~ |
      cis'4 b2. |
      fis4 gis4 cis'4 d'4 |
      cis'4 a4 e2 |
      r1 |
      e4 a4 cis'2 |
      a4 e4 cis2 |
      fis4 a4 cis'2 |
      a4 fis4 cis2 |
      fis2 a2~ |
      a4 fis4 d2 |
      e4 a4 cis'2 |
      a2 e2 |
      e2 a2~ |
      a4 e4 cis2~ |
      cis4 fis4 a2 |
      cis'2 a2~ |
      a4 d4 fis2 |
      a4 fis4 a4 fis4~ |
      fis2 b2~ |
      b4 d'4 b2 |
      d'2 b2~ |
      b4 b,2. |
      b1 |
      e1~ |
      e1~ |
      e1~ |
      e2 a2~ |
      a4 e4 cis2~ |
      cis4 fis4 a4 fis4 |
      a2 fis2 |
      a4 fis4 gis4 b4 |
      a4 d'4 a4 e4 |
      a4 e4 a2 |
      a4 fis4 b2 |
      a4 e4 cis2 |
      e4 a4 cis'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e2^\markup { \tiny \italic "Real answer" } gis4 b4 |
      a2 cis'4 b8 a8 |
      gis4 fis4 e2 |
      fis4.^\markup { \tiny \italic "Countersubject" } gis16 fis16 e8 fis8 gis4 |
      fis4. gis8 a4 gis4 |
      a4 gis4 fis2 |
      fis2. b,4~ |
      b,2 cis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis4. a8 b2 |
      cis'4 fis'4 e'4 b4~ |
      b4 fis4 gis4. fis8 |
      e2 a4 gis4 |
      a2 e2 |
      fis8 gis8 a4 fis4 gis4 |
      cis'4 d'4 a2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis2 dis'2 |
      e'2. fis'4 |
      b4 fis4 cis'2 |
      e4 b,4 e2 |
      a2 gis8 fis8 e4 |
      fis2. gis4 |
      e4 b4 fis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis4 b,8 cis8 d2 |
      b4 fis4 cis4 a,4 |
      d2. a4~ |
      a2 d'4. cis'8 |
      b4 e'4 a2 |
      cis4 gis,4 dis4 fis,4 |
      cis4 a,4 e,4 b,4~ |
      b,2 gis4 e4 |
      e2 cis2 |
      fis2 cis2 |
      a4 d4 a,4 cis4 |
      e2 b4 fis4 |
      cis4 e2 fis4~ |
      fis2 cis2 |
      r1 |
      cis4 e2. |
      a2 e2 |
      a4 fis4 a2 |
      cis'4 a4 fis4 cis4 |
      d2 fis2 |
      d2 a,2 |
      cis2 e2 |
      a2 cis'2 |
      a2 e2~ |
      e4 cis4 a,4 cis4~ |
      cis2 fis2 |
      cis2 fis2 |
      a,2 d4 fis4~ |
      fis2 d2~ |
      d2 fis2 |
      b2 fis4 b4 |
      d1 |
      b2. b,4~ |
      b,2 e2~ |
      e1~ |
      e1~ |
      e1~ |
      e2 cis2~ |
      cis4 e4 a2 |
      cis2 fis2 |
      cis2 fis2 |
      fis4 a4 e4 b,4 |
      fis2. b4 |
      e4 b,4 d2 |
      a,2 e2 |
      a2 e2 |
      cis2 e2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e2^\markup { \tiny \italic "Real answer" } gis4 b4 |
      a2 cis'4 b8 a8 |
      gis4 fis4 e2 |
      cis4. d8 e4 cis4 |
      fis,4.^\markup { \tiny \italic "Countersubject" } gis,16 fis,16 e,8 fis,8 gis,4 |
      fis,4. gis,8 a,4 gis,4 |
      a,4 gis,4 fis,2 |
      a,2 b,2~ |
      b,2 cis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,8 a,8 b,4 gis,2 |
      cis8 b,8 a,4 e2 |
      b,4 fis4 cis8 d8 e4~ |
      e4 b,4 fis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e8 fis8 gis4 dis2 |
      e4 a4 e4 b,4 |
      e4 a,4 cis2 |
      cis4 fis4 cis2 |
      fis8 e8 d4 a,4 e,4 |
      a,4 d4 a,2 |
      r1 |
      r1 |
      a,4 d4 g,4 b,4 |
      g4 d'4 a2 |
      d2. e4 |
      d4 a,8 g,8 fis,2 |
      b,2 cis4 d4 |
      e2 dis4 fis4 |
      e2. b,4~ |
      b,2 cis2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4 cis2 a,4~ |
      a,4 cis4 e2 |
      a,4 cis2. |
      fis4 cis2. |
      a,4 d4 fis,4 a,4 |
      d2 a2 |
      cis4 a,2. |
      cis4 a,4 e2 |
      cis2. e4~ |
      e1 |
      cis'4 fis2.~ |
      fis4 cis2 a,4~ |
      a,4 d2.~ |
      d2. fis4 |
      d4 fis2. |
      d1~ |
      d1 |
      b,4 d2. |
      b4 e2. |
      gis,4 e2 gis,4~ |
      gis,4 e,2 gis,4 |
      e1~ |
      e4 cis2.~ |
      cis1~ |
      cis2. a,4~ |
      a,4 fis,2 cis,4 |
      r1 |
      r1 |
      r1 |
      fis,4 a,4 e,2 |
      cis2 e2 |
      a4 e4 cis2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e2^\markup { \tiny \italic "Real answer" } gis4 b4 |
      a2 cis'4 b8 a8 |
      gis4 fis4 e2 |
      e,4 fis,4 cis4 e,4 |
      fis,4.^\markup { \tiny \italic "Countersubject" } gis,16 fis,16 e,8 fis,8 gis,4 |
      fis,4. gis,8 a,4 gis,4 |
      a,4 gis,4 fis,2 |
      fis,8 e,8 d,4 b,4 e,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis4 gis,8 a,8 b,2 |
      cis4 fis4 cis4 dis4 |
      b,4 fis4 cis'4 gis4 |
      a4 cis2. |
      fis,2. gis,4 |
      e,4 b,4 fis,4 cis4 |
      r1 |
      r1 |
      a4 d8 cis8 b,2 |
      g,4 d,4 a,4 e,4 |
      b,4 g4 fis4 a,4~ |
      a,4 e,4 b,4 d4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a4 e2 cis4~ |
      cis2 a,4 cis4~ |
      cis2. a,4~ |
      a,2 cis4 a,4~ |
      a,2 d2~ |
      d4 a,4 d4 a,4~ |
      a,4 cis2 e4~ |
      e4 a,2 e,4 |
      e,4 a,4 cis2~ |
      cis4 a,4 cis2~ |
      cis4 a4 fis4 cis4~ |
      cis4 a,2 fis4~ |
      fis2 d2~ |
      d4 a,4 d2~ |
      d2 b,2~ |
      b,4 fis,4 b,2~ |
      b,4 d,2 b,4~ |
      b,4 d,4 b,2~ |
      b,1~ |
      b,1~ |
      b,1~ |
      b,2. e4~ |
      e2 a,4 e,4~ |
      e,4 a,4 cis2~ |
      cis4 fis,4 cis,4 fis,4~ |
      fis,2 a,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 16" shortInstrumentName = "V16" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,2^\markup { \tiny \italic "Real answer" } gis,4 b,4 |
      a,2 cis4 b,8 a,8 |
      gis,4 fis,4 e,2 |
      fis,4.^\markup { \tiny \italic "Countersubject" } gis,16 fis,16 e,8 fis,8 gis,4 |
      fis,4. gis,8 a,4 gis,4 |
      a,4 gis,4 fis,2 |
      cis,2 d,2 |
      e,1 |
      fis,4 d4 g4 b,4~ |
      b,4 fis4 a,4 e4 |
      g,8 a,8 b,2 e,4 |
      a,2 fis4 b,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4 a,2 e,4~ |
      e,4 cis2 a,4~ |
      a,4 cis,2 a,4~ |
      a,4 cis,2 a,4~ |
      a,2. fis,4~ |
      fis,4 d,2 a,4~ |
      a,2. cis4~ |
      cis4 e,2 a,4 |
      a,4 e,2. |
      a,2. cis,4~ |
      cis,4 cis2 fis,4~ |
      fis,4 cis4 fis,2~ |
      fis,4 d4 a,4 fis,4~ |
      fis,4 d2 fis,4~ |
      fis,4 d2. |
      b,2. d,4~ |
      d,4 b,2. |
      b,,2. b,4~ |
      b,1~ |
      b,1~ |
      b,1~ |
      b,4 e,2.~ |
      e,4 e2. |
      cis4 a,2 cis,4~ |
      cis,4 a,2 cis,4~ |
      cis,4 a,2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 17" shortInstrumentName = "V17" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,2^\markup { \tiny \italic "Subject" } cis4 e4 |
      d2 fis4 e8 d8 |
      cis4 b,4 a,2 |
      a,8 gis,8 fis,4 d,2 |
      e,8 fis,8 gis,4 a,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,8 fis,8 e,2 gis,4~ |
      gis,8 fis,4. gis,4 cis4 |
      fis,4 d,4 a,4 e4 |
      a,4 d4 fis,4 cis,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis,2 a,2~ |
      a,4 e4 a,2 |
      cis,2 a,4 cis,4~ |
      cis,2 fis,2~ |
      fis,4 a,,2 fis,4~ |
      fis,2 a,,2~ |
      a,,4 e,4 cis,2~ |
      cis,4 a,2. |
      e,4 a,,4 e,2~ |
      e,4 a,4 cis,4 a,4~ |
      a,4 cis,2. |
      fis,2 a,,2~ |
      a,,4 fis,2. |
      d,4 a,4 d,2~ |
      d,4 b,4 fis,4 d,4~ |
      d,2 b,2~ |
      b,4 b,,2.~ |
      b,,4 b,2.~ |
      b,2 e,2~ |
      e,1~ |
      e,1~ |
      e,1~ |
      e,1 |
      a,2. a,,4~ |
      a,,2 fis,2~ |
      fis,4 cis4 fis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 18" shortInstrumentName = "V18" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,8 d,8 cis,4 cis,,2 |
      a,,2^\markup { \tiny \italic "Subject" } cis,4 e,4 |
      d,2 fis,4 e,8 d,8 |
      cis,4 b,,4 a,,2 |
      a,,2 d,,2 |
      e,,8 fis,,8 gis,,4 a,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,2. a,,4 |
      e,2 a,2~ |
      a,2 cis,2~ |
      cis,2 a,2~ |
      a,4 d,2. |
      a,2. a,,4~ |
      a,,2 e,4 a,,4 |
      e,2. a,,4 |
      a,,2. e,4~ |
      e,2 cis2 |
      cis,2. a,4 |
      cis,2 a,2 |
      a,,2. d,,4 |
      a,,2 fis,2~ |
      fis,2 b,,4 fis,,4 |
      d,2. d,,4 |
      b,,1~ |
      b,,1~ |
      b,,1 |
      e,1~ |
      e,1~ |
      e,1~ |
      e,1 |
      cis2. cis,4~ |
      cis,2. fis,,4 |
      cis,2 a,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 19" shortInstrumentName = "V19" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,4 d,4 cis,4. b,,8 |
      a,,2^\markup { \tiny \italic "Subject" } cis,4 e,4 |
      d,2 fis,4 e,8 d,8 |
      cis,4 b,,4 a,,2 |
      a,,4 b,,4 e,,4 a,,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      cis2 e,2 |
      a,,2. e,4 |
      cis4 fis,2. |
      a,,1 |
      fis,1 |
      a,,1 |
      a,2 a,,2~ |
      a,,4 e,4 a,,2 |
      cis,4 a,2. |
      cis,2 a,2 |
      a,,2 fis,2 |
      a,,1 |
      a,1 |
      d,2 fis,,4 d,4~ |
      d,2 b,2 |
      b,,2 b,,,2 |
      b,,1~ |
      b,,1~ |
      b,,1~ |
      b,,1~ |
      b,,2 e,,2~ |
      e,,1 |
      e,1~ |
      e,4 cis2. |
      cis,1 |
      a,2 cis,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 20" shortInstrumentName = "V20" } {
      \clef "bass" \key a \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,,2^\markup { \tiny \italic "Subject" } cis,4 e,4 |
      d,2 fis,4 e,8 d,8 |
      cis,4 b,,4 a,,2 |
      a,,8 gis,,8 fis,,4 b,,2 |
      e,,4. d,,8 cis,,2 |
      fis,,4 g,,8 a,,8 b,,4 d,4 |
      b,,4.^\markup { \tiny \italic "Countersubject" } cis,16 b,,16 a,,8 b,,8 cis,4 |
      b,,4. cis,8 d,4 cis,4 |
      d,4 cis,4 b,,2 |
      b,,8 a,,8 g,,4 a,,8 g,,8 fis,,4 |
      cis,4.^\markup { \tiny \italic "Countersubject" } dis,16 cis,16 b,,8 cis,8 dis,4 |
      cis,4. dis,8 e,4 dis,4 |
      e,4 dis,4 cis,2 |
      a,,2^\markup { \tiny \italic "Stretto subject" } cis,4 e,4 |
      d,2 fis,4 e,8 d,8 |
      cis,4 b,,4 a,,2 |
      a,,4 e,,4 b,,,2 |
      a,,,4 cis,,4 e,,4 d,,4 |
      fis,,4 a,,2. |
      r1 |
      a,,1~ |
      a,,1~ |
      a,,1~ |
      a,,1 |
      d,,1~ |
      d,,1 |
      a,,1~ |
      a,,1 |
      a,,1~ |
      a,,1 |
      fis,,1~ |
      fis,,1 |
      d,,1~ |
      d,,1 |
      b,,,1~ |
      b,,,1~ |
      b,,,1~ |
      b,,,1 |
      e,,1~ |
      e,,1~ |
      e,,1~ |
      e,,1 |
      a,,1~ |
      a,,1 |
      fis,,1~ |
      fis,,1 |
      fis,,4.^\markup { \tiny \italic "Countersubject" } gis,,16 fis,,16 e,,8 fis,,8 gis,,4 |
      fis,,4. gis,,8 a,,4 gis,,4 |
      a,,4 gis,,4 fis,,2 |
      fis,,2 e,,2 |
      cis,,2 a,,2 |
      a,,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
