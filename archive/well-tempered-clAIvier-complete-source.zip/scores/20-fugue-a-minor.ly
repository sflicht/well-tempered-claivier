\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 14)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XX. Fugue in A minor — The hidden pulse"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a2")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key a \minor \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 92
      \mark \markup \box \small "Exposition 1" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4^\markup { \tiny \italic "Subject" } e'''4 c'''4 a''4 |
      g''4. a''8 b''4 d'''4 |
      c'''2 a''2 |
      c'''4^\markup { \tiny \italic "Countersubject" } d'''8 c'''8 b''4 c'''4 |
      b''4. a''16 b''16 d'''4 c'''4 |
      b''4. a''16 b''16 c'''2 |
      e'''2 gis'''4 a'''4 |
      c'''1 |
      e''4 e'''4 d'''2 |
      a''1 |
      \mark \markup \box \small "Sequential episode" a''1 |
      e''1 |
      \mark \markup \box \small "Exposition 2" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''4 e''4 a''8 g''8 f''4 |
      g''2. a''4~ |
      a''4. g''8 f''2~ |
      f''8 e''8 d''4 g''2~ |
      g''8 fis''8 b''4 fis''2 |
      b''2 g''2 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Exposition 3" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 4" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      r1 |
      \mark \markup \box \small "Exposition 5" r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      \mark \markup \box \small "Sequential episode" r1 |
      \mark \markup \box \small "Development" f'''4 e'''4 f'''2~ |
      f'''2 g'''8 a'''8 bes'''4 |
      f'''2 bes''4. c'''8 |
      \mark \markup \box \small "Linking episode" d'''1 |
      a''1 |
      \mark \markup \box \small "Development" e'''4^\markup { \tiny \italic "Related-key subject" } b'''4 g'''4 e'''4 |
      d'''4. e'''8 fis'''4 a'''4 |
      g'''2 e'''2 |
      \mark \markup \box \small "Stretto" c'''1 |
      e''4 b''8 a''8 g''4 f''4 |
      a''2 a''4^\markup { \tiny \italic "Stretto subject" } e'''4 |
      c'''4 a''4 g''4. a''8 |
      b''4 d'''4 c'''2 |
      a''2 a''4 e''4 |
      \mark \markup \box \small "Caesura" r1 |
      \mark \markup \box \small "Complete ensemble" c'''1 |
      e'''1 |
      c'''1 |
      f'''2 c'''2 |
      f'''1~ |
      f'''2. a'''4 |
      e'''1~ |
      e'''2 c'''2 |
      \mark \markup \box \small "Gathered development" a''2^\markup { \tiny \italic "Subject-head fragment in augmentation" } e'''2 |
      c'''4 e'''2 c'''4~ |
      c'''2. a'''4 |
      c''''4 c'''2 f''4~ |
      f''1~ |
      f''2. d'''4~ |
      d'''4 f'''2.~ |
      f'''1 |
      d'''4 b''2 gis''4 |
      b''2 gis''2 |
      gis'''4 b''2. |
      gis''1~ |
      gis''4 gis'''2. |
      e'''4 gis''4 gis'''4 b'''4 |
      c''''4 e'''4 c'''2~ |
      c'''2. e'''4 |
      a'''2 c''''4 c'''4~ |
      c'''1 |
      \mark \markup \box \small "Final return" c'''4 b''4 c'''2~ |
      c'''2 d'''2 |
      e'''2 d'''2 |
      \mark \markup \box \small "Final cadence" d'''4 f'''4 e'''2~ |
      e'''4 c'''2. |
      c'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4^\markup { \tiny \italic "Subject" } e'''4 c'''4 a''4 |
      g''4. a''8 b''4 d'''4 |
      c'''2 a''2 |
      c'''4^\markup { \tiny \italic "Countersubject" } d'''8 c'''8 b''4 c'''4 |
      b''4. a''16 b''16 d'''4 c'''4 |
      b''4. a''16 b''16 c'''2 |
      c'''4 d'''4 e'''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4 e''2 a'4 |
      e''8 f''8 g''2 d''4 |
      e''2 a''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'''4 e''2. |
      c'''1 |
      c''4 a''2. |
      f'''2 f''2~ |
      f''4 f'''4 a''2 |
      f'''4 a''2.~ |
      a''1 |
      c''4 c'''2. |
      e''1 |
      c'''1 |
      c''2 a''2~ |
      a''2 a'2 |
      f''1 |
      a'4 f''4 a'4 f''4~ |
      f''1 |
      d'''2. d''4~ |
      d''1~ |
      d''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 c''4 e''2 |
      c'''1 |
      c''2 c'''2~ |
      c'''4 f''2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4^\markup { \tiny \italic "Subject" } e'''4 c'''4 a''4 |
      g''4. a''8 b''4 d'''4 |
      c'''2 a''2 |
      c'''4^\markup { \tiny \italic "Countersubject" } d'''8 c'''8 b''4 c'''4 |
      b''4. a''16 b''16 d'''4 c'''4 |
      b''4. a''16 b''16 c'''2 |
      a''4. g''8 f''2~ |
      f''8 e''2.~ e''8 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4 e''4 g'4 d''4 |
      g'4 g''2 d'''4 |
      g''4 c'''4 f''8 g''8 a''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'''2 e''2~ |
      e''4 c'''4 e''4 c'''4~ |
      c'''2 f''2~ |
      f''4 f'''4 a''2~ |
      a''2 d''4 a''4~ |
      a''4 f'''4 a''2~ |
      a''2 c''2~ |
      c''4 a''2. |
      a''2 a'4 e''4~ |
      e''2 c'''2 |
      f''4 a''4 c''2~ |
      c''4 a''2 a'4 |
      d''4 a'2. |
      d''2. a''4 |
      d'''2. f''4~ |
      f''2 d'''2~ |
      d'''4 d''2.~ |
      d''1 |
      b''2 e''2~ |
      e''4 b'2 e''4~ |
      e''4 b''2 e''4~ |
      e''2 b''2 |
      a''2 e''2~ |
      e''4 c'''2. |
      f'''4 c'''4 f''2~ |
      f''4 a'4 f''4 c'''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a''4^\markup { \tiny \italic "Subject" } e'''4 c'''4 a''4 |
      g''4. a''8 b''4 d'''4 |
      c'''2 a''2 |
      c''4^\markup { \tiny \italic "Countersubject" } d''8 c''8 b'4 c''4 |
      b'4. a'16 b'16 d''4 c''4 |
      b'4. a'16 b'16 c''2 |
      f''4. e''8 d''2 |
      e''1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e''4 c'''2 e''4~ |
      e''2 a'2 |
      f''4 a''2. |
      c''2. a''4~ |
      a''2. d''4~ |
      d''4 a''2.~ |
      a''4 c''2 a''4~ |
      a''4 c''2. |
      c''4 a''2. |
      c''2. a''4~ |
      a''4 a'2 f''4~ |
      f''4 a'2 f''4~ |
      f''2 a'4 d''4~ |
      d''4 f'4 d''2~ |
      d''1 |
      b''4 b'2 b''4~ |
      b''4 b'2.~ |
      b'1~ |
      b'1~ |
      b'4 e''2.~ |
      e''1~ |
      e''1~ |
      e''1 |
      a'2. a''4~ |
      a''4 c''2 f''4~ |
      f''2. c''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 05" shortInstrumentName = "V05" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4^\markup { \tiny \italic "Subject" } e''4 c''4 a'4 |
      g'4. a'8 b'4 d''4 |
      c''2 a'2 |
      c''4^\markup { \tiny \italic "Countersubject" } d''8 c''8 b'4 c''4 |
      b'4. a'16 b'16 d''4 c''4 |
      b'4. a'16 b'16 c''2 |
      c''4 d''4 e''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 e''2 a''4~ |
      a''4 c''4 a'2~ |
      a'4 f''2 c'''4~ |
      c'''4 f''2 a'4~ |
      a'2 f''4 d''4~ |
      d''2 f'2 |
      c''2. e''4~ |
      e''2 a'4 e'4 |
      e'4 c''2 a''4~ |
      a''2 c''2~ |
      c''4 f'4 c''4 f''4~ |
      f''2 a'2~ |
      a'4 f''2 a'4~ |
      a'2 d'4 d''4~ |
      d''2. b''4~ |
      b''2 b'2~ |
      b'4 b''4 b'2~ |
      b'1~ |
      b'1~ |
      b'1~ |
      b'2 e''2~ |
      e''1~ |
      e''2 a'4 e''4~ |
      e''2 a'2~ |
      a'4 f''4 c'''4 f''4~ |
      f''2 c''4 f''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 06" shortInstrumentName = "V06" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      e''4^\markup { \tiny \italic "Real answer" } b''4 g''4 e''4 |
      d''4. e''8 fis''4 a''4 |
      g''2 e''2 |
      f''4^\markup { \tiny \italic "Countersubject" } g''8 f''8 e''4 f''4 |
      e''4. d''16 e''16 g''4 f''4 |
      e''4. d''16 e''16 f''2 |
      g''2 d''4 e''4 |
      b'2 a'2 |
      b'2 g'8 fis'8 e'4 |
      gis'8 a'8 b'4 e''4 f''4 |
      c''2.~ c''8 d''8 |
      e''2 b'2 |
      c''8 b'8 a'2. |
      f'4 c'4 f'8 e'8 d'4 |
      b2 c'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 b'4 a'4 c''8 d''8 |
      e''2. d''4 |
      a'2 c''8 b'8 a'4 |
      e'8 fis'8 g'4 d''4 c''4 |
      d''2 a'8 b'8 c''4 |
      g'2 c''8 d''8 e''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4 e'8 f'8 g'4 d''4 |
      g''4. f''8 e''4 d''4 |
      a'4. g'8 f'8 g'8 a'4 |
      e'4 fis'4 b'4 e''4 |
      fis''8 e''8 d''4 a'8 b'8 c''4 |
      g'2 c''8 d''8 e''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'4 e'2 a'4 |
      e''2. a'8 b'8 |
      c''2 f''8 e''8 d''4 |
      g'2. c'4 |
      d'2 a'8 b'8 c''4 |
      g'2. c''4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'2 e''4 a'4 |
      e''2. a'4~ |
      a'2 f''4 c''4~ |
      c''4 f''2. |
      a'4 f'4 a'2 |
      d''2. a''4 |
      c''2 a'2 |
      e''2. a''4 |
      a''4 e''2 c''4~ |
      c''2 e''4 a'4~ |
      a'2. f'4 |
      f''2. a'4~ |
      a'2 f''4 d''4~ |
      d''2 a'4 d''4 |
      f'2. d''4~ |
      d''2 d'4 b'4~ |
      b'2. b4~ |
      b2 b'2~ |
      b'1~ |
      b'1~ |
      b'1 |
      e''1~ |
      e''2. c''4 |
      e''4 a''2 c''4~ |
      c''2 f''4 c''4~ |
      c''2 a'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 07" shortInstrumentName = "V07" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4^\markup { \tiny \italic "Real answer" } b'4 g'4 e'4 |
      d'4. e'8 fis'4 a'4 |
      g'2 e'2 |
      f'4^\markup { \tiny \italic "Countersubject" } g'8 f'8 e'4 f'4 |
      e'4. d'16 e'16 g'4 f'4 |
      e'4. d'16 e'16 f'2 |
      g'2.~ g'8 a'8 |
      b'2 a'2 |
      e'1 |
      a'2 gis'4 a'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f''4 c''4 g'4 d'4 |
      g'8 f'8 e'2 a'4 |
      e'2 d'2 |
      g'2 d'4 e'4 |
      fis'4. e'8 d'4 fis'4 |
      b'2 g'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'4 e'2 a4 |
      e'4 b4 g'4 d''4 |
      g'2 d'2 |
      g'8 a'8 b'4 e'2 |
      fis'2 d''4 a'4 |
      d'4 g'2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a'2 e'2 |
      a'2 e''2 |
      a'2 f'2~ |
      f'2 c''2 |
      f'2 d'2 |
      f'4 a'4 d''4 a'4~ |
      a'2 e'2 |
      a'2 e''2 |
      a'2 e'2 |
      a'2 e'4 c''4~ |
      c''2 f'2 |
      c''2 a'2~ |
      a'2 f'2~ |
      f'4 a'4 d''2~ |
      d''2 f'2~ |
      f'4 d'2. |
      b'2 d'2 |
      b'1~ |
      b'1~ |
      b'1~ |
      b'1~ |
      b'2 e''2~ |
      e''4 e'2. |
      a'2 e''4 a'4~ |
      a'2 c'2 |
      f'2 c''2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 08" shortInstrumentName = "V08" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4^\markup { \tiny \italic "Real answer" } b'4 g'4 e'4 |
      d'4. e'8 fis'4 a'4 |
      g'2 e'2 |
      f'4^\markup { \tiny \italic "Countersubject" } g'8 f'8 e'4 f'4 |
      e'4. d'16 e'16 g'4 f'4 |
      e'4. d'16 e'16 f'2 |
      e'4 d'4 g'2~ |
      g'8 fis'2.~ fis'8 |
      e'4. fis'8 g'2 |
      a'2 d'4 a4 |
      e'1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4 c'8 d'8 e'4 a'4 |
      e'8 f'8 g'4 e'4 a'4 |
      g'8 f'8 e'4 d'8 e'8 f'4 |
      g'4 d'4 g'2 |
      d'2 a'4 e'4 |
      b'2 g'4 c''4 |
      r1 |
      d'4^\markup { \tiny \italic "Related-key subject" } a'4 f'4 d'4 |
      c'4. d'8 e'4 g'4 |
      f'2 d'2 |
      f'2 bes'2 |
      a'1 |
      g'4 fis'4 d''4 c''4 |
      g'2 d'4 e'4 |
      d'2 e'2 |
      e'8 f'8 g'4 e'2 |
      b4. c'8 d'4 a'4~ |
      a'2 e'4 a'4~ |
      a'2 e'4 g'4 |
      d''4 a'2 e'4 |
      a4 c'4 e'4 a'4 |
      r1 |
      a'2 c''4 a'4~ |
      a'4 e'4 a'4 c''4 |
      a'2. f'4 |
      a'2 c''4 a'4~ |
      a'2 d''4 a'4 |
      d'2 a4 d'4 |
      e'2 a'4 e'4 |
      c'2 a4 c'4 |
      c'2. c''4 |
      e'4 c'2. |
      f'2 a'4 c'4 |
      f'4 a'4 f'4 c''4 |
      f'4 a2 a'4~ |
      a'1 |
      b'2 d''2~ |
      d''2 b'2 |
      gis'2. b4 |
      gis2 b4 d'4 |
      b4 e'4 b2~ |
      b1~ |
      b1~ |
      b4 b'2 gis'4 |
      a'2^\markup { \tiny \italic "Subject-head fragment in augmentation" } e''2 |
      e'2. c''4~ |
      c''2 a'2~ |
      a'1 |
      c''4 g'4 c''4 f''4 |
      c''4 g'4 d''4 a'4 |
      c''4 g'4 f'4 d'4 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 09" shortInstrumentName = "V09" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4^\markup { \tiny \italic "Real answer" } b'4 g'4 e'4 |
      d'4. e'8 fis'4 a'4 |
      g'2 e'2 |
      f'4^\markup { \tiny \italic "Countersubject" } g'8 f'8 e'4 f'4 |
      e'4. d'16 e'16 g'4 f'4 |
      e'4. d'16 e'16 f'2 |
      g'1~ |
      g'8 fis'2.~ fis'8 |
      g'2~ g'8 fis'8 e'4 |
      a'2 d''2 |
      b'2 a'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'4 e'4 a'4 d''4 |
      a'8 g'8 f'4 c'4 d'8 e'8 |
      f'2~ f'8 e'8 d'4 |
      r1 |
      r1 |
      c''4 b'2 e'8 fis'8 |
      g'4 d'2 a'4 |
      d'4 g'2 c''4 |
      c''4 g'2 a'4 |
      e'8 f'8 g'2 d'4 |
      e'4 a'2 c''4 |
      f'4 c'2 e'4 |
      d'4 f'4 e'4 c'4~ |
      c'4 e'4 c'4 e'4 |
      r1 |
      c'4 e'2 c'4 |
      a4 c'2 a4 |
      c'4 f'2 a'4 |
      f'4 c'4 a4 c'4 |
      d'4 f'2 a'4 |
      f'2 d'4 f'4 |
      e'4 c'4 e'4 a'4 |
      e'4 c'2 e'4 |
      c'4 e'2 a'4~ |
      a'4 e'4 c'2~ |
      c'4 f'2. |
      c'4 f'2. |
      a4 d'4 f'2 |
      d'4 a2 f4 |
      d'2. b4~ |
      b2. d'4~ |
      d'2 b'2~ |
      b'4 b2. |
      b'1 |
      e'1~ |
      e'1~ |
      e'1~ |
      e'2 a'2~ |
      a'4 e'2 a'4~ |
      a'4 f'2 a'4 |
      f'4 a'2 f'4 |
      a'4 g'2 a'4 |
      e'4 c'4 b4 a4 |
      g4 c'4 f'4 a'4 |
      a'2 e'2 |
      a4 c'4 a4 c'4 |
      a4 c'2 e'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 10" shortInstrumentName = "V10" } {
      \clef "treble" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e'4^\markup { \tiny \italic "Real answer" } b'4 g'4 e'4 |
      d'4. e'8 fis'4 a'4 |
      g'2 e'2 |
      f'4^\markup { \tiny \italic "Countersubject" } g'8 f'8 e'4 f'4 |
      e'4. d'16 e'16 g'4 f'4 |
      e'4. d'16 e'16 f'2 |
      e'4 d'4 e'2 |
      b2 a8 b8 c'4 |
      d'2 e'2 |
      a'2 gis'4 a'8 g'8 |
      f'4 c'2 d'8 e'8 |
      f'2 e'4 d'4 |
      c'8 bes8 a4 d'8 e'8 f'4 |
      f'8 e'8 d'2. |
      a'4 e'4 f'8 e'8 d'4 |
      e'4 b8 c'8 d'4 g'8 a'8 |
      b'8 a'8 g'4 fis'4 e'4 |
      b2 e'8 d'8 c'4 |
      e'8 d'8 c'2 e'4~ |
      e'4 d'4. e'8 f'4 |
      e'8 d'8 c'2 e'4 |
      f'4 e'2 c'4 |
      b4 a4 c'4 e'4 |
      f'4 e'2 c'4 |
      r1 |
      c'4 a2 c'4~ |
      c'4 e'2 c'4~ |
      c'4 a4 c'4 f'4~ |
      f'4 a'2 f'4~ |
      f'4 d'2 f'4~ |
      f'4 d'4 f'4 d'4 |
      c'4 a2 c'4~ |
      c'4 e'2 c'4 |
      c'4 a2 c'4 |
      e'2. a'4~ |
      a'4 f'2 a'4~ |
      a'4 f'4 a'4 f'4~ |
      f'4 d'2 f'4~ |
      f'4 d'4 f'4 d'4~ |
      d'2 f'4 d'4~ |
      d'4 f'2 d'4~ |
      d'2 b4 d'4 |
      b4 d'4 b2~ |
      b2. e'4~ |
      e'1~ |
      e'1~ |
      e'1~ |
      e'4 a'2 e'4~ |
      e'4 c'4 a4 c'4~ |
      c'4 a2 c'4~ |
      c'4 f'2 a'4 |
      a'4 e'2 c'4 |
      e'4 g'2 a'4 |
      e'4 c'4 d'4 f'4 |
      d'2 b4 e'4 |
      c'4 e'2 c'4~ |
      c'4 a2 c'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 11" shortInstrumentName = "V11" } {
      \clef "bass" \key a \minor \time 4/4
      a4^\markup { \tiny \italic "Subject" } e'4 c'4 a4 |
      g4. a8 b4 d'4 |
      c'2 a2 |
      c'4^\markup { \tiny \italic "Countersubject" } d'8 c'8 b4 c'4 |
      b4. a16 b16 d'4 c'4 |
      b4. a16 b16 c'2 |
      a4 g4 a4. b8 |
      c'8 d'8 e'2 d'4 |
      e'8 d'8 c'4 d'2 |
      e'8 fis'8 g'2.~ |
      g'8 fis'2.~ fis'8 |
      d'2 c'2 |
      b8 a8 g4 b4 a4~ |
      a4 g2 f4 |
      g2 d2 |
      e2 c2 |
      c4 f8 g8 a2 |
      gis8 a8 b4 a2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a8 b8 c'4 g4 f4 |
      g8 a8 b2 a8 b8 |
      c'8 b8 a2 c'4 |
      c'4 b4. a8 g4 |
      b8 c'8 d'2 a4 |
      b8 a8 g2 e4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a8 b8 c'4 g4 f4 |
      g8 a8 b4 e'4 f'4 |
      c'4 g4 f8 g8 a4 |
      e4 fis4 e8 fis8 g4 |
      b8 c'8 d'2 e'4 |
      b8 a8 g2 e4 |
      r1 |
      r1 |
      r1 |
      r1 |
      d'8 c'8 bes2 g8 f8 |
      e4 a4 d'8 e'8 f'4 |
      e'4 d'2 e'4 |
      b8 c'8 d'2 a4 |
      b8 a8 g2 e4 |
      e2~ e8 d8 c4 |
      g2 d'2 |
      a2 c2 |
      f4 a4 c'2 |
      d'2 a4 c'4~ |
      c'2. a4 |
      r1 |
      e'1 |
      c'1 |
      f'1 |
      c'2 f2 |
      a4 a'2. |
      a2. f4 |
      c4 c'2.~ |
      c'2 e'2 |
      e'4 c'2 a4 |
      c'4 a2 c'4 |
      a4 c'4 a4 c'4 |
      a4 c'2 a4 |
      f4 a2 f4 |
      a4 d'2 f'4 |
      d'4 b2 d'4 |
      b4 d'2 b4~ |
      b4 d'2 b4 |
      d'4 b4 d'4 b'4 |
      b1~ |
      b1~ |
      b1~ |
      b4 e'2.~ |
      e'4 a2 c'4 |
      a4 c'4 e'4 c'4 |
      a4 c'2 a4 |
      c'4 a2 c'4 |
      a4^\markup { \tiny \italic "Subject" } e'4 c'4 a4 |
      g4. a8 b4 d'4 |
      c'2 a2 |
      a2 gis4 b4 |
      c'2. a4 |
      a1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 12" shortInstrumentName = "V12" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a4^\markup { \tiny \italic "Subject" } e'4 c'4 a4 |
      g4. a8 b4 d'4 |
      c'2 a2 |
      c'4^\markup { \tiny \italic "Countersubject" } d'8 c'8 b4 c'4 |
      b4. a16 b16 d'4 c'4 |
      b4. a16 b16 c'2 |
      a4 g4 a4. b8 |
      c'4 g8 f8 e4 f8 g8 |
      a1 |
      g1 |
      b,4 fis8 g8 a8 g8 fis4 |
      g1 |
      a2 b4 c'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f'4 c'8 d'8 e'4 d'8 c'8 |
      b8 a8 g2 a4~ |
      a2 c'2 |
      g4 b8 c'8 d'4 c'4 |
      d'8 c'8 b4 a4 fis4 |
      b4 e'4 c'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a8 b8 c'4 e'4 d'8 c'8 |
      b8 a8 g4 e4 f4 |
      g8 f8 e4 a4. b8 |
      c'4 g8 a8 b8 a8 g4 |
      d8 e8 fis4 a2 |
      b8 a8 g4 c'2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 a8 bes8 c'4 bes4 |
      f4 c4 g2 |
      c'2 bes2 |
      bes4 f4 g2 |
      e'4 a2. |
      e4 fis4 g2 |
      d8 c8 b,2 e8 fis8 |
      g8 a8 b4 g2 |
      a4 g4 c'2 |
      g4 d4 g4 a4 |
      c'4 a4 c'2 |
      a4 e4 g4 e4 |
      g4 a2. |
      c'4 a4 c'2 |
      r1 |
      a4 c'4 a2 |
      e4 c4 e2 |
      a4 c'4 a4 c'4 |
      a4 f4 a2 |
      f4 a4 f2 |
      d4 f4 a2 |
      c'4 e'4 c'2 |
      a4 e4 a2 |
      a4 c'4 a2 |
      e2 a2 |
      c'4 a4 c'4 a4 |
      f4 c4 f2 |
      a4 f4 a2 |
      f2 d2 |
      f2 d4 f4 |
      d4 b,2. |
      d4 b2. |
      d2 b2~ |
      b1~ |
      b1~ |
      b1 |
      e1~ |
      e4 c'4 a2 |
      e2 a2 |
      c'4 f'4 c'2 |
      a4 f4 a2 |
      a4 b4 g4 f4 |
      g4 e4 d4 f4 |
      g4 e4 a2 |
      f4 a4 e'4 b4 |
      a4 e4 a2 |
      c'4 e'4 c'2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 13" shortInstrumentName = "V13" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a4^\markup { \tiny \italic "Subject" } e'4 c'4 a4 |
      g4. a8 b4 d'4 |
      c'2 a2 |
      c4^\markup { \tiny \italic "Countersubject" } d8 c8 b,4 c4 |
      b,4. a,16 b,16 d4 c4 |
      b,4. a,16 b,16 c2 |
      d4 c2 d4 |
      e2. f4 |
      a1~ |
      a8 g8 fis4 g2 |
      d8 e8 fis2. |
      g1~ |
      g8 f4 g8 a2 |
      gis2 a2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 e8 f8 g4 f4 |
      g8 a8 b4 g4 a4 |
      g2 f2~ |
      f8 e8 d4 g2 |
      b2 a2 |
      e8 fis8 g2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      f4 e8 f8 g4 d'8 c'8 |
      b4. a8 g4 a4 |
      e2 a2 |
      e'4 b4 e'8 d'8 c'4 |
      d'8 c'8 b4 fis4 e8 fis8 |
      g2 c'2 |
      r1 |
      d4 a,4 f4 bes4 |
      c'2 g2 |
      c4 f4 bes2 |
      r1 |
      r1 |
      g4 d4 g4 c4 |
      d2 b,4 e,4 |
      b,8 c8 d4 g2 |
      c8 d8 e4 g4 c'4 |
      b8 c'8 d'4 b4 a4 |
      e2 a2 |
      c'2 g2 |
      d2 e2 |
      a2 e2 |
      r1 |
      e2 a2 |
      c'4 a4 e2 |
      f2 a2 |
      c'4 a4 f2 |
      d2 f2 |
      a2 f2 |
      a2 c'4 a4 |
      c'4 a4 e2 |
      e4 a4 c'2 |
      a2 c'4 a4~ |
      a2 f4 c'4 |
      f2. a4~ |
      a2 d'2 |
      a2 f2~ |
      f2 d'2 |
      f2 d2~ |
      d2. b4~ |
      b2 b,2~ |
      b,2 e2~ |
      e1~ |
      e1~ |
      e1~ |
      e2 c'4 a4 |
      c'4 a4 c'4 a4~ |
      a2 f2 |
      a2 f2 |
      c4 e4 g4 c'4 |
      g2 d2 |
      g2 a2 |
      d2 b2 |
      e2 c2 |
      e2 a2 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 14" shortInstrumentName = "V14" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,4^\markup { \tiny \italic "Subject" } e4 c4 a,4 |
      g,4. a,8 b,4 d4 |
      c2 a,2 |
      c4^\markup { \tiny \italic "Countersubject" } d8 c8 b,4 c4 |
      b,4. a,16 b,16 d4 c4 |
      b,4. a,16 b,16 c2 |
      d4 c2 d4 |
      e2. d4 |
      e8 d8 c4 d2 |
      c4 b,2 e4 |
      b4 fis2. |
      e4 d4 c2 |
      f,8 g,8 a,2. |
      gis,2 a,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d4 e2 d4 |
      g2. d4 |
      g4 c4 f2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4 b,2 e4 |
      b2 fis4 a,4 |
      d8 c8 b,4 g2 |
      c'4 e2~ e8 f8 |
      g2 d4 a,4~ |
      a,4 c4 e4 c4~ |
      c4 e4 c4 g,4~ |
      g,4 d4 a2~ |
      a4 e4 a2 |
      r1 |
      e4 c4 e2~ |
      e4 a4 c'2 |
      f4 c4 f2 |
      a,4 c4 f4 c4 |
      a,4 d2. |
      a4 f2. |
      a,4 c2. |
      e4 a4 c'2 |
      c'4 c4 e2~ |
      e4 a2. |
      c2 f4 c4~ |
      c4 a,4 c4 f4~ |
      f2 d2~ |
      d4 f4 a4 d4~ |
      d2 b,2 |
      d2 b2 |
      b,2 d2~ |
      d4 b2 b,4~ |
      b,1 |
      e1~ |
      e1~ |
      e1 |
      e,4 e2. |
      c4 e4 c2~ |
      c4 f,4 a,2~ |
      a,4 c4 f2 |
      c'4 e2 a4 |
      c'4 e'4 b4 d4 |
      g,2 d2 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 15" shortInstrumentName = "V15" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,4^\markup { \tiny \italic "Subject" } e4 c4 a,4 |
      g,4. a,8 b,4 d4 |
      c2 a,2 |
      c4^\markup { \tiny \italic "Countersubject" } d8 c8 b,4 c4 |
      b,4. a,16 b,16 d4 c4 |
      b,4. a,16 b,16 c2 |
      d4 c2 d4 |
      e2. d4 |
      e8 d8 c4 d2 |
      c4 b,4. a,8 g,4 |
      fis,4. g,8 a,2 |
      b,8 c8 d4 c2 |
      c8 b,8 a,4 b,4 c4 |
      d4 c4 f,4. g,8 |
      a,2 g,2 |
      a,8 bes,8 c4 d2 |
      bes,4. a,8 g,4 d,4 |
      cis,2 d,2 |
      g,4 b,4. a,8 g,4~ |
      g,8 a,8 b,2 c4 |
      d2 c2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a4 e4 c4 e4~ |
      e2 c4 a4~ |
      a4 f4 c4 a,4~ |
      a,2 f4 a4~ |
      a4 d4 a,2~ |
      a,4 d4 a2~ |
      a4 e4 a,2~ |
      a,4 c2 a,4 |
      e,2 c4 e4 |
      a,4 c2 e4 |
      a,2 f2 |
      a4 a,2 a4 |
      a,4 d,2. |
      f,1~ |
      f,4 d,4 b,2~ |
      b,2 d2~ |
      d1~ |
      d2. b,4~ |
      b,4 gis,2. |
      e,1~ |
      e,1 |
      gis,4 e2.~ |
      e4 c4 e,4 a,4~ |
      a,1 |
      f1~ |
      f4 c2. |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 16" shortInstrumentName = "V16" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4^\markup { \tiny \italic "Real answer" } b4 g4 e4 |
      d4. e8 fis4 a4 |
      g2 e2 |
      b,2. c4 |
      f,4^\markup { \tiny \italic "Countersubject" } g,8 f,8 e,4 f,4 |
      e,4. d,16 e,16 g,4 f,4 |
      e,4. d,16 e,16 f,2 |
      a,2~ a,8 g,8 f,4~ |
      f,8 e,2.~ e,8 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c'4 b4 c'2~ |
      c'4 b2 a8 b8 |
      c'8 b8 a2 c'4 |
      g4 d2 e4 |
      b,8 c8 d2 a,4 |
      b,4 e4. d8 c4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d4 g4 c4 a4 |
      e8 f8 g2 d4 |
      g2 d4 f4 |
      c4 g2. |
      b,8 c8 d2 a,4 |
      e4 b,4 e8 d8 c4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g4 b,2 e4 |
      b4 fis2 a,4 |
      d8 c8 b,4 e8 d8 c4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e4 a2 e4~ |
      e4 a,2 e,4 |
      c2. f,4~ |
      f,4 c2 f4~ |
      f4 a,2 d4~ |
      d4 a,2.~ |
      a,4 e2 c4~ |
      c4 e,2. |
      a,2. e,4~ |
      e,4 c4 a,2~ |
      a,4 f4 c2~ |
      c4 f,2.~ |
      f,4 d2 a,4~ |
      a,4 f,2.~ |
      f,4 d2 d,4~ |
      d,4 b,2.~ |
      b,1 |
      b,,2. b,4~ |
      b,1~ |
      b,1~ |
      b,1~ |
      b,4 e,2. |
      e2. a,4~ |
      a,4 c,2 a,4~ |
      a,2. f,4~ |
      f,4 c2 a,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 17" shortInstrumentName = "V17" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,4^\markup { \tiny \italic "Real answer" } b,4 g,4 e,4 |
      d,4. e,8 fis,4 a,4 |
      g,2 e,2 |
      f,2 e,8 d,8 c,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      d4 e2 a4 |
      e2. a4~ |
      a1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g,4 d4 g,2 |
      d2 a,4 e4 |
      g,8 a,8 b,4 e,4 g,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,2 c2~ |
      c4 e,2 a,4~ |
      a,2. f4~ |
      f4 a,2. |
      d4 a,2 f,4~ |
      f,2. a,,4~ |
      a,,2 e,4 c4~ |
      c2 e,2 |
      e,2 a,2~ |
      a,4 e4 a,4 c,4~ |
      c,2 c4 f,4~ |
      f,4 c4 f,2~ |
      f,2. a,4~ |
      a,4 d,2.~ |
      d,4 b,2.~ |
      b,2. b,,4~ |
      b,,2 b,2~ |
      b,1~ |
      b,1~ |
      b,4 e,2.~ |
      e,1~ |
      e,1~ |
      e,2 e2~ |
      e4 a,4 c,2~ |
      c,4 a,4 f4 a,4~ |
      a,2 c4 f,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 18" shortInstrumentName = "V18" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,4^\markup { \tiny \italic "Real answer" } b,4 g,4 e,4 |
      d,4. e,8 fis,4 a,4 |
      g,2 e,2 |
      f,4. e,8 d,2 |
      e,4. d,8 c,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      g,8 a,8 b,4 d4 g,4 |
      d2 a,4 fis4 |
      b,2 e,8 fis,8 g,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,2 a,,4 e,4~ |
      e,2 c2~ |
      c4 f,2. |
      c2. f,4~ |
      f,2 d2 |
      a,1 |
      a,,2. e,4~ |
      e,2 c4 e,4 |
      e,2 c,2 |
      a,2. e,4 |
      f,2. a,,4 |
      f,2. c,4 |
      d,2 a,,2 |
      f,2. a,4 |
      d,1 |
      f,2. d4 |
      d,2. d4~ |
      d2 d,2 |
      e,2. b,,4~ |
      b,,2 e,2 |
      b,,2. e,4~ |
      e,2 b,,4 e,4 |
      c,4 a,,4 c,2 |
      a,2. e,4 |
      f,2. c4~ |
      c2 f,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 19" shortInstrumentName = "V19" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,4^\markup { \tiny \italic "Real answer" } b,4 g,4 e,4 |
      d,4. e,8 fis,4 a,4 |
      g,2 e,2 |
      a,,2 f,2 |
      e,4. d,8 c,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a,2 c,2~ |
      c,2 a,2 |
      c,2 a,4 c,4~ |
      c,2 a,2 |
      a,,2. f,4 |
      a,,2 a,2~ |
      a,2 a,,2~ |
      a,,4 e,2. |
      e,2 a,,2~ |
      a,,2 e,2 |
      a,1 |
      c,2 a,2 |
      d,2 a,2 |
      d,1 |
      b,,1~ |
      b,,1~ |
      b,,1 |
      b,1 |
      e,1 |
      b,,1 |
      e,2 b,,2~ |
      b,,2 e,,2 |
      c,2. e,4~ |
      e,2 c2 |
      f,1 |
      c,2 a,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 20" shortInstrumentName = "V20" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,4^\markup { \tiny \italic "Real answer" } b,4 g,4 e,4 |
      d,4. e,8 fis,4 a,4 |
      g,2 e,2 |
      f,2 e,8 d,8 c,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      c,2 a,2 |
      c,1 |
      a,2 c,4 a,4 |
      a,,1 |
      f,2. a,,4~ |
      a,,1 |
      a,2. c,4~ |
      c,2 a,4 c,4 |
      e,2. a,,4 |
      e,4 a,,2. |
      f,1 |
      a,,2. c,4 |
      f,2. f,,4~ |
      f,,4 d,2. |
      b,2. b,,4~ |
      b,,1~ |
      b,,1~ |
      b,,1~ |
      b,,4 e,,4 b,,4 e,,4~ |
      e,,2 b,,2~ |
      b,,4 e,2. |
      b,,2. b,4 |
      e,2. c4 |
      e,1 |
      a,,2. f,4 |
      a,,2. f,4 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 21" shortInstrumentName = "V21" } {
      \clef "bass" \key a \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      e,,8 f,,8 g,,4 e,4 a,,4 |
      a,,4^\markup { \tiny \italic "Subject" } e,4 c,4 a,,4 |
      g,,4. a,,8 b,,4 d,4 |
      c,2 a,,2 |
      a,,8 g,,8 f,,4 d,,2 |
      e,,4 gis,,,4 a,,,2 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      bes,,4^\markup { \tiny \italic "Countersubject" } c,8 bes,,8 a,,4 bes,,4 |
      a,,4. g,,16 a,,16 c,4 bes,,4 |
      a,,4. g,,16 a,,16 bes,,2 |
      d,,2 g,,2 |
      a,,4. g,,8 f,,2 |
      c,4^\markup { \tiny \italic "Countersubject" } d,8 c,8 b,,4 c,4 |
      b,,4. a,,16 b,,16 d,4 c,4 |
      b,,4. a,,16 b,,16 c,2 |
      a,,4^\markup { \tiny \italic "Stretto subject" } e,4 c,4 a,,4 |
      g,,4. a,,8 b,,4 d,4 |
      c,2 a,,2 |
      a,,4 c,4 e,2 |
      g,,4 f,,4 a,,2 |
      f,,4 c,,2. |
      r1 |
      a,,1~ |
      a,,1~ |
      a,,1~ |
      a,,1 |
      d,,1~ |
      d,,1 |
      a,,1~ |
      a,,1 |
      a,,1~ |
      a,,1 |
      f,,1~ |
      f,,1 |
      d,,1~ |
      d,,1~ |
      d,,1~ |
      d,,1 |
      b,,,1~ |
      b,,,1 |
      e,,1~ |
      e,,1~ |
      e,,1~ |
      e,,1 |
      a,,1~ |
      a,,1 |
      f,,1~ |
      f,,1 |
      f,,4^\markup { \tiny \italic "Countersubject" } g,,8 f,,8 e,,4 f,,4 |
      e,,4. d,,16 e,,16 g,,4 f,,4 |
      e,,4. d,,16 e,,16 f,,2 |
      f,,4 d,,4 e,,4 gis,,4 |
      a,,1 |
      a,,1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #9 }
  }
}
