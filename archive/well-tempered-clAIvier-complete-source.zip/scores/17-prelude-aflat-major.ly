\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XVII. Prelude in A-flat major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key aes \major \time 4/4
      \tempo "Andante cantabile" 4 = 76
      \mark \markup \box \small "Opening cell" c'''2\p des'''4 ees'''4 |
      c'''2 des'''4 ees'''4 |
      des'''4 f'''8 g'''8 f'''4 des'''4 |
      f'''2 g'''4 f'''4 |
      ees'''2 f'''4 ees'''4 |
      c'''2 des'''4 c'''4 |
      des'''4 c'''8 des'''8 c'''4 des'''4 |
      bes''2 aes''4 bes''4 |
      \mark \markup \box \small "Contrasting span" c'''2\mp des'''4 ees'''4 |
      e'''2 ees'''4 e'''4 |
      f'''4 ees'''8 f'''8 ees'''4 f'''4 |
      ees'''2 f'''4 g'''4 |
      f'''2 ees'''4 f'''4 |
      des'''2 ees'''4 f'''4 |
      d'''4 des'''8 d'''8 c'''4 bes''4 |
      g''2 aes''4 bes''4 |
      \mark \markup \box \small "Development" c'''2\mf des'''4 ees'''4 |
      des'''2 ees'''4 f'''4 |
      fes'''4 f'''8 fes'''8 f'''4 fes'''4 |
      ees'''2 f'''4 ees'''4 |
      \mark \markup \box \small "Return" f'''2\mp g'''4 f'''4 |
      f'''2 g'''4 f'''4 |
      f'''4 g'''8 f'''8 g'''4 f'''4 |
      g'''2 g'''4 ees'''4 |
      \mark \markup \box \small "Cadence" ees'''2\p des'''4 ees'''4 |
      c'''2 des'''4 ees'''4 |
      ees'''4 f'''8 ees'''8 bes''4 g''4 |
      aes''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "treble" \key aes \major \time 4/4
      aes8\p bes8 c'8 ees'8 aes8 c'8 aes8 ees'8 |
      aes8 ees'8 c'8 ees'8 aes8 c'8 aes8 ees'8 |
      des'8 ees'8 f'8 aes'8 des'8 f'8 des'8 aes'8 |
      bes8 f'8 des'8 f'8 bes8 des'8 bes8 f'8 |
      ees'8 f'8 g'8 bes'8 ees'8 g'8 ees'8 bes'8 |
      f'8 c''8 aes'8 c''8 f'8 aes'8 f'8 c''8 |
      des'8 ees'8 f'8 aes'8 des'8 f'8 des'8 aes'8 |
      ees'8 bes'8 g'8 bes'8 ees'8 g'8 ees'8 bes'8 |
      aes8\mp bes8 c'8 ees'8 aes8 c'8 aes8 ees'8 |
      c'8 g'8 e'8 g'8 c'8 e'8 c'8 g'8 |
      f'8 g'8 aes'8 c''8 f'8 aes'8 f'8 c''8 |
      c'8 g'8 ees'8 g'8 c'8 ees'8 c'8 g'8 |
      des'8 ees'8 f'8 aes'8 des'8 f'8 des'8 aes'8 |
      bes8 f'8 des'8 f'8 bes8 des'8 bes8 f'8 |
      bes8 c'8 d'8 f'8 bes8 d'8 bes8 f'8 |
      ees'8 bes'8 g'8 bes'8 ees'8 g'8 ees'8 bes'8 |
      aes'8\mf bes'8 c''8 ees''8 aes'8 c''8 aes'8 ees''8 |
      des''8 aes''8 f''8 aes''8 des''8 f''8 des''8 aes''8 |
      des''8 ees''8 fes''8 aes''8 des''8 fes''8 des''8 aes''8 |
      aes'8 ees''8 c''8 ees''8 aes'8 c''8 aes'8 ees''8 |
      f'8\mp g'8 aes'8 c''8 f'8 aes'8 f'8 c''8 |
      des''8 aes''8 f''8 aes''8 des''8 f''8 des''8 aes''8 |
      bes'8 c''8 des''8 f''8 bes'8 des''8 bes'8 f''8 |
      ees''8 bes''8 g''8 bes''8 ees''8 g''8 ees''8 bes''8 |
      aes'8\p bes'8 c''8 ees''8 aes'8 c''8 aes'8 ees''8 |
      aes'8 ees''8 c''8 ees''8 aes'8 c''8 aes'8 ees''8 |
      ees''8 bes''8 g''8 bes''8 ees''8 g''8 ees''8 des''8 |
      c''1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key aes \major \time 4/4
      aes,1\p |
      c1 |
      des1 |
      des1 |
      ees1 |
      f,2.~ f,8 ees,8 |
      des,1 |
      ees,1 |
      c,1\mp |
      c,1 |
      f,1 |
      c,1 |
      des,1 |
      des,2.~ des,8 c,8 |
      bes,,1 |
      ees,1 |
      aes,1\mf |
      des,1 |
      des,1 |
      c,1 |
      f,1\mp |
      des,1 |
      des,1 |
      ees,1 |
      c,1\p |
      ees,1 |
      ees,1 |
      aes,,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
