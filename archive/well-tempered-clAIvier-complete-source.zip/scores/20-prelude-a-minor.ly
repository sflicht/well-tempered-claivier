\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XX. Prelude in A minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key a \minor \time 5/4
      \tempo "Con moto, elastico" 4 = 96
      \mark \markup \box \small "Opening cell" e''4\p a'8 c''8 a''4 e''4 c''4 |
      c''4 f'8 a'8 f''4 c''4 a'4 |
      a'4 d'8 f'8 d''4 a'4 f'4 |
      b'4 gis'8 b'8 e'4 gis'4 e''4 |
      g''4 c''8 e''8 c'''4 g''4 e''4 |
      d''4 g'8 b'8 g''4 d''4 b'4 |
      a'4 f''8 c''8 a'4 c''4 f'4 |
      b'4 e'8 gis'8 e''4 b'4 gis'4 |
      \mark \markup \box \small "Contrasting span" a'4\mp a''8 e''8 c''4 e''4 a'4 |
      b'4 g''8 d''8 b'4 d''4 g'4 |
      f''4 d'''8 a''8 f''4 a''4 d''4 |
      e''4 a'8 c''8 a''4 e''4 c''4 |
      d''4 f''8 e''8 d''4 b'4 f''4 |
      dis''4 fis''8 b''8 dis''4 b'4 fis''4 |
      gis''4 b''8 a''8 gis''4 e''4 b''4 |
      e''4 b''8 gis''8 b''4 e'''4 gis''4 |
      \mark \markup \box \small "Return" a''4\mp e''8 d''8 c''4 a'4 e''4 |
      f''4 a''8 d'''8 f''4 d''4 a''4 |
      f''4 bes'8 d''8 bes''4 f''4 d''4 |
      b'4 gis'8 b'8 e'4 gis'4 e''4 |
      \mark \markup \box \small "Cadence" e''4\p a'8 c''8 a''4 e''4 c''4 |
      e''4 a'8 c''8 a''4 e''4 c''4 |
      b'4 e'8 gis'8 e''4 b'4 gis'4 |
      a'1~ a'4 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key a \minor \time 5/4
      c'4.\p e'4. c'2 |
      a4. c'4. a2 |
      f4. a4. f2~^\markup { \tiny \italic "Prepared suspension" } |
      f8 e4^\markup { \tiny \italic "Resolution" } gis4. e2 |
      e4. g4. e2 |
      g4. b4. g2 |
      a4. c'4. a2~^\markup { \tiny \italic "Prepared suspension" } |
      a8 gis4^\markup { \tiny \italic "Resolution" } b4. b2~^\markup { \tiny \italic "Prepared suspension" } |
      b8 a4^\markup { \tiny \italic "Resolution" } c'4. a2 |
      b4. d'4. b2 |
      d'4. f'4. d'2 |
      c'4. e'4. e'2~^\markup { \tiny \italic "Prepared suspension" } |
      e'8 d'4^\markup { \tiny \italic "Resolution" } f'4. d'2 |
      dis'4. fis'4. dis'2 |
      e'4. gis'4. e'2 |
      gis'4. b'4. e'2 |
      e'4.\mp e'4. c'2 |
      d'4. f'4. d'2 |
      d'4. d'4. bes2 |
      gis4. b4. b2 |
      c'4.\p e'4. c'2 |
      c'4. e'4. c'2 |
      gis4. b4. gis2 |
      a1~ a4 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key a \minor \time 5/4
      e1~\p e4 |
      a1~ a4 |
      a1~ a4 |
      gis1~ gis4 |
      e1~ e4 |
      d1~ d4 |
      c1~ c4 |
      b,1~ b,4 |
      e1~\mp e4 |
      d1~ d4 |
      f1~ f4 |
      e1~ e4 |
      f1~ f4 |
      fis1~ fis4 |
      b1~ b4 |
      b1~ b4 |
      a1~\mp a4 |
      a1~ a4 |
      bes1~ bes4 |
      b1~ b4 |
      a1~\p a4 |
      e1~ e4 |
      d1~ d4 |
      c1~ c4 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key a \minor \time 5/4
      a,2\p a,2. |
      f,2 f,2~ f,8 e,8 |
      d,2 d,2. |
      e,2 e,2. |
      c,2 c,2. |
      g,2 g,2. |
      f,2 f,2. |
      e,2 e,2. |
      a,2\mp a,2. |
      g,2 g,2. |
      d,2 d,2. |
      c,2 c,2. |
      d,2 d,2. |
      b,,2 b,,2. |
      e,2 e,2. |
      e,2 e,2. |
      a,2\mp a,2. |
      d,2 d,2. |
      d,2 d,2. |
      e,2 e,2. |
      c,2\p c,2. |
      e,2 e,2. |
      e,2 e,2. |
      a,,1~ a,,4 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
