\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "III. Fugue in C# major — Bright hinges"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano; optional spatial chamber ensemble"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Voice 01" shortInstrumentName = "V01" } {
      \clef "treble" \key cis \major \time 4/4
      \tempo "Con moto, sempre chiaro" 4 = 120
      \mark \markup \box \small "Continuous exposition" r1 |
      r1 |
      gis''4^\markup { \tiny \italic "Real answer" } bis''4 ais''4 dis'''4 |
      eis'''8 dis'''8 cis'''4 gis''2 |
      ais''4^\markup { \tiny \italic "Countersubject" } gis''8 ais''8 bis''4. cis'''16 bis''16 |
      cis'''8 bis''8 ais''4 eis''2 |
      gis''2 ais''2 |
      gis''4. ais''8 bis''2 |
      \mark \markup \box \small "Subject-head sequence" eis''2 dis''4^\markup { \tiny \italic "Subject-head fragment" } fis''4 |
      gis''2 cis''4^\markup { \tiny \italic "Subject-head fragment" } eis''4 |
      \mark \markup \box \small "Shadow in the relative minor" fis''4^\markup { \tiny \italic "Countersubject" } eis''8 fis''8 gis''4 gisis''4 |
      ais''8 gis''8 fis''2. |
      \mark \markup \box \small "Subject-head sequence" fis''8 gis''8 ais''4 gis''4^\markup { \tiny \italic "Subject-head fragment" } bis''4 |
      gis''2 fis''4^\markup { \tiny \italic "Subject-head fragment" } ais''4 |
      \mark \markup \box \small "Subdominant preparation" fis''2 dis''2 |
      eis''2 fis''2~ |
      \mark \markup \box \small "Stretto" fis''8 eis''4. fis''4 eis''4 |
      fis''4^\markup { \tiny \italic "Stretto subject" } ais''4 gis''4 cis'''4 |
      dis'''8 cis'''8 b''4 fis''2 |
      \mark \markup \box \small "Four-part final return" fis''4 gis''2. |
      cis'''4. bis''8 ais''2 |
      \mark \markup \box \small "Final cadence" ais''2 dis'''2 |
      cis'''1^\markup { \tiny \italic "Cadential tonic arrival" } |
      cis'''1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 02" shortInstrumentName = "V02" } {
      \clef "treble" \key cis \major \time 4/4
      cis''4^\markup { \tiny \italic "Subject" } eis''4 dis''4 gis''4 |
      ais''8 gis''8 fis''4 cis''2 |
      eis'4^\markup { \tiny \italic "Countersubject" } dis'8 eis'8 fisis'4. gis'16 fisis'16 |
      gis'8 fisis'8 eis'4 bis2 |
      eis'2 fis'4 gis'4 |
      cis''4. bis'8 ais'4 gis'4 |
      gis'2 cis''8 bis'8 ais'4 |
      cis''2 bis'2~ |
      bis'8 ais'2.~ ais'8~ |
      ais'8 gis'4 fis'8 eis'4 gis'4 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis'2 gis'2~ |
      gis'2 ais'2 |
      gis'2 fis'4 gis'4 |
      fis'2 eis'2 |
      gis'2 ais'4. b'8 |
      cis''4^\markup { \tiny \italic "Subject" } eis''4 dis''4 gis''4 |
      ais''8 gis''8 fis''4 cis''2 |
      ais'2 gis'4. fis'8 |
      eis'1 |
      eis'1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 03" shortInstrumentName = "V03" } {
      \clef "bass" \key cis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      cis'4^\markup { \tiny \italic "Subject" } eis'4 dis'4 gis'4 |
      ais'8 gis'8 fis'4 cis'2 |
      eis4^\markup { \tiny \italic "Countersubject" } dis8 eis8 fisis4. gis16 fisis16 |
      gis8 fisis8 eis4 bis,2 |
      cis8 dis8 eis4 fis8 gis8 ais4 |
      bis8 ais8 gis2. |
      ais4^\markup { \tiny \italic "Relative-key subject" } cis'4 bis8 cis'16 dis'16 eis'4 |
      fis'8 eis'8 dis'4 ais2 |
      dis'4. cis'8 bis4 dis'4 |
      eis'8 dis'8 cis'4 ais2 |
      ais2 gis2~ |
      gis2 fis2 |
      gis4. ais8 bis2 |
      ais4. bis8 cis'2 |
      gis2 fis4. gis8 |
      ais4^\markup { \tiny \italic "Countersubject" } gis8 ais8 bis4. cis'16 bis16 |
      cis'8 bis8 ais4 eis2 |
      fis2 gis2~ |
      gis1 |
      gis1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
    \new Staff \with { instrumentName = "Voice 04" shortInstrumentName = "V04" } {
      \clef "bass" \key cis \major \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      gis,4^\markup { \tiny \italic "Real answer" } bis,4 ais,4 dis4 |
      eis8 dis8 cis4 gis,2 |
      ais,4^\markup { \tiny \italic "Subject-head fragment" } cis4 dis2 |
      gis,4^\markup { \tiny \italic "Subject-head fragment" } bis,4 cis2 |
      ais,2 eis,2 |
      dis,8 eis,8 fis,2. |
      dis,4^\markup { \tiny \italic "Subject-head fragment" } fis,4 gis,2 |
      cis4^\markup { \tiny \italic "Subject-head fragment" } eis4 fis4. eis8 |
      dis4. cis8 bis,2 |
      cis4. bis,8 ais,4. bis,8 |
      cis4^\markup { \tiny \italic "Stretto subject" } eis4 dis4 gis4 |
      ais8 gis8 fis4 cis2 |
      b,2 ais,2 |
      fis,4 eis,8 fis,8 gis,2 |
      fis,4. gis,8 ais,2 |
      ais,2 bis,2 |
      cis1^\markup { \tiny \italic "Cadential tonic bass" } |
      cis1^\markup { \tiny \italic "Final tonic" } \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
