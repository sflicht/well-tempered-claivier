\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XV. Prelude in G major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key g \major \time 7/8
      \tempo "Allegretto, preciso" 4 = 108
      \mark \markup \box \small "Opening cell" g'8\p b'8 d''8 b'8 g''8 d''8 g'8 |
      d''8 fis''8 a''8 fis''8 g''8 a''8 d''8 |
      g'8 b'8 d''8 b'8 g''8 d''8 g'8 |
      g'8 c'8 d'8 e'8 g'8 e'8 c''8 |
      a'8 c''8 e''8 c''8 a''8 e''8 a'8 |
      d''8 fis''8 a''8 fis''8 g''8 a''8 d''8 |
      g'8 b'8 d''8 b'8 g''8 d''8 g'8 |
      a'8 d'8 e'8 fis'8 a'8 fis'8 d''8 |
      \mark \markup \box \small "Contrasting span" e''8\mp g''8 b''8 g''8 e'''8 b''8 e''8 |
      b'8 d''8 fis''8 d''8 e''8 fis''8 b'8 |
      g''8 e''8 c'''8 g''8 c''8 d''8 e''8 |
      a'8 c''8 e''8 c''8 a''8 e''8 a'8 |
      e''8 cis''8 a''8 e''8 a'8 b'8 cis''8 |
      a''8 fis''8 d'''8 a''8 d''8 d''8 fis''8 |
      g''8 b'8 g''8 d''8 g'8 a'8 b'8 |
      d''8 fis''8 a''8 fis''8 d'''8 a''8 d''8 |
      \mark \markup \box \small "Development" d''8\mf b'8 g''8 d''8 g'8 a'8 b'8 |
      g''8 e''8 c'''8 g''8 c''8 c''8 e''8 |
      b''8 g''8 e'''8 b''8 e''8 fis''8 g''8 |
      b'8 d''8 fis''8 d''8 b''8 fis''8 b'8 |
      a'8 e''8 a''8 c''8 e''8 c''8 a'8 |
      b'8 fis''8 e''8 dis''8 fis''8 dis''8 b'8 |
      e''8 b''8 e'''8 g''8 b''8 g''8 e''8 |
      e''8 c''8 c''8 g''8 fis''8 e''8 g''8 |
      g''8 d'''8 g'''8 b''8 d'''8 b''8 g''8 |
      a''8 e'''8 d'''8 c'''8 e'''8 c'''8 a''8 |
      a''8 e'''8 a'''8 cis'''8 e'''8 cis'''8 a''8 |
      fis''8 d''8 d''8 a''8 g''8 fis''8 a''8 |
      e''8 b''8 e'''8 g''8 b''8 g''8 e''8 |
      b'8 fis''8 e''8 d''8 fis''8 d''8 b'8 |
      c''8 e''8 g''8 e''8 c'''8 g''8 c''8 |
      a'8 d'8 e'8 fis'8 a'8 fis'8 d''8 |
      \mark \markup \box \small "Return" g'8\mp b'8 d''8 b'8 g''8 d''8 g'8 |
      c''8 e''8 g''8 e''8 fis''8 g''8 c''8 |
      c''8 ees''8 g''8 ees''8 c'''8 g''8 c''8 |
      d''8 g'8 a'8 b'8 d''8 b'8 g''8 |
      \mark \markup \box \small "Cadence" a''8\p c'''8 e'''8 c'''8 a'''8 e'''8 a''8 |
      g''8 b''8 d'''8 b''8 c'''8 d'''8 g''8 |
      d''8 fis''8 a''8 fis''8 d'''8 a''8 fis''8 |
      g''2.~ g''8 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key g \major \time 7/8
      b4\p b4 g4. |
      fis4 a4 fis4. |
      g4 b4 b4. |
      c'4 g4 c'4. |
      c'4 e'4 c'4. |
      d'4 fis'4 d'4. |
      d'4 g'4 g'4. |
      d'4 a4 d'4. |
      g'4\mp g'4 e'4. |
      d'4 fis'4 d'4. |
      e'4 g'4 e'4. |
      c'4 e'4 c'4. |
      cis'4 e'4 cis'4. |
      fis'4 fis'4 d'4. |
      b4 b4 g4. |
      fis4 a4 fis4. |
      g4\mf b4 b4. |
      e'4 e'4 e'4. |
      g'4 g'4 e'4. |
      d'4 fis'4 d'4. |
      c'4 e'4 c'4. |
      b4 dis'4 dis'4. |
      g'4 b'4 g'4. |
      e'4 e'4 c'4. |
      b4 d'4 b4. |
      c'4 e'4 c'4. |
      cis'4 e'4 cis'4. |
      d'4 fis'4 fis'4. |
      g'4 g'4 e'4. |
      d'4 fis'4 d'4. |
      e'4 e'4 c'4. |
      d'4 a4 d'4. |
      b4\mp d'4 b4. |
      e'4 e'4 c'4. |
      ees'4 ees'4 c'4. |
      b4 d'4 b4. |
      c'4\p e'4 c'4. |
      b4 b4 g4. |
      fis4 fis4 d4. |
      d2.~ d8 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key g \major \time 7/8
      d2.~\p d8 |
      fis2.~ fis8 |
      g2.~ g8 |
      g2.~ g8 |
      e2.~ e8 |
      fis2.~ fis8 |
      g2.~ g8 |
      a2.~ a8 |
      b2.~\mp b8 |
      fis2.~ fis8 |
      g2.~ g8 |
      e2.~ e8 |
      e2.~ e8 |
      fis2.~ fis8 |
      g2.~ g8 |
      a2.~ a8 |
      g2.~\mf g8 |
      e2.~ e8 |
      g2.~ g8 |
      fis2.~ fis8 |
      e2.~ e8 |
      fis2.~ fis8 |
      b2.~ b8 |
      g2.~ g8 |
      d2.~ d8 |
      e2.~ e8 |
      e2.~ e8 |
      a2.~ a8 |
      g2.~ g8 |
      fis2.~ fis8 |
      g2.~ g8 |
      a2.~ a8 |
      g2.~\mp g8 |
      g2.~ g8 |
      g2.~ g8 |
      d2.~ d8 |
      e2.~\p e8 |
      d2.~ d8 |
      c2.~ c8 |
      b,2.~ b,8 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key g \major \time 7/8
      g,4.\p g,4 g,4 |
      d,4. d,4 d,4 |
      b,,4. b,,4 b,,4 |
      c,4. c,4 c,4 |
      c,4. c,4 c,4 |
      d,4. d,4 d,4 |
      g,4. g,4 g,4 |
      d,4. d,4 d,4 |
      e,4.\mp e,4 e,4 |
      b,,4. b,,4 b,,4 |
      c,4. c,4 c,4 |
      c,4. c,4 c,4 |
      a,,4. a,,4 a,,4 |
      d,4. d,4 d,4 |
      g,4. g,4 g,4 |
      d,4. d,4 d,4 |
      b,,4.\mf b,,4 b,,4 |
      c,4. c,4 c,4 |
      e,4. e,4 e,4 |
      b,,4. b,,4 b,,4 |
      c,4. c,4 c,4 |
      b,,4. b,,4 b,,4 |
      e,4. e,4 e,4 |
      c,4. c,4 c,4 |
      g,4. g,4 g,4 |
      c,4. c,4 c,4 |
      a,,4. a,,4 a,,4 |
      d,4. d,4 d,4 |
      e,4. e,4 e,4 |
      b,,4. b,,4 b,,4 |
      c,4. c,4 c,4 |
      d,4. d,4 d,4 |
      g,4.\mp g,4 g,4 |
      c,4. c,4 c,4 |
      c,4. c,4 c,4 |
      b,,4. b,,4 b,,4 |
      c,4.\p c,4 c,4 |
      d,4. d,4 d,4 |
      d,4. d,4 d,4 |
      g,,2.~ g,,8 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
