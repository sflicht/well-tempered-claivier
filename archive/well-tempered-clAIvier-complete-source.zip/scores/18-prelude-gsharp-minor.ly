\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XVIII. Prelude in G-sharp minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 3-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key gis \minor \time 6/8
      \tempo "Moderato, oscuro" 4 = 100
      \mark \markup \box \small "Opening cell" gis8\p ais8 b8 gis'8 b8 dis'8 |
      dis8 ais8 fisis8 dis'8 fisis8 ais8 |
      gis8 ais8 b8 gis'8 b8 dis'8 |
      e8 gis8 cis8 gis8 e8 cis'8 |
      fis8 gis8 ais8 fis'8 ais8 cis'8 |
      b8 fis'8 dis'8 b'8 dis'8 fis'8 |
      e'8 fis'8 gis'8 e''8 gis'8 b'8 |
      fisis'8 ais'8 dis'8 ais'8 fisis'8 dis''8 |
      \mark \markup \box \small "Contrasting span" b'8\mp gis''8 b'8 ais'8 gis'8 dis''8 |
      ais'8 fis''8 ais'8 cis''8 fis'8 cis''8 |
      gis'8 e''8 gis'8 fis'8 e'8 b'8 |
      dis'8 ais'8 fisis'8 dis''8 fisis'8 ais'8 |
      dis'8 b'8 dis'8 cis'8 b8 fis'8 |
      gis'8 e''8 gis'8 b'8 e'8 b'8 |
      e'8 cis''8 e'8 dis'8 cis'8 gis'8 |
      ais'8 eis''8 cisis''8 ais''8 cisis''8 eis''8 |
      \mark \markup \box \small "Development" ais''8\mf fisis''8 dis'''8 fisis''8 ais''8 dis''8 |
      ais''8 fisis''8 dis'''8 fisis''8 ais''8 dis''8 |
      dis''8 b'8 gis''8 b'8 dis''8 gis'8 |
      b'8 e'8 b'8 gis'8 e''8 gis'8 |
      gis'8 e'8 cis''8 e'8 gis'8 cis'8 |
      dis'8 b8 gis'8 b8 dis'8 gis8 |
      e'8 cis'8 ais'8 cis'8 e'8 ais8 |
      ais8 dis8 ais8 fisis8 dis'8 fisis8 |
      \mark \markup \box \small "Return" b,8\mp cis8 dis8 b8 dis8 fis8 |
      cis8 gis8 e8 cis'8 e8 gis8 |
      a8 b8 cis'8 a'8 cis'8 e'8 |
      fisis8 ais8 dis8 ais8 fisis8 dis'8 |
      \mark \markup \box \small "Cadence" gis8\p ais8 b8 gis'8 b8 dis'8 |
      cis'8 gis'8 e'8 cis''8 e'8 gis'8 |
      dis'8 ais'8 fisis'8 dis''8 fisis'8 fisis'8 |
      gis'2. \bar "|."
    }
    \new Staff \with { instrumentName = "Inner figure" shortInstrumentName = "I." } {
      \clef "bass" \key gis \minor \time 6/8
      dis8\p gis,8 b,8 gis,8 dis8 b,8 |
      ais,8 dis,8 fisis,8 dis,8 ais,8 fisis,8 |
      gis,8 gis,8 b,8 gis,8 dis8 b,8 |
      gis8 cis8 e8 cis8 gis8 e8 |
      cis8 fis,8 ais,8 fis,8 cis8 ais,8 |
      fis8 b,8 dis8 b,8 fis8 dis8 |
      b8 e8 gis8 e8 b8 gis8 |
      ais8 dis8 fisis8 dis8 ais8 fisis8 |
      gis8\mp gis8 b8 gis8 dis'8 b8 |
      cis'8 fis8 ais8 fis8 cis'8 ais8 |
      b8 e8 gis8 e8 b8 gis8 |
      ais8 dis8 fisis8 dis8 ais8 fisis8 |
      fis8 b,8 dis8 b,8 fis8 dis8 |
      b8 e8 gis8 e8 b8 gis8 |
      gis8 cis8 e8 cis8 gis8 e8 |
      eis8 ais,8 cisis8 ais,8 eis8 cisis8 |
      ais8\mf dis8 fisis8 dis8 ais8 fisis8 |
      ais8 dis8 fisis8 dis8 ais8 fisis8 |
      gis8 gis8 b8 gis8 dis'8 b8 |
      b8 e8 gis8 e8 b8 gis8 |
      gis8 cis8 e8 cis8 gis8 e8 |
      dis8 gis,8 b,8 gis,8 dis8 b,8 |
      e8 ais,8 cis8 ais,8 e8 cis8 |
      ais8 dis8 fisis8 dis8 ais8 fisis8 |
      fis8\mp b,8 dis8 b,8 fis8 dis8 |
      gis8 cis8 e8 cis8 gis8 e8 |
      e8 a,8 cis8 a,8 e8 cis8 |
      ais,8 dis,8 fisis,8 dis,8 ais,8 fisis,8 |
      gis,8\p gis,8 b,8 gis,8 dis8 b,8 |
      gis8 cis8 e8 cis8 gis8 e8 |
      ais8 dis8 fisis8 dis8 ais8 cis'8 |
      b2. \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key gis \minor \time 6/8
      gis,4.\p gis,4. |
      dis,4. dis,4 cis,8 |
      b,,4. b,,4. |
      cis,4. cis,4. |
      fis,4. fis,4. |
      b,,4. b,,4. |
      e,4. e,4. |
      dis,4. dis,4. |
      gis,4.\mp gis,4. |
      fis,4. fis,4. |
      e,4. e,4. |
      dis,4. dis,4. |
      b,,4. b,,4. |
      e,4. e,4 dis,8 |
      cis,4. cis,4 b,,8 |
      ais,,4. ais,,4. |
      dis,4.\mf dis4. |
      dis,4. dis4. |
      gis,4. gis4. |
      e,4. e4. |
      cis,4. cis4. |
      b,,4. b,4. |
      cis,4. cis4. |
      dis,4. dis4. |
      b,,4.\mp b,,4. |
      cis,4. cis,4. |
      cis,4. cis,4. |
      dis,4. dis,4. |
      gis,4.\p gis,4. |
      cis,4. cis,4. |
      dis,4. dis,4. |
      gis,,2. \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
