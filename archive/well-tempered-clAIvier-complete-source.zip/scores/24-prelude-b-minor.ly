\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XXIV. Prelude in B minor"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 5-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key b \minor \time 4/4
      \tempo "Sostenuto, poi con moto" 4 = 82
      \mark \markup \box \small "Opening cell" b'2\p cis''4 d''4 |
      fis''2 g''4 fis''4 |
      g''2 a''4 g''4 |
      g''2 fis''4 e''4 |
      cis''2 d''4 cis''4 |
      cis''2 d''4 cis''4 |
      d''2 e''4 d''4 |
      cis''2 d''4 cis''4 |
      \mark \markup \box \small "Contrasting span" d''2\mp cis''4 d''4 |
      e''2 a''4 cis'''4 |
      g'''8 b''8 d'''8 cis'''8 b''8 g'''8 g''8 d'''8 |
      d'''8 a'''8 d''''8 fis'''8 a'''8 d'''8 fis'''8 d''''8 |
      e'''8 g''8 b''8 a''8 g''8 e'''8 e''8 b''8 |
      cis'''8 eis''8 gis''8 cis''8 eis''8 cis'''8 cis''8 gis''8 |
      fis''8 ais'8 cis''8 b'8 ais'8 fis''8 fis'8 cis''8 |
      fis'8 cis''8 fis''8 ais'8 cis''8 fis'8 ais'8 fis''8 |
      \mark \markup \box \small "Development" b''8\mf d''8 fis''8 e''8 d''8 b''8 b'8 fis''8 |
      a''8 cis''8 e''8 a'8 cis''8 a''8 a'8 e''8 |
      g''8 b'8 d''8 cis''8 b'8 g''8 g'8 d''8 |
      fis''8 cis'''8 fis'''8 ais''8 cis'''8 fis''8 ais''8 fis'''8 |
      d''''16 fis'''16 g'''16 a'''16 fis'''16 d''''16 a'''16 d'''16 d''''16 fis'''16 d'''16 a'''16 fis'''16 d''''16 a'''16 d'''16 |
      g'''16 b''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 g'''16 b''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 |
      e'''16 g''16 a''16 b''16 g''16 e'''16 b''16 e''16 e'''16 g''16 e''16 b''16 g''16 e'''16 b''16 e''16 |
      cis'''16 fis''16 fis'''16 ais''16 fis''16 cis'''16 ais''16 fis'''16 cis'''16 fis''16 fis'''16 ais''16 fis''16 cis'''16 ais''16 fis'''16 |
      b'''16 d'''16 e'''16 fis'''16 d'''16 b'''16 fis'''16 b''16 b'''16 d'''16 b''16 fis'''16 d'''16 b'''16 fis'''16 b''16 |
      g'''16 b''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 g'''16 b''16 g''16 d'''16 b''16 g'''16 d'''16 g''16 |
      e'''16 g''16 a''16 b''16 g''16 e'''16 b''16 e''16 e'''16 g''16 e''16 b''16 g''16 e'''16 b''16 e''16 |
      fis''16 b'16 b''16 d''16 b'16 fis''16 d''16 b''16 fis''16 b'16 b''16 d''16 b'16 fis''16 d''16 b''16 |
      c'''16 e''16 fis''16 g''16 e''16 c'''16 g''16 c''16 c'''16 e''16 c''16 g''16 e''16 c'''16 g''16 c''16 |
      fis''16 ais'16 fis'16 cis''16 ais'16 fis''16 cis''16 fis'16 fis''16 ais'16 fis'16 cis''16 ais'16 fis''16 cis''16 fis'16 |
      b'4. d''8 g''4 b''4~^\markup { \tiny \italic "Prepared suspension" } |
      b''8 ais''4^\markup { \tiny \italic "Resolution" } fis''8 ais''4 fis''4 |
      \mark \markup \box \small "Return" d''4.\mp fis''8 d''4 d''4 |
      g''4. b''8 g''4 e''4 |
      g''4. g''8 fis''4 g''4 |
      fis''4. fis''8 e''4 fis''4 |
      \mark \markup \box \small "Cadence" fis''4.\p e''8 d''4 b'4 |
      d''4. fis''8 d''4 b'4 |
      cis''4. cis''8 b'4 ais'4 |
      b'1 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key b \minor \time 4/4
      d'4\p fis'4 d'2 |
      d'4 d'4 b2 |
      b4 b4 g2 |
      g4 b4 g2 |
      fis4 ais4 fis2 |
      ais4 cis'4 ais2 |
      b4 d'4 b2 |
      ais4 ais4 fis2 |
      fis4\mp a4 fis2 |
      a4 cis'4 a2 |
      b4 d'4 d'2 |
      fis'4 a'4 fis'2 |
      g'4 g'4 e'2 |
      eis'4 gis'4 eis'2 |
      ais'4 ais'4 fis'2 |
      cis'4 fis'4 fis'2 |
      b'4\mf d''4 b'2 |
      cis''4 cis''4 a'2 |
      b'4 b'4 g'2 |
      fis'4 ais'4 fis'2 |
      fis'4 a'4 fis'2 |
      b'4 b'4 g'2 |
      g'4 b'4 g'2 |
      fis'4 ais'4 ais'2 |
      b'4 d''4 b'2 |
      b'4 d''4 b'2 |
      g'4 b'4 g'2 |
      b'4 fis'4 b'2 |
      e''4 c''4 c''2 |
      ais'4 fis'4 fis'2 |
      g'4 g'4 g'2 |
      fis'4 fis'4 fis'2 |
      d'4\mp fis'4 d'2 |
      e'4 g'4 e'2 |
      e'4 e'4 cis'2 |
      ais4 cis'4 ais2 |
      b4\p d'4 b2 |
      d'4 d'4 b2 |
      ais4 cis'4 ais2 |
      b1 \bar "|."
    }
    \new Staff \with { instrumentName = "Middle" shortInstrumentName = "I." } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      a8\mp d8 fis8 a8 fis8 d8 a8 fis8 |
      e8 a,8 cis8 e8 cis8 a,8 e8 cis8 |
      d8 g,8 b,8 d8 b,8 g,8 d8 b,8 |
      a8 d8 fis8 a8 fis8 d8 a8 fis8 |
      b8 e8 g8 b8 g8 e8 b8 g8 |
      gis8 cis8 eis8 gis8 eis8 cis8 gis8 eis8 |
      cis8 fis,8 ais,8 cis8 ais,8 fis,8 cis8 ais,8 |
      cis8 fis,8 ais,8 cis8 ais,8 fis,8 cis8 ais,8 |
      b,8\mf b,8 d8 fis8 d8 b,8 fis8 d8 |
      e8 a,8 cis8 e8 cis8 a,8 e8 cis8 |
      d8 g,8 b,8 d8 b,8 g,8 d8 b,8 |
      cis8 fis,8 ais,8 cis8 ais,8 fis,8 cis8 ais,8 |
      a8 d8 fis8 a8 fis8 d8 a8 fis8 |
      d'8 g8 b8 d'8 b8 g8 d'8 b8 |
      b8 e8 g8 b8 g8 e8 b8 g8 |
      cis'8 fis8 ais8 cis'8 ais8 fis8 cis'8 ais8 |
      b8 b8 d'8 fis'8 d'8 b8 fis'8 d'8 |
      d'8 g8 b8 d'8 b8 g8 d'8 b8 |
      b8 e8 g8 b8 g8 e8 b8 g8 |
      fis8 b,8 d8 fis8 d8 b,8 fis8 d8 |
      g8 c8 e8 g8 e8 c8 g8 e8 |
      cis'8 fis8 ais8 cis'8 ais8 fis8 cis'8 ais8 |
      b8 g8 b8 d'8 b8 g8 d'8 b8 |
      cis'8 fis8 ais8 cis'8 ais8 fis8 cis'8 ais8 |
      b8\mp b8 d'8 fis'8 d'8 b8 fis'8 d'8 |
      b8 e8 g8 b8 g8 e8 b8 g8 |
      g8 cis8 e8 g8 e8 cis8 g8 e8 |
      cis8 fis,8 ais,8 cis8 ais,8 fis,8 cis8 ais,8 |
      b,8\p b,8 d8 fis8 d8 b,8 fis8 d8 |
      fis8 b,8 d8 fis8 d8 b,8 fis8 d8 |
      cis8 fis,8 ais,8 cis8 ais,8 fis,8 cis8 e8 |
      d1 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key b \minor \time 4/4
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      r1 |
      fis,2\mf fis,2 |
      e,2 e,2 |
      g,2 g,2 |
      fis,2 fis,2 |
      fis,2 fis,2 |
      g,2 g,2 |
      g,2 b,2 |
      ais,2 cis2 |
      d2 fis2 |
      d2 b,2 |
      g,2 b,2 |
      d2 fis2 |
      e2 e2 |
      cis2 cis2 |
      b,2 d2 |
      cis2 cis2 |
      fis,2\mp fis,2 |
      g,2 b,2 |
      g,2 g,2 |
      cis2 cis2 |
      r1 |
      r1 |
      r1 |
      d1 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key b \minor \time 4/4
      b,,1\p |
      d,1 |
      g,,1 |
      e,,1 |
      fis,,1 |
      fis,,1 |
      b,,1 |
      fis,,1 |
      d,,1\mp |
      a,,1 |
      g,,1 |
      d,1 |
      e,1 |
      cis,1 |
      fis,,1 |
      fis,,1 |
      b,,1\mf |
      a,,1 |
      g,,1 |
      fis,,1 |
      d,,1 |
      g,,1 |
      e,,1 |
      fis,,1 |
      b,,1 |
      g,,1 |
      e,,1 |
      d,,1 |
      e,,1 |
      fis,,1 |
      g,,1 |
      fis,,1 |
      b,,1\mp |
      e,1 |
      e,1 |
      fis,1 |
      d,1\p |
      fis,1 |
      fis,1 |
      b,,1 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
