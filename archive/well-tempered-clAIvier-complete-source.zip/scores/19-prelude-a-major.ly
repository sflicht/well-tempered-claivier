\version "2.24.3"
\language "nederlands"
#(set-global-staff-size 16)
\header {
  title = "The Well-Tempered clAIvier"
  subtitle = "XIX. Prelude in A major"
  composer = "ChatGPT / composed for Sam"
  instrument = "Piano — 4-layer study score"
  tagline = "Original composition - second working edition"
}
\paper {
  #(set-paper-size "a4")
  top-margin = 13\mm
  bottom-margin = 14\mm
  left-margin = 15\mm
  right-margin = 12\mm
  print-page-number = ##t
  ragged-last-bottom = ##f
  system-system-spacing.basic-distance = #18
  system-system-spacing.padding = #7
}
\score {
  \new StaffGroup <<
    \new Staff \with { instrumentName = "Melody" shortInstrumentName = "M." } {
      \clef "treble" \key a \major \time 9/8
      \tempo "Allegro fluente" 4 = 110
      \mark \markup \box \small "Opening cell" a'8\p cis''8 e''8 d''8 cis''8 e''8 cis'''8 e''8 cis''8 |
      d''8 fis''8 a''8 d'''8 fis''8 a''8 fis'''8 a''8 fis''8 |
      a'8 cis''8 e''8 d''8 cis''8 e''8 cis'''8 e''8 cis''8 |
      fis'8 d'8 b8 d'8 fis'8 b'8 d'8 fis'8 d''8 |
      e''8 gis''8 b''8 a''8 gis''8 b''8 gis'''8 b''8 gis''8 |
      a''8 cis'''8 e'''8 a'''8 cis'''8 e'''8 cis''''8 e'''8 cis'''8 |
      fis''8 a''8 cis'''8 b''8 a''8 cis'''8 a'''8 cis'''8 a''8 |
      gis''8 e''8 cis''8 e''8 gis''8 cis'''8 e''8 gis''8 e'''8 |
      \mark \markup \box \small "Contrasting span" a''8\mp gis''8 fis''8 a''8 fis'''8 a''8 fis''8 d''8 fis''8 |
      fis''8 b''8 dis''8 fis''8 dis'''8 fis''8 dis''8 b'8 dis''8 |
      b'8 a'8 gis'8 b'8 gis''8 b'8 gis'8 e'8 gis'8 |
      a'8 cis''8 e''8 a''8 cis''8 e''8 cis'''8 e''8 cis''8 |
      cis''8 b'8 a'8 cis''8 a''8 cis''8 a'8 fis'8 a'8 |
      gis'8 cis''8 eis'8 gis'8 eis''8 gis'8 eis'8 cis'8 eis'8 |
      cis''8 b'8 a'8 cis''8 a''8 cis''8 a'8 fis'8 a'8 |
      d''8 fis''8 a''8 d'''8 fis''8 a''8 fis'''8 a''8 fis''8 |
      \mark \markup \box \small "Development" cis''8\mf e''8 cis'''8 e''8 cis''8 d''8 e''8 cis''8 a'8 |
      e''8 gis''8 e'''8 gis''8 e''8 cis'''8 gis''8 e''8 cis''8 |
      fis''8 a''8 fis'''8 a''8 fis''8 gis''8 a''8 fis''8 d''8 |
      d''8 b'8 d''8 fis''8 d'''8 fis''8 d''8 b''8 fis''8 |
      a''8 cis'''8 a'''8 cis'''8 a''8 b''8 cis'''8 a''8 fis''8 |
      fis''8 a''8 fis'''8 a''8 fis''8 d'''8 a''8 fis''8 d''8 |
      d''8 fis''8 d'''8 fis''8 d''8 e''8 fis''8 d''8 b'8 |
      gis'8 e'8 gis'8 b'8 gis''8 b'8 gis'8 e''8 b'8 |
      \mark \markup \box \small "Return" a'8\mp cis''8 e''8 d''8 cis''8 e''8 cis'''8 e''8 cis''8 |
      d''8 fis''8 a''8 d'''8 fis''8 a''8 fis'''8 a''8 fis''8 |
      d''8 f''8 a''8 d'''8 f''8 a''8 f'''8 a''8 f''8 |
      e''8 cis''8 a'8 cis''8 e''8 a''8 cis''8 e''8 cis'''8 |
      \mark \markup \box \small "Cadence" b''8\p d'''8 fis'''8 e'''8 d'''8 fis'''8 d''''8 fis'''8 d'''8 |
      a''8 cis'''8 e'''8 a'''8 cis'''8 e'''8 cis''''8 e'''8 cis'''8 |
      e''8 gis''8 b''8 e'''8 gis''8 b''8 gis'''8 b''8 gis''8 |
      a''1~ a''8 \bar "|."
    }
    \new Staff \with { instrumentName = "Upper inner" shortInstrumentName = "U." } {
      \clef "treble" \key a \major \time 9/8
      cis'4.\p e'4. cis'4. |
      fis'4. fis'4. d'4. |
      cis'4. e'4. cis'4. |
      d'4. b4. b4. |
      e'4. gis'4. e'4. |
      cis'4. cis'4. a4. |
      a4. cis'4. a4. |
      cis'4. e'4. cis'4. |
      fis'4.\mp fis'4. d'4. |
      dis'4. fis'4. dis'4. |
      gis'4. gis'4. e'4. |
      e'4. a'4. a'4. |
      a'4. a'4. fis'4. |
      eis'4. eis'4. cis'4. |
      fis'4. a'4. fis'4. |
      fis'4. fis'4. d'4. |
      cis'4.\mf e'4. cis'4. |
      e'4. gis'4. e'4. |
      fis'4. fis'4. d'4. |
      d'4. fis'4. d'4. |
      fis'4. a'4. fis'4. |
      a'4. fis'4. d'4. |
      d'4. fis'4. d'4. |
      e'4. gis'4. e'4. |
      cis'4.\mp e'4. cis'4. |
      fis'4. fis'4. d'4. |
      f'4. f'4. d'4. |
      cis'4. e'4. cis'4. |
      d'4.\p d'4. b4. |
      cis'4. cis'4. a4. |
      gis4. gis4. e4. |
      e1~ e8 \bar "|."
    }
    \new Staff \with { instrumentName = "Lower inner" shortInstrumentName = "L." } {
      \clef "bass" \key a \major \time 9/8
      e2.\p e4. |
      fis2. fis4. |
      e2. e4. |
      fis2. fis4. |
      gis2. b4. |
      cis'2. e'4. |
      cis'2. a4. |
      gis2. e4. |
      fis2.\mp fis4. |
      dis2. fis4. |
      gis2. b4. |
      cis'2. e'4. |
      cis'2. a4. |
      gis2. eis4. |
      a2. fis4. |
      a2. fis4. |
      e2.\mf e4. |
      gis2. e4. |
      a2. fis4. |
      fis2. d4. |
      cis2. a,4. |
      a,2. fis,4. |
      fis,2. fis,4. |
      b,2. b,4. |
      cis2.\mp e4. |
      fis2. fis4. |
      a2. f4. |
      e2. e4. |
      fis2.\p d4. |
      e2. cis4. |
      b,2. d4. |
      cis1~ cis8 \bar "|."
    }
    \new Staff \with { instrumentName = "Bass" shortInstrumentName = "B." } {
      \clef "bass" \key a \major \time 9/8
      a,4.\p a,4. a,4. |
      d,4. d,4. d,4. |
      cis,4. cis,4. cis,4. |
      d,4. d,4. d,4. |
      e,4. e,4. e,4. |
      a,4. a,4. a,4 gis,8 |
      fis,4. fis,4. fis,4. |
      cis,4. cis,4. cis,4. |
      d,4.\mp d,4. d,4. |
      b,,4. b,,4. b,,4. |
      e,4. e,4. e,4. |
      a,4. a,4. a,4. |
      fis,4. fis,4. fis,4. |
      cis,4. cis,4. cis,4. |
      fis,4. fis,4. fis,4 e,8 |
      d,4. d,4. d,4. |
      a,,4.\mf a,4. a,,4. |
      cis,4. cis4. cis,4. |
      d,4. d4. d,4. |
      d,4. d4. d,4. |
      fis,4. fis4. fis,4. |
      d,4. d4. d,4. |
      d,4. d4. d,4. |
      e,4. e4. e,4. |
      a,4.\mp a,4. a,4. |
      d,4. d,4. d,4. |
      d,4. d,4. d,4. |
      cis,4. cis,4. cis,4. |
      d,4.\p d,4. d,4. |
      e,4. e,4. e,4. |
      e,4. e,4. e,4. |
      a,,1~ a,,8 \bar "|."
    }
  >>
  \layout {
    indent = 18\mm
    short-indent = 6\mm
    \context { \Score \override BarNumber.break-visibility = ##(#f #f #t) }
    \context { \Staff \override VerticalAxisGroup.default-staff-staff-spacing.basic-distance = #11 }
  }
}
